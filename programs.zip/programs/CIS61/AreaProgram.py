"""Darrell Owens--Area Triangle--CIS 61--8/24/17"""
import math
hypC=eval(input("Give the longest side"))
oppB=eval(input("Give the opposite"))
adjA=eval(input("Give the adjacent"))
sides=(adjA+oppB+hypC)/2
ans=math.sqrt(sides*(sides-adjA)*(sides-oppB)*(sides-hypC))
print("The answer is: " + str(ans))