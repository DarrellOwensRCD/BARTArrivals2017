"""CIS 61 Darrell Owens COnstructed Class Circle"""
class Circle:
    def __init__(self, radius, pi):
        self.circumference=2*(pi*radius)
        self.area=pi*(pow(radius, 2))
        self.diameter=2*radius
        self.radius

    def show(self):
        print ('Radius' , self.radius)
        print ('Circumference', self.circumference)
        print ('Area', self.area)
        print ('Diameter', self.diameter)

r=Circle(5,3.14159)
r.show()
        
