def main():
    counter=0
    counter2=0

    while(counter<3):
        counter=counter+1
        print(counter)
            
        while(counter2<2):
            counter2=counter2+1
            print("Test " + str(counter2))
        counter2=0
            
