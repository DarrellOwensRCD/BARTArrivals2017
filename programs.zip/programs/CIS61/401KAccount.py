class account:
    def __init__(self, n, i, a):
        self.name=n
        self.income=i
        self.age=a
    def person_info(self):
        pass
    
class FourOoneK(account):
    def __init__(self, a):
        account.__init__(self, a)
        self.age=a
    def calculate(self):
        if (self.age < 59.5):
            def early_withdrawl(self):
                pass
        else:
            if(self.age>=70.5):
                def mandatory_withdrawl(self):
                    pass
            else:
                def withdrawl_info(self):
                    pass
