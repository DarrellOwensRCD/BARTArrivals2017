"Darrell Owens CIS 61 Custom Exception 10/8/2017"""
class Error (Exception):
    pass
class tooSmall(Error):
    pass
class tooBig(Error):
    pass
def main():
    guess=0
    counter=0
    while(counter<3):
        while(True):
            try:
                guess=int(input("Provide a number between 1-10, you get three chances"))
                if (guess >10):
                    raise tooBig
                elif (guess < 1):
                    raise tooSmall
                break
            except tooSmall:
                print("Too small, remaining chances", (2-counter))
                print("Hint, off by : ", (1-guess))
                print()
            except tooBig:
                print("Too high, remaining chances", (2-counter))
                print("Hint, too high by : ", (guess-10))
                print()
            counter=counter+1
            if (counter > 2):
                break
        if(guess<11 and guess>0):
            break

          
    if(guess>0 and guess <11 or guess>0 and guess <11 and counter>2):
        print("Correct, you chose a number between 1-10")
    else:
        print("You're out of time")

