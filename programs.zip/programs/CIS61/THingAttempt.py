import pandas as pd
import numpy as np
from sklearn.datasets import make_classification, make_blobs
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cross_validation import train_test_split, cross_val_score
from sklearn.metrics import accuracy_score, recall_score, precision_score, confusion_matrix
import matplotlib.pyplot as plt
%matplotlib inline
plt.style.use("fivethirtyeight")
from IPython.display import Image

Image("EuclideanDistanceGraphic.jpg")
#Source: Analytics Vidya

data = make_classification(n_samples=200,
                           n_features=2,
                           n_classes=2,
                           n_informative=2,
                           n_redundant=0,
                            class_sep=.75,
                           random_state=5)

X = data[0]
y = data[1]
plt.figure(figsize=(15,11))
plt.scatter(X[:,0], X[:,1], c=y, s=250)
plt.xlabel("Feature One")
plt.ylabel("Feature Two")
plt.xlim(-3,3)
plt.ylim(-3,3);
