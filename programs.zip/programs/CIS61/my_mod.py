def my_func():
    print ('got called')
