import urllib.request
import json
import time
def BARTf():
    line_list=[]
    counter=0
    BART_key='MW9S-E7SL-26DU-VV8V'
    url='http://api.bart.gov/api/etd.aspx?cmd=etd&orig=RICH&key=MW9S-E7SL-26DU-VV8V&json=y'
    response=urllib.request.urlopen(url).read()
    json_obj=str(response, 'utf-8')
    data=json.loads(json_obj)
    print ('Sample station: Richmond')
    """Prints all keys and values"""
        
    for d in data['root']['station'][0]['etd'][0]['estimate']:
        value=(d['minutes'])
    return value
def main():
    value=BARTf()
    print("From main " + str(value))
