def main():
    f=open("CIS61TestFile.txt","r")
    if f.mode=='r':
        contents=f.read()
        print (contents)
