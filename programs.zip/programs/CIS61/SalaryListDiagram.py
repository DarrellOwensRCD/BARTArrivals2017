def main():
    a=int(input("Give the starting income")) 
    b=int(input("Give ending input"))
    n=1
    incomes=[]
    for x in range (a, b+1):
        if (x==a*n):
            incomes.append(x)
            n=n+1
    print (incomes) 
