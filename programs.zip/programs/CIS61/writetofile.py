def main():
    f= open("CIS61TestFile.txt","w")
    employees=["Dale Jackson", "Peter Bronan", "Truman Jerks"]
    address=["1234 Spaulding St", "1313 MLK Way", "1201 Corbett"]
    
    for i in range (0, 3):
        f.write("Employee %d\r " % (i+1))
        f.write(" ")
        f.write(employees[i])
        f.write(" ")
        f.write(address[i])
        f.write("\n")
        
    f.close()   

