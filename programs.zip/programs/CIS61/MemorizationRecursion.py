factorial_memo = {}
def factorial(k):
    if (k==1): return 1
    if k not in factorial_memo:
        sum=pow(k, 3)
        factorial_memo[k] = sum + factorial(k-1)
    return factorial_memo[k]
def main():
    print(factorial(9))
