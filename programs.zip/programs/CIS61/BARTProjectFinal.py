"""Darrell Owens CIS 61 Project 10/17/2017"""
import urllib.request
import json
import time
def all_stations(stn_rep):
    if(stn_rep.lower()=="sf"):
        SFstops=["Embarcadero", "Montgomery st.", "Powell st.", "Civic Center", "16th st. Mission", "24th st. Mission", "Glen Park", "Balboa Park"]
        for a in range (8):
            print(str(a)+ " " +SFstops[a])
        nans=int(input("Choose station by number: "))
        final_choice=SFstops[nans]
    elif(stn_rep.lower()=="oak"):
        OAKstops=["19th st. Oakland", "12th st. Oakland City Center", "Rockridge", "MacArthur", "Fruitvale", "Coliseum", "West Oakland"]
        for b in range (7):
            print(str(b)+ " "+ OAKstops[b])
        nans=int(input("Choose station by number: "))
        final_choice=OAKstops[nans]
    elif(stn_rep.lower()=="berk"):
        BERKstops=["Downtown Berkeley", "Ashby", "North Berkeley"]
        for c in range (3):
            print(str(c)+ " "+ BERKstops[c])
        nans=int(input("Choose station by number: "))
        final_choice=BERKstops[nans]
    else:
        ans=int(input("Type: 1. "))
        if (ans==1):
            Pstops=["Daly City", "Colma", "South San Francisco", "San Bruno", "San Francisco Intl Airport", "Millbrae"]
            for w in range(6):
                print(str(w)+ " " +Pstops[w])
            nans=int(input("Choose station by number"))
            final_choice=Pstops[nans]
        elif (ans==2):
            CCstops=["Orinda", "Lafayette", "Pleasant Hill", "Walnut Creek", "Concord", "North Concord", "Pittsburg/Bay Point"]
            for x in range(7):
                print(str(x)+" " +CCstops[x])
            nans=int(input("Choose station by number"))
            final_choice=CCstops[nans]
        elif(ans==3):
            SAstops=["Bayfair", "San Leandro", "Hayward", "South Hayward", "Fremont", "Castro Valley", "West Dublin", "Dublin/Pleasanton", "Warm Springs", "Union City"]
            for y in range (10):
                print(str(y)+ " " +SAstops[y])
            nans=int(input("Choose station by number"))
            final_choice=SAstops[nans]
        elif (ans==4):
            Rstops=["El Cerrito Plaza", "El Cerrito Del Norte", "Richmond"]
            for z in range (3):
                print(str(z)+ " " +Rstops[z])
            nans=int(input("Choose station by number"))
            final_choice=Rstops[nans]
        
    return final_choice
def stations(request_1):
    dict = {
            "12th st. Oakland City Center": "12th",
            "16th st. Mission": "16th",
            "19th st. Oakland": "19th",
            "24th st. Mission": "24th",
            "Ashby": "ashb",
            "Balboa Park": "balb",
            "Bayfair": "bayf",
            "Castro Valley": "cast",
            "Civic Center": "civic",
            "Coliseum": "cols",
            "Colma": "colm",
            "Concord": "conc",
            "Daly City": "daly",
            "Downtown Berkeley": "dbrk",
            "Dublin/Pleasanton": "dubl",
            "El Cerrito del Norte": "deln",
            "El Cerrito Plaza": "plza",
            "Embarcadero": "embr",
            "Fremont": "frmt",
            "Fruitvale": "ftvl",
            "Glen Park": "glen",
            "Hayward": "hayw",
            "Lafayette": "lafy",
            "Lake Merritt": "lake",
            "MacArthur": "mcar",
            "Millbrae": "mlbr",
            "Montgomery st.": "mont",
            "North Berkeley": "nbrk",
            "North Concord": "ncon",
            "Oakland Intl Airport": "oakl",
            "Orinda": "orin",
            "Pittsburg/Bay Point": "pitt",
            "Pleasant Hill": "phil",
            "Powell st.": "powl",
            "Richmond": "rich",
            "Rockridge": "rock",
            "San Bruno": "sbrn",
            "San Francisco Intl Airport": "sfia",
            "San Leandro": "sanl",
            "South Hayward": "shay",
            "South San Francisco": "ssan",
            "Union City": "ucty",
            "Walnut Creek": "wcrk",
            "Warm Springs": "warm",
            "West Dublin": "wdub",
            "West Oakland": "woak"
           
}
    return dict[request_1]
def trip_cost(query1, query2, st1, st2):
    api_key="MW9S-E7SL-26DU-VV8V"
    temp_url="http://api.bart.gov/api/sched.aspx?cmd=fare&orig="
    final_url=temp_url+query1+"&dest="+query2+"&date=today&key="+api_key+"&json=y"
    
    response=urllib.request.urlopen(final_url).read()
    json_obj=str(response, "utf-8")
    data1=json.loads(json_obj)
 
    print("From "+ st1+ " to " + st2)
    print("Fare $: "+ data1["root"]["trip"]["fare"])
    print("-------------------------------------------------")
    print()
    
def stn_search(query):
    line_list1=[]
    api_key="MW9S-E7SL-26DU-VV8V"
    temp_url="http://api.bart.gov/api/etd.aspx?cmd=etd&orig="
    locality=query
    final_url=temp_url + query+"&key="+ api_key+ "&json=y"
    response1=urllib.request.urlopen(final_url).read()
    json_obj1=str(response1, "utf-8")
    data1=json.loads(json_obj1)
    
    for d in data1["root"]["station"]:
        print("Station: "+ (d["name"]))
    for d in data1["root"]["station"][0]["etd"]:
        line_list1.append((d["destination"]))
    n_lines=(len(line_list1))
    print("-------------------------------------------------")
    print("Lines serving this station: " + ", ".join(line_list1))
    print("-------------------------------------------------")
    for i in range (n_lines):    
        print(line_list1[i])
        for d in data1["root"]["station"][0]["etd"][i]["estimate"]:
            if (d["minutes"]=="Leaving"):
                print(d["length"]+" car " +(line_list1[i])+ " train now boarding, platform " + d["platform"])
            else:
                print("Train arrival in : " + d["minutes"]+ " mins.")
                print(d["length"]+ " car train.")
                if (d["delay"]!="0" and d["delay"] > "59"):
                    delay_n=int(d["delay"])
                    print("This train is delayed by "+ str(time.strftime("%M:%S", time.gmtime(delay_n))))
            print()
        print("*************************************************")
    print (time.strftime("Current time " + "%m/%d/%Y %H:%M:%S\n"))
    print("________________________________________________")
def main():
        print("~Welcome to the Bay Area Rapid Transit estimated time arrival program~\n")
        ans=input("Do you need a station print out y, or can you type it by yourself? n:  ")
        if (ans=="y" or ans=="Y"):
            print("Is it in SF, Oakland, Berkeley or a Suburb?")
            ans=input("Type SF, Oak for Oakland, Berk for Berkeley, or suburb for suburban: ")
            return_stn=all_stations(ans)
            temp=stations(return_stn)
            stn_search(temp)
                
        elif (ans=="n" or ans=="N"):             
            try: 
                request=input("Type your station please, and Ill give you arrival times: ")
                temp=stations(request)
                stn_search(temp)
            except KeyError:
                print("You typed it wrong, read the station name carefully and try again.")
                request=input("Station please, and Ill give you arrival times: ")
                temp=stations(request)
                stn_search(temp)
                
        inquiry=input("Press any button for more options or type close. ")
        while(inquiry!="close"):
            print("Would you like to calculate fare, update the page? Or choose new a station? ")
            inquiry=input("Type update, fare, new or close ")       
            if (inquiry=="update"):
                print()
                try: 
                    stn_search(temp)
                except:
                    print("You typed it wrong. Try again")
                    stn_search(temp)
            elif(inquiry == "new"):
                request=input("Station Please, and Ill give you arrival times: ")
                temp=stations(request)
                print()
                stn_search(temp)
            elif (inquiry == "fare"):
                ans=input("From " + request + " station or another? y/n")
                if (ans=="n" or ans=="N"):
                    request=input("Starting station...")
                    stn_2=input("To where?")
                    new0=stations(request)
                    new1=stations(stn_2)
                    trip_cost(new0, new1, request, stn_2)                    
                else:
                    stn_2=input("To where?")
                    temp=stations(request)
                    new1=stations(stn_2)
                    trip_cost(temp, new1, request, stn_2)
            elif (inquiry=="close"):
                print("Enjoy your trip!")
                break
            else:
                print("Invalid input, try again")
                         
