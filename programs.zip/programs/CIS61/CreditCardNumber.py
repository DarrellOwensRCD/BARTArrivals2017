def main():
    print("Will determine if it has spaced credit number or 1 string")
    word=[int (y) for y in input().split()]
    if (len(word) == 4):
        print("You used a 4 digit format")
    elif (len(word) == 1):
        print("You used a singular format")
    else:
        print("Your format didn't make sense")
        
    
