"""Darrell Owens, Word Jumble, 9/22/2017, CIS 61"""
def main():
    print("This is a Word Jumble Game! Choose which game you'll play!")
    print("Press 1 for: Exercising in Class!")
    print("Press 2 for: SQL in what?!")
    print("Press 3 for: Word Reverser!")
    print("Press 4 for: Double Vision!")
    print("Press 5 for: Finish my statements!")
    x=int(input("Press Any other key to quit....  "))

    print("-----------------------------------------------------------------------------")
    print("If its two or more words, seperate with a space. Answers arent case sensitive")
    print("-----------------------------------------------------------------------------")
    print(" ")

    if(x==1):
        a='exercise'
        b='Class'
        print("Figure out the puzzle")
        print(a[:4]+ b + a[4:])
        answer=input("Answer: ")
        if(answer.lower()=="in class exercise"):
            print("Good job, answer was 'In class exercise!'")
        else:
            print("Sorry, wrong answer. Think about what teachers do in class.")
            print(a[:4]+b+a[4:])
            answer2=input(print("Try again, your answer is: "))
            if(answer2.lower()=="in class exercise"):
                print("Good job, it's in class exercise!")
            else:
                print("Go home and think it over")
        
    elif(x==2):
        a='SQL'
        b,c,d=a
        z='Java'
        y,x,w,v=z
        print("___ is embedded in _____")
        print("Here's your hint: ", y+b+x+c+w+d+v)
        answer=input("Answer (seperate the words with spacebar: ")
        if(answer.lower()=='sql java'):
            print("Good job, word whiz! SQL is embedded in Java")
        else:
            print("No, think about it. Structured Query Language embedded in what programming language?")
            answer2=input("Answer: ")
            if(answer2.lower()=='sql java'):
                print("Good job! SQL embedded in Java. Second time's a charm!")
            else:
                print("Eh, you might wanna look into other professions, kid.")
    elif(x==3):
        a="Engineering"
        print("What's the hobby of learning how things are built and breaking it down?")
        print("Hint: ", a[::-1])
        answer=input("Answer: ")
        if(answer.lower()=='reverse engineering'):
              print("Ha! You're obviously a PC owner!")
        else:
              print("Look who's never held a screwdriver, this should be easy!")
              print("How do you un-engineer something? Hint: ", a[::-1])
              answer2=input("Answer: ")
              if(answer2.lower()=="reverse engineering"):
                  print("Good, you reverse engineered my hint!")
              else:
                  print("I can tell you're a Mac user. Go to Safari and look up 'reverse engineering', kiddo.")
              
    elif(x==4):
        a="Trouble"
        print("When you're dealing with two jokers instead of one, you've got...?")
        print("Hint: ", a*2)
        answer=input("Answer")
        if(answer.lower()=="double trouble"):
            print("Good job, double trouble!")
        else:
            print("Go to In-N-Out and think about it.")
            print("When you get a Double Double, your heart's got Double ___")
            print("Hint: ", a*2)
            answer2=input("Answer: ")
            if (answer.lower()=="double trouble"):
                print("Good job. You watched the 'Double Trouble' episode of Jonny Quest, huh?")
            else:
                print("This is like the easiest puzzle in the world. Go pick up your Elementary School diploma.")
        
    elif(x==5):
        a="Bussiness"
        print("You forgot something didn't you? Or maybe a score to settle? You might have...")
        print("Hint: ", a.replace('ness','...'))
        answer=input("Answer: ")
        if (answer.lower()=='unfinished bussiness'):
            print("Good! Now go finish your bussiness!")
        else:
            print("Wrong answer, but it's quite literal.")
            print("Answer may be 'unfinsihed buss...' or something")
            answer2=input("Answer: ")
            if(answer2.lower()=='unfinished bussiness'):
                print("You've been working too hard! But you got it!")
            else:
                print("Slacker dectected. You've obviously never finished anything. Turn off the computer and get a job")
    else:
        print("See ya, have a good time.")
                
   
    
