def main():
    """Darrell Owens--CIS 61--A T 4 2--9/2/2017"""
    iteration=float(input("How many iterations?"))
    count=0
    x=.5
    cup=.5
    print("Cup starts with: " + str(x))
    while (count < iteration):
        
        count+=1
        x*=.5
        cup+=x
        
    print(count)
    print ("%.16f" % (cup))
    
        
