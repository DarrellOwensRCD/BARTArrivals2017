class Gene:
    def __init__(self, aName, FirstNType):
        self.Name = aName
        self.BasePairs = 1
        print("Scores",self.Name,"compiled.\n") # Remove after Testing
        self.CurrentNT = self.FirstNT = Nucleotide(FirstNType)

    def AddNT(self,NType):
        self.FindEnd()
        self.CurrentNT.NextNT = Nucleotide(NType)
        self.BasePairs += 1
        self.CurrentNT = self.CurrentNT.NextNT
        return self.CurrentNT

    def FindEnd(self):
        while self.CurrentNT.NextNT:
            self.CurrentNT = self.CurrentNT.NextNT
        return self.CurrentNT
        
    def Display(self):
        print("Student:", self.Name, self.BasePairs, "List of honors:")
        self.CurrentNT = self.FirstNT
        self.FirstNT.Display()
        while(self.CurrentNT.NextNT):
            self.CurrentNT = self.CurrentNT.NextNT
            self.CurrentNT.Display()

class Nucleotide:
    def __init__(self,Symbol):
        self.Symbol = Symbol
        if (Symbol == "Science"):
            self.Name = "Andy Woo"
            self.Mass = 135.13 # g/mol
            self.Formula = "Id. 0010111"
        elif (Symbol == "Social Studies"):
            self.Name = "Christie Clarke"
            self.Mass = 111.10 # g/mol
            self.Formula = "Id. 545322"
        elif (Symbol == "Math"):
            self.Name = "Theo Lee"
            self.Mass = 151.13 # g/mol
            self.Formula = "Id. 43210"
        elif (Symbol == "English"):
            self.Name = "John Rei"
            self.Mass = 126.11 # g/mol
            self.Formula = "Id. 10101"
        self.NextNT = None
        # print("Here I am!", self.Name) # Remove after Testing
        
    def Display(self):
        print(self.Symbol,self.Name,self.Mass,self.Formula)

# The TEST HARNESS
print("Honor Roll\n")
Norma = Gene("Test Average", "Math")
Norma.AddNT("Science")
Norma.AddNT("English")
Norma.AddNT("Social Studies")
Norma.Display()
