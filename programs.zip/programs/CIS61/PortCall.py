"""Darrell Owens 9/10/2017 Port List CIS 61"""
def main():
    ports=['Oakland', 'Long Beach', 'Hong Kong',
              'Kaohsiung', 'Naha', 'Yokohama', 'Oakland']
    for x, y in enumerate (ports, 1):
        print(x, y)
        
    ans=input("Would you like to change this list, yes/no?")
    
    if (ans.lower() == 'yes' ):
        city=int(input("Insert city's number on list to change"))
        cityNo=city-1
        replace=input("Type in the new city")
        ports[cityNo]=replace

        print('This is the following cities to port: ')
        for i, n in enumerate (ports, 1):
            print(i, n)
    else:
        print("Proceeding with current ports, thanks you.")
