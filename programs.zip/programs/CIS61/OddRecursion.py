def for_loop(num):
    sum=0
    for x in range(1, num+1):
        sum+=x
    return sum
def recursion(num):
    if (num==0):
        return 0
    elif(num%2!=0):
        return num + recursion(num-1)
    else:
        return recursion(num-1)
def main():
    n=int(input("Provided a number to be recursively determined."))
    print("Using for loop, sum of all is ", for_loop(n))
    print("Using recursion, sum of odds are ", recursion(n))
    
