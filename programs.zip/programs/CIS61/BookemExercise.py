class Books:
    ISBN={"121131311", "12121212", "49403493"}
    books={"Lion Tales", "War and Peace", "Superman"}
    dewey={"011", "112", "133"}
    authors={"Jon Doe", "Thris Campton", "Ellis Way"}
    subject={"Fiction", "Nonfiction", "biography"}
        
    def __init__(self, name, iden):
        self.full_name=name
        self.ID=iden
    def student_info(self):
        print('Student name: ', self.full_name)
        print('Identification no: ', self.ID)
    def date_books_out(self):
        pass
        
"""If all functions related to the library will be located in the Books class
then yes, a movie method will solve the issue. If not, then for sake of organization
it would be best to use a seperate class for movies."""
