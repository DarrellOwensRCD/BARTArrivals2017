import math
"""This works, switch it around""" 
def main():
    n = 147573952589676412927

    if n == 1 or n<0:
        print ("Not Prime")
    elif n % 2 == 0 and n != 2:
       print ("Not Prime")
       print ("Factor: ", 2)
    else:
       flag = 0
       for x in range(3, int(math.sqrt(n))):
           if n% x == 0:
               print ("Not Prime")
               print ("Factor: ", x)
               flag = 1
               quit()
       if flag==0:
           print ("Prime")
===========================================================
"""Darrell Owens CIS 61 8/5/2017 Brute force prime"""
import math
def main():
    print("Testing if Messenne Number to 67 is prime")
    number=147573952589676412927
    
    if(number < 2):
        print("It aint prime.")
    elif(number==2 or number % 2==0):
            print("If its 2 it's prime, if its not, then its Even.")
    else:
        flag=0
        for x in range(3, int(math.sqrt(number))):
               if number% x == 0:
                   print ("Not Prime")
                   print ("It's factor is : ", x)
                   flag = 1
                   quit()
        if flag==0:
               print ("Prime")
