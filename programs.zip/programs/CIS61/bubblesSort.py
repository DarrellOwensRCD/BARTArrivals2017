"""Darrell Owens CIS 61 10/6/2017 BubbleSort"""
def main():
    list=['C++', 'Java', 'Python', 'C#', 'COBOL', 'FORTRAN']
    for i in range (len(list)-1, 0, -1):
        for x in range (i):
            if(list[x] > list[x+1]):
                hold=list[x]
                list[x]=list[x+1]
                list[x+1]=hold
    print(list)
