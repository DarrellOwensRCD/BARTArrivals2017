def main():
    try:
        a=int(input("Give value one"))
        b=int(input("Give value two"))
        print(a/b)

    except ZeroDivisionError:
        print("Cannot divide by zero")
