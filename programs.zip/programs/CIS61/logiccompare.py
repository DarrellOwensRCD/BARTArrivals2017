"""Darrell Owens CIS 61 9/5/2017 Logic Comparator"""

def LogicComparator(p, q):
        truth = [True, False]
        counter=0
        counter2=0
        while(counter< 1):
            counter+=1
            while(counter2<1):
                counter2+=1
                t1, t2 = truth[counter], truth[counter2]

                if (p(t1,t2) != q(t1,t2)):
                            return False;
            counter2=0

        return True;

def dm1(p,q):
        return not(p and q);
def dm2(p,q):
        return (not p) or (not q);
def dm3(p,q):
        return not (p or q);
def dm4(p,q):
        return (not p) and (not q);
    
def main():
    print("!(p && q) vs !p || !q :" + str(LogicComparator(dm1, dm2)))
    print("!(p || q) vs !p && !q :" + str(LogicComparator(dm3, dm4)))


