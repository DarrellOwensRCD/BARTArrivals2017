class Galaxy:
    def star_systems(self):
        print("Here lies gasses, stars, and debris")
class Solar_System(Galaxy):
    def planet_clusters(self):
        print("Here lies a rotation of planets")
class Earth(Solar_System):
    def terrain(self):
        print("Here lies 7 contienents.")
        
g=Earth()
g.star_systems()
g.planet_clusters()
g.terrain()
