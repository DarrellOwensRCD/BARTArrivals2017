"""Darrell Owens CIS 61 9/14/2017(for loop ver.)"""
def main():
    counter=0
    shopping_list=[]
    n=int(input("How many items do you have?"))

    for x in range (n):
        item=input("State your item: ")
        shopping_list.append(item)
        counter=counter+1
    print(shopping_list[0])
