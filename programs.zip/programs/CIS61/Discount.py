def main():
    """Darrell Owens--CIS 61--Discount Program--8/24/2017"""
    amount= eval(input("Enter total amount and I'll calculate the discount"))

    if (amount > 500.00):
        discount=amount*.15
        nAmount=amount-discount
        print("15 percent discount applied, total is $%.2f" % (nAmount))

    elif (amount > 100.00):
        discount=amount*.1
        nAmount=amount-discount
        print("10 percent discount applied, total is $%.2f" % (nAmount))

    elif (amount > 50.00):
        discount=amount* .05
        nAmount=amount-discount
        print("5 percent discount applied, total is $%.2f" % (nAmount))

    else:
        print("No discount, total is: $%.2f" % (nAmount))
        
              
