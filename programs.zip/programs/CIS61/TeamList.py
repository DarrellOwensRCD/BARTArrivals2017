"""Darrell Owens, Volley, 9/22/2017 CIS 61"""
def main():
    listPlayers= \
    [
    "Berkeley Ravens", "Oakland T-Rex",
    ["Jesse Wang", "George Truman", "Clark Kent", "Tildon Owens", "Kyrie O'Shag", "Tim Rick"],
    ["Sampson Holloway", "Tim Dirk", "Clark Rells", "Owen Shyoer", "Kelly Drumpf", "Simpson Bond"],
    "Red and Gold", "Black and Blue"]

    print("Tonight, Bay Area teams: ", listPlayers[0], "and", listPlayers[1], " will face off.")
    print("Here's the stats: ")
    print("---------------------------")
    fmt = '{:<8}{:<20}{}'
    print(fmt.format(' ', listPlayers[0], listPlayers[1]))
    for i, (team1, team2) in enumerate(zip(listPlayers[2], listPlayers[3])):
        print(fmt.format(i+1, team1, team2))
    print(listPlayers[0], "wear", listPlayers[4])
    print(listPlayers[1], "wear", listPlayers[5])
