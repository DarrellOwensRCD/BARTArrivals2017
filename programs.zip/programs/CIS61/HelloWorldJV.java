package FilePackage;

import java.util.Scanner;

public class HelloWorldJV {

    public static void main(String[] args) {
         Scanner input = new Scanner(System.in);
         
         String FirstName;
         String LastName;
         String FullName;
                 
         System.out.println("Hello, World");
         
         System.out.println("What's your First Name?");
         FirstName = input.nextLine();
         
         System.out.println("What's your Last Name?");
         LastName = input.nextLine();
         
         FullName = FirstName + ' ' + LastName; 
         
         System.out.println("Hello, " + FullName + "!");
     }
}
