def main():
    """Darrell Owens--CIS 61--Scores--9/3/2017"""
    count=0
    score=0
    result=0
    print("Insert your test scores")
    print("if a score is given below 0 or above 110, loop ends")

    while(score>=0 and score < 110):
        score=float(input("What is your test score?"))
        if (score >=0 and score <110):
            result+=score
            count+=1
        else:
            print("Got it, will sum results")
    final=result/count
    print("Using %d" % (count) + " the class average is " + str(final))
