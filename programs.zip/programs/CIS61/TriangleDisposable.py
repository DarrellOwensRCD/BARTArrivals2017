def main():

    print("This program will ask you for the measurements of three separate angles in the form of degrees, minutes, and seconds. \nIt will then tell you if the angles you enter make up a Euclidean, elliptical, or hyperbolic trianle, i.e., a triangle in two or three dimensional space.")
    print("\n")

    angleTotalA = 0
    angleTotalB = 0
    angleTotalC = 0

    degrees = 0
    minutes = 0
    seconds = 0

    
    for x in range(3):
        angleInputDegrees = eval(input("Enter the number of whole degrees in the angle:"))
        angleInputMinutes = eval(input("Enter the number of whole minutes in the angle:"))
        angleInputSeconds = eval(input("Enter the number of seconds in the angle:"))
        degrees = degrees + angleInputDegrees
        minutes = minutes + angleInputMinutes
        seconds = seconds + angleInputSeconds
        if x == 0:
            angleTotalA = angleTotalA + angleInputDegrees + (angleInputMinutes *(1 / 60)) + (angleInputSeconds * (1 / 3600))
            print("On to angle 2.")
        if x == 1:
            angleTotalB = angleTotalB + angleInputDegrees + (angleInputMinutes *(1 / 60)) + (angleInputSeconds * (1 / 3600))
            print("On to angle 3.")
        if x == 2:
            angleTotalC = angleTotalC + angleInputDegrees + (angleInputMinutes *(1 / 60)) + (angleInputSeconds * (1 / 3600))
            print("Third angle complete.  Calculating...")


    print("Angle A in decimal form is:", angleTotalA)
    print("Angle B in decimal form is:", angleTotalB)
    print("Angle C in decimal form is:", angleTotalC)    
            

    degreesTotal = degrees + ((minutes + (seconds // 60)) // 60)
    minutesTotal = (minutes + (seconds // 60)) % 60
    secondsTotal =  seconds % 60

    print(degreesTotal, minutesTotal, secondsTotal)

    
    print("There are", degrees + ((minutes + (seconds // 60)) // 60), "degrees,", (minutes + (seconds // 60)) % 60, "minutes, and", seconds % 60, "seconds in your triangle.")

    if degreesTotal == 180 and minutesTotal == 0 and secondsTotal == 0 and angleTotalA  == angleTotalB and angleTotalA == angleTotalC and angleTotalB == angleTotalC:
        print("You have entered a Euclidean equilateral triangle.")

    if degreesTotal == 180 and minutesTotal == 0 and secondsTotal == 0 and angleTotalA == angleTotalB and angleTotalC != angleTotalA or angleTotalA == angleTotalC and angleTotalB != angleTotalA or angleTotalB == angleTotalC and angleTotalA != angleTotalB:
        print("You have entered a Euclidean isosceles triangle.")

    if degreesTotal == 180 and minutesTotal == 0 and secondsTotal == 0 and angleTotalA != angleTotalB and angleTotalA != angleTotalC and angleTotalB != angleTotalC:
        print("You have entered a Euclidean scalene triangle.")

    if degreesTotal < 180 and angleTotalA == angleTotalB == angleTotalC:
        print("You have entered a hyperbolic equilateral triangle.")

    if degreesTotal < 180 and angleTotalA == angleTotalB and angleTotalC != angleTotalA or angleTotalA == angleTotalC and angleTotalB != angleTotalA or angleTotalB == angleTotalC and angleTotalA != angleTotalB: 
        print("You have entered a hyperbolic isosceles triangle.")

    if degreesTotal < 180 and angleTotalA != angleTotalB and angleTotalA != angleTotalC and angleTotalB != angleTotalC:
        print("You have entered a hyperbolic scalene triangle.")

    if degreesTotal > 180 and angleTotalA  == angleTotalB and angleTotalA == angleTotalC and angleTotalB == angleTotalC:
        print("You have entered an elliptical equilateral triangle.")

    if degreesTotal == 180 and minutesTotal > 0 and angleTotalA  == angleTotalB and angleTotalA == angleTotalC and angleTotalB == angleTotalC:
        print("You have entered an elliptical equilateral triangle.")

    if degreesTotal == 180 and secondsTotal > 0 and angleTotalA  == angleTotalB and angleTotalA == angleTotalC and angleTotalB == angleTotalC:
        print("You have entered an elliptical equilateral triangle.")

    if degreesTotal > 180 and angleTotalA == angleTotalB and angleTotalC != angleTotalA or angleTotalA == angleTotalC and angleTotalB != angleTotalA or angleTotalB == angleTotalC and angleTotalA != angleTotalB: 
        print("You have entered an elliptical isosceles triangle.")

    if degreesTotal == 180 and minutesTotal > 0 and angleTotalA == angleTotalB and angleTotalC != angleTotalA or angleTotalA == angleTotalC and angleTotalB != angleTotalA or angleTotalB == angleTotalC and angleTotalA != angleTotalB:  
        print("You have eneted an elliptical isosceles triangle.")

    if degreesTotal == 180 and secondsTotal > 0 and angleTotalA == angleTotalB and angleTotalC != angleTotalA or angleTotalA == angleTotalC and angleTotalB != angleTotalA or angleTotalB == angleTotalC and angleTotalA != angleTotalB:   
        print("You have entered an elliptical isosceles triangle.")
        
    if degreesTotal > 180 and angleTotalA != angleTotalB and angleTotalA != angleTotalC and angleTotalB != angleTotalC:
        print("You have entered an elliptical scalene triangle.")

    if degreesTotal == 180 and minutesTotal > 0 or secondsTotal > 0 and angleTotalA != angleTotalB and angleTotalA != angleTotalC and angleTotalB != angleTotalC:
        print("You have entered an elliptical scalene triangle.")
    
        
