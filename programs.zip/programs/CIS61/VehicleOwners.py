class DMV_info:
    def __init__(self, location):
        self.location=current_location
    def list_of_DMVs(self):
        pass
    def closest_location(self, current_location):
        pass
    
def driver_history():
    pass

class driver_newInfo:
    def __init__(self, vehicle): 
        self.vehicle=current_vehicle
    def model_stats(self):
        pass
