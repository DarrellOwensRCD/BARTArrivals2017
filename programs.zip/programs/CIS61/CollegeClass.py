class College:
    def __init__(self, name, code, ad):
        self.school=name
        self.ref=code
        self.address=ad

    def college_show(self):
        print('School: ', self.school)
        print('Code: ', self.ref)
        print('Address: ', self.address)
def main():
    main_name=input("Insert school name")
    main_code=input("Insert school code")
    main_address=input("Insert school address")

    c=College(main_name, main_code, main_address)
    c.college_show()
        
