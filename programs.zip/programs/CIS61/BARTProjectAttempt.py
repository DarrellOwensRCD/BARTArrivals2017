"""Darrell Owens CIS 61 Project 10/17/2017"""
import urllib.request
import json
import time

def stations(request_1):
    dict = {
            '12th st. Oakland City Center': '12th',
            '16th st. Mission': '16th',
            '19th st. Oakland': '19th',
            '24th st. Mission': '24th',
            'Ashby': 'ashb',
            'Balboa Park': 'balb',
            'Bay Fair': 'bayf',
            'Castro Valley': 'cast',
            'Civic Center': 'civic',
            'Coliseum': 'colm',
            'Colma': 'colm',
            'Concord': 'conc',
            'Daly City': 'daly',
            'Downtown Berkeley': 'dbrk',
            'Dublin/Pleasanton': 'dubl',
            'El Cerrito del Norte': 'deln',
            'El Cerrito Plaza': 'plza',
            'Embarcadero': 'embr',
            'Fremont': 'frmt',
            'Fruitvale': 'ftvl',
            'Glen Park': 'glen',
            'Hayward': 'hayw',
            'Lafayette': 'lafy',
            'Lake Merritt': 'lake',
            'MacArthur': 'mcar',
            'Millbrae': 'mlbr',
            'Montgomery st.': 'mont',
            'North Berkeley': 'nbrk',
            'North Concord': 'ncon',
            'Oakland Intl Airport': 'oakl',
            'Orinda': 'orin',
            'Pittsburg/Bay Point': 'pitt',
            'Pleasant Hill': 'phil',
            'Powell st.': 'powl',
            'Richmond': 'rich',
            'Rockridge': 'rock',
            'San Bruno': 'sbrn',
            'San Francisco Intl Airport': 'sfia',
            'San Leandro': 'sanl',
            'South Hayward': 'shay',
            'South San Francisco': 'ssan',
            'Union City': 'ucty',
            'Warm Springs': 'wcrk',
            'West Dublin': 'wdub',
            'West Oakland': 'woak'
           
}
    return dict[request_1]
def stn_search(query):
    line_list1=[]
    api_key='MW9S-E7SL-26DU-VV8V'
    temp_url='http://api.bart.gov/api/etd.aspx?cmd=etd&orig='
    locality=query
    final_url=temp_url + query+"&key="+ api_key+ '&json=y'
    response1=urllib.request.urlopen(final_url).read()
    json_obj1=str(response1, 'utf-8')
    data1=json.loads(json_obj1)
    
    for d in data1['root']['station']:
        print("Station: "+ (d['name']))
    for d in data1['root']['station'][0]['etd']:
        line_list1.append((d['destination']))
    n_lines=(len(line_list1))
    print("-------------------------------------------------")
    print("Lines serving this station: " + ', '.join(line_list1))
    print("-------------------------------------------------")
    for i in range (n_lines):    
        print(line_list1[i])
        for d in data1['root']['station'][0]['etd'][i]['estimate']:
            if (d['minutes']=='Leaving'):
                print(d['length']+" car " +(line_list1[i])+ " train now boarding, platform " + d['platform'])
            else:
                print("Train arrival in : " + d['minutes']+ " mins.")
                print(d['length']+ " car train.")
                if (d['delay']!='0' and d['delay'] > '59'):
                    delay_n=int(d['delay'])
                    print("This train is delayed by "+ str(time.strftime("%M:%S", time.gmtime(delay_n))))
            print()
        print("*************************************************")
    print (time.strftime("Current time " + '%m/%d/%Y %H:%M:%S\n'))
    print("________________________________________________")
def main():
        print("~Welcome to the Bay Area Rapid Transit estimated time arrival program~\n")
        try: 
            request=input("Type your station please, and I'll give you arrival times: ")
            temp=stations(request)
            stn_search(temp)
        except KeyError:
            print("You typed it wrong, here's the stations and try again")
            request=input("Station Please, and I'll give you arrival times: ")
            temp=stations(request)
            stn_search(temp)
            
        inquiry=input("Press any button for more options or type close.")
        while(inquiry!='close'):
            inquiry=input("Would you like to update the page? Or choose new a station? Type 'update', 'new' or 'close'")
            if (inquiry=='update'):
                print()
                stn_search(temp)
            elif(inquiry == 'new'):
                request=input("Station Please, and I'll give you arrival times: ")
                temp=stations(request)
                print()
                stn_search(temp)
            elif (inquiry=='close'):
                print("Enjoy your trip!")
                break
            else:
                print("Invalid input, try again")
                         
