class MajorTracker:
    def __init__(self, name, major):
        self.name=name
        self.major=major
    def student_major(self):
        pass
def main():
    main_name=input("Insert name")
    main_major=input("Insert major")
    m=MajorTracker(main_name, main_major)
    m.studentName_major()
