"""Darrell Owens CIS 61 Collatz 9/10/2017"""
def collatz(n):
    counter=1
    while(n!=1):
        print(n)
        if (n % 2==0):
            n=n/2
        else:
            n=n*3+1
        counter=counter+1
    print(n)
    return counter
def main():
    i=int(input("Give me an int for the collatz test."))
    count=collatz(i)
    print(count-1)
