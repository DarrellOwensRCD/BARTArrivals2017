print("Provide values for a, b, c ")
quad=[int (y) for y in input().split()]

if (quad[0] <= 0 ):
    print("Formula can't be used, sorry.")

else:
    condition= (pow(quad[1], 2))-(4* (quad[0] * quad[2]))

    if (condition < 0):
        print("Squaring negative values ensures no real solution.")

    else:
        print("All conditions satisfy....")

        answer=(-1*quad[1] + pow(condition, .5))/(2*quad[0])
        answer1=(-1*quad[1] - pow(condition, .5))/ (2*quad[0])

        print("Subtraction: " + str(answer))
        print("Addition: " + str(answer1))
