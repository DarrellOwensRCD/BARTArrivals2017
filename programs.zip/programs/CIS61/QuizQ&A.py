class quiz:
    def problems():
        def problem_1(self, A, B, C):
            pass
        def problem_2(self, A, B, C):
            pass
        def problem_TF_1(self, t, f):
            pass
        def problem_TF_2(self, t, f):
            pass
    def grade_calculator():
        pass
