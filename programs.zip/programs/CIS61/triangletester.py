"""Darrell Owens--Triangulator--CIS 61--8/24/17"""

print("Give me your sides of a triangle")
C=eval(input("Give the longest side"))
B=eval(input("Give the opposite"))
A=eval(input("Give the adjacent"))

if(C==B and C==A):
    print ("Triangle is an equalateral")

else:
    if (C==B or C==A ):
        print ("Triangle is isoceles")
    elif( B==A):
        print ("Triangle is isoceles")

    elif (A+B+C < C*2):
        print("This isn't a triangle.")

    else:
        print("Triangle is scalene.")
    
    
