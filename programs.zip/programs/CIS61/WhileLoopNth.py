def calculator(i):
    k=0
    while (k < i):
        k=k+1
        num=(pow(k, 2) + k )/ 2
    instant=print(num)
    return instant

def main():
    """Darrell Owens--CIS 61--Triangular Numbers--9/2/2017"""
    n=eval(input("Give me your nth number"))
    answer= input("Do you want a list or instant?")

    if (answer== 'list'): 
        counter=0
        while (counter < n):
            counter=counter+1
            number=(pow(counter, 2) + counter)/2
            print(number)
    elif(answer=='instant'):
        calculator(n)
    
                
