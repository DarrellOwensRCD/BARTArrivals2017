def main():
    string list=[current_word.lower() for current_word in words]
    print(list)
