def main():
    print("Assume Moore's Law means double the transisters, double the speed (bit per second)")
    print("Moore's law is wrong by the way, but indeed technology is exponential")
    print("A 2.3 GHz processor clocks in at 2.3 billion bits per second")
    print("The human brain clocks in 400 billion bits per second, only 2000 we're aware of")

    human_brain=400
    computer=2.3
    counter=0
    print("Computer.........Human")
    while(computer < human_brain):
        computer=computer*2
        
        print(str(computer) +" vs. " + str(human_brain))
        counter+=1
    print("Computers are smarter than humans in approx. " + str(counter) + "years")
        
