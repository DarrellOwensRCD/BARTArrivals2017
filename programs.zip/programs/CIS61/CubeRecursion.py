def recursion(num):
    if (num==0):
        return 0
    else:
        sum=pow(num, 3)
        return sum + recursion(num-1)
def main():
    print("All cubes between 0 to 13 are: ", recursion(13))
