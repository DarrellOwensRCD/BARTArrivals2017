"""Darrell Owens--Shipping Charge--CIS 61--8/24/17"""

def finalPrice(nB, fC, cPD):
    fC=0.00
    return nB*cPD+fC
    
def main():
    books=["Lion Tales", "Narnia", "War and Peace"]
    nBooks=len(books)
    flatCharge=3.00
    chargePerBook=1.99
    print ("Total price of books are: $" + str(finalPrice(nBooks, flatCharge, chargePerBook)))
    
