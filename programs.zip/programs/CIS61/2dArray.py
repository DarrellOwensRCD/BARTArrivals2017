"""Darrell Ownes 2d Array CIS 61 10/3/2017"""
def main():
    values = [[2725, 2974, 3088, 3239, 3357],
              [2357, 2594, 2708, 2819, 2935],
              [2159, 2304, 2416, 2530, 2707],
              [1980, 2081, 2194, 2305, 2403],
              [1787, 1900, 2015, 2015, 2015],
              [1700, 1700, 1700, 1700, 1700],
              [1516, 1516, 1516, 1516, 1516]]
    print("TEST")
    years=eval(input("Insert years in "))
    grade=int(input("Insert grade E-"))
    gradeCalc=(7-grade)
    if (years<2):
      yearsCalc=0
    else:
        if(years>=2 and years<3):
          yearsCalc=1
        elif(years>=3 and years <4):
          yearsCalc=2
        elif(years>=4 and years <6):
            yearsCalc=3
        else:
            yearsCalc=4

    print(values[gradeCalc][yearsCalc])
    
