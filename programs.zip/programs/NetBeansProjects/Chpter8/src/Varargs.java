
class varTests{
    static String phrase=" This is a test of vargs";
    
    void VarargsExc (int...data){
        for (int i: data)
            System.out.println(i+" ");
    }
}
class Varargs {
    public static void main (String [] args){
        varTests VarTest=new varTests();
        int [] data0= new int [5]; //decleration example
        int [] data1= {10, 20, 30};
        System.out.println(VarTest.phrase);
        VarTest.VarargsExc(data1);
      
    }
    
}
