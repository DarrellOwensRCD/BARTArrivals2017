//Darrell Owens
//Exam 2
//Cis 36A
//5/1/2017
class Overloading{
    double add(int x, double y){
        return x+y;
    }
    
    double add(double x, int y){
        return x+y+1;
    }
    
}
public class Overloaded {
    public static void main (String[] args){
        Overloading OO= new Overloading ();
        double a, b;
        a=OO.add(3,3.14 );
        b=OO.add(3.14, 3);
        
        System.out.print(a+" "+b);
    }
}
/*
6.140000000000001 7.140000000000001BUILD SUCCESSFUL (total time: 0 seconds)
*/