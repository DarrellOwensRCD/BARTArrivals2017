//Darrell Owens
//Exam 2: Problem 2
//Cis 36A
//5/1/2017
class String1{  
 boolean Palindrome(String str) {    
    int n = str.length();
    for( int i = 0; i < n/2; i++ )
        if (str.charAt(i) != str.charAt(n-i-1)) return false;
    return true; 
    } 
}
public class StringTester{
    public static void main (String[] args){
        String1 ST=new String1();
        
       String PH="darrell";
       String DH="abcdcba";
       
       System.out.println("Is this Palindrome?");
        System.out.println("Darrell = " + ST.Palindrome(PH));
        System.out.println("abcdcba = "+ ST.Palindrome(DH));   
    }
}
/*
run:
Is this Palindrome?
Darrell = false
abcdcba = true
BUILD SUCCESSFUL (total time: 0 seconds)
*/