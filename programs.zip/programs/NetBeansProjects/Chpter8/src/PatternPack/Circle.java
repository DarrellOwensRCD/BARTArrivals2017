package PatternPack;

public class Circle{
    public void triangle () { 
        for (int i=1; i<6; i++){
            for (int k=1; k<i; k++){
                System.out.print("*");
            }
            System.out.println("*");
        }
    }
}
class PrintPattern {
    public static void main (String[] args){
        Circle PP = new Circle();
        PP.triangle();
    }
}
