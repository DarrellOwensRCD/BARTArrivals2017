/*
This program tests four concepts: printing Private, Public and Static Variables. 
Along with referencing a class from a different package. 
*/
import PatternPack.Circle;
class testingP{
    private int x=1000;
    public int y=2000;
    static int z=3000;
    
    int getx() {
        return x;
    }
}
public class PrivatesStatics {
    public static void main (String[] args){
        
        PackageRelay.ReturnFive RF = new PackageRelay.ReturnFive(); //Relays from foreign pacakge
        testingP TP=new testingP();    
        Circle Tri=new Circle();  
                                                                    //called: PackageRelay
        int a;                                                    
        a=RF.ReturnFiveAct();
        Tri.triangle();                                             
        System.out.println("This is from a foreign pacakge: " +a);
        System.out.println(testingP.z + TP.y + TP.getx());
    }           
}
/*
run:
*
**
***
****
*****
This is from a foreign pacakge: 5
6000
BUILD SUCCESSFUL (total time: 0 seconds)

*/