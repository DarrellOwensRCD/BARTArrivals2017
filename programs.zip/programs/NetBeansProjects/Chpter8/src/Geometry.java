//Darrell Owens
//4/25/2017
//Java 36a
//Lab 
import static java.lang.Math.pow;
public interface Geometry {
    double cube (double L);
    double sphere (double r);
    double cone (double r, double height);
    double pi = 3.14159;
}

class Volume implements Geometry{
    
    public double cube (double L){
        return pow(L, 3);
    }
    
    public double sphere (double r){
        return ((4* pi) * (pow (r, 3)))/3;
    }
    
    public double cone (double r, double height){
        return (pi * pow(r, 2) * height)/3;
    }
}

class Surface implements Geometry{
    
    public double cube (double L){
        return 6*(pow(L, 2));
    }
    
    public double sphere (double r){
        return 4*pi* pow(r, 2);
    }
    public double cone (double r, double height){
        return (pi*r)*(r+ pow((height*height) + (r*r) , .5));
    }
}

class GeometryTester {
    public static void main(String [] args){
    Surface GTS = new Surface();
    Volume GTV= new Volume();
    double cubeRatio, sphereRatio, coneRatio;
    double i=4.0;
    
    System.out.println("Volume of cube: " + GTV.cube(i)+ " Surface of cube: "+ GTS.cube(i));
    System.out.println("Volume of sphere: " + GTV.sphere(i)+ " Surface of sphere: "+ GTS.sphere(i));
    System.out.println("Volume of cone: " + GTV.cone(i, i)+ " Surface of cone: "+ GTS.cone(i, i));
    
    cubeRatio=GTS.cube(i) / GTV.cube(i);
    sphereRatio= GTS.sphere(i) / GTV.sphere(i);
    coneRatio= GTS.cone(i, i)/ GTV.cone(i, i);
    
    if (sphereRatio < cubeRatio && sphereRatio< coneRatio)  
        System.out.println("Verified: Sphere is the smallest ratio at " + sphereRatio);
    else 
        System.out.println("Calculation error.");

    }
}
/*
run:
Volume of cube: 64.0 Surface of cube: 96.0
Volume of sphere: 268.08234666666664 Surface of sphere: 201.06176
Volume of cone: 67.02058666666666 Surface of cone: 121.35150696665106
Verified: Sphere is the smallest ratio at 0.75
BUILD SUCCESSFUL (total time: 0 seconds)
*/
