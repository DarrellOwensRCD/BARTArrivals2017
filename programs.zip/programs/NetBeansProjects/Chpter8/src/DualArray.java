class DAverage{
    double sum;
    double average;
    void ShowArray(double[][] dual){
    for (double[] x : dual)
{
   for (double y : x)
   {
        System.out.print(y + " ");
   }
   System.out.println();
}
        
}
    double Average(double [][] dual){
        for(int i=0;i<dual.length;i++){
            for(int j=0;j<dual[i].length;j++){
                sum = sum+dual[i][j];
            }
        }
        return sum;
    }
}
public class DualArray {
    public static void main (String[] args){
        double average, rAverage, k;
        
        DAverage DA= new DAverage();
        double array[][]= {{5, 6, 7}, {8, 9, 10}};
        
        average=DA.Average(array);
        
        k=array.length * array[0].length;
        rAverage=average/k;
        
        System.out.println("Answer is: "+ rAverage);
        System.out.println();
        
        DA.ShowArray(array);
       
    }
    
}
