package PackageRelay;
/*
Test program which will be called by "PrivateStatistics.java" in the default pacakge in
Project "Chpter 8"
*/
public class ReturnFive{
    public int ReturnFiveAct(){
        return 5;
    }
}
class CalculateInt {
    public static void main(String[] args){
        ReturnFive RO= new ReturnFive(); 
        
        int n;
        
        System.out.println(n=RO.ReturnFiveAct());
    }
}
