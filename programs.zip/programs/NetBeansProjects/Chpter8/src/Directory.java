//Darrell Owens
//Exam 2: Problem 3
//Cis 36A
//5/1/2017
public interface Directory{
    double ElectPower(double a, double b);
    double ElectEnergy(double c, double d, double e);
}
class EnergyConsumption implements Directory{
    double result1, result2;
    
    public double ElectPower (double a, double b){
        result1=a*b;
    return result1;
    }

    public double ElectEnergy (double c, double d, double e){
        result2= (c*d*e)/1000;
    return result2;
    }
}

class TestElectricPower {
    public static void main (String[] args){
        EnergyConsumption EC= new EnergyConsumption();
        
        System.out.println("Elect Power: "+ EC.ElectPower(2.0, 120.0)+" watts");
        System.out.println("Elect Energy: " + EC.ElectEnergy(2.0, 120.0, 1000.0)+ " kilos");
    }   
}
/*
run:
Elect Power: 240.0 watts
Elect Energy: 240.0 kilos
BUILD SUCCESSFUL (total time: 0 seconds)
*/
