
package chapter10;

/**
 *
 * @author darrell
 */
public class Chapter10 {
    public static void main(String[] args) {
        int array[]={10, 20, 30 , 40};
        int array2[]={0, 2, 30, 10};
        int x;
        
        try{
            for (int i=0; i<array.length; i++){
                x= array[i]/array2[i];
                System.out.println(x);
            }
        }
        catch (ArithmeticException ex1){
            System.out.println("Error! Can't divide by zero");
        }
        System.out.println("Code has finished running.");
    }
}
