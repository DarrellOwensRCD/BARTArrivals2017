package preparetodelete;

class Deer{ 
    String firstName;
    String lastName;
    
    Deer(String a, String b){
        a=firstName;
        b=lastName;
    }

    String FirstNamePrint() {
        System.out.print(firstName);
        return firstName;
    }
    String LastNamePrint(){
        System.out.print(lastName);
        return lastName;
    } 
}
class DeerTester {
    public static void main (String[] args){
    
    String x; 
    String y;

    String[] employeesF = {"Fox", "Samus", "Master", "Captain"};
    String[] employeesL = {"McCloud", "Aran", "Hand", "Falcon"};
    
    for(int i=0; i<4; i++)
    {
        x=employeesF[i];
        y=employeesL[i];
        
    Deer Name = new Deer(x, y);
    
    Name.LastNamePrint();
    Name.FirstNamePrint();

        }
    }  
}
