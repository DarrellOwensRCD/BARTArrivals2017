public class whatever{
  public static void main (String [] args)
    throws java.io.IOException {
    
    char ch;
    System.out.print("Type something w/ a key");
    
    for (int i=0; i<5; i++)
    ch=(char) System.in.read();
    
    
  }
}