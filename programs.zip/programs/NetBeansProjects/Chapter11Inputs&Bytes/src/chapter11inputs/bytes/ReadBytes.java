
package chapter11inputs.bytes;
import java.io.*;
  
  public class ReadBytes {
  public static void main (String[] args)
          
    throws IOException {
    byte[] data = new byte[10];
    
    System.out.println("Enter characters: ");
    int numRead= System.in.read(data);
    System.out.println("You entered ");
    for (int i=0; i< numRead; i++)
      System.out.print ((char) data[i]);
  }
}