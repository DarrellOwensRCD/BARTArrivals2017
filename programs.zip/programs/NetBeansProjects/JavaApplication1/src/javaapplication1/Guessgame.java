
package javaapplication1;

/*
 Darrell Owens
 Java 26a
 Guess the number
 2/13/2017
 */
import java.util.Scanner;

public class Guessgame {
    public static void main(String[] args)
    {   
        char i = 'K';
        Scanner reader = new Scanner(System.in);
        System.out.println("Try and guess the letter");
        char guess = reader.next().charAt(0);
        
        if (guess==i)
        {
            System.out.println("Good job! The letter was K!");
        }
        else if (i != guess)
        {
            if (i < guess)
            {
            int x= guess-i;
            System.out.println("Sorry, you were " + x + " too high away from the letter.");
            }
            
            else if (i > guess)
            {
            int y= i-guess;
            System.out.println("Sorry, you were " + y + " to low away from the letter");
            }
            
        }
    }
}
/*
run:
Try and guess the letter
A
Sorry, you were 10 to low away from the letter
BUILD SUCCESSFUL (total time: 1 second)

*/
