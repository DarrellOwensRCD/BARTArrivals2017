package javaapplication1;

/**
 *
 * Reversing a string (only does a word)
 */
import java.util.Scanner;
public class ReverseString {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Let me reverse your string ");
        String reversestring = scanner.next();
        
        String reverse = new StringBuffer(reversestring).reverse().toString();
        System.out.println(reverse);
    }
    
}
/*
run:
Let me reverse your string 
Darrell
llerraD
BUILD SUCCESSFUL (total time: 4 seconds)

*/