/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * Vowels Counter
 */
import java.util.Scanner;
public class VowelCounter {
    {
  
                Scanner scanner = new Scanner (System.in);
                System.out.println("Enter a string and I'll count the vowels");
                String string1=scanner.next();

                string1 = string1.toLowerCase();
                int count = 0;
                int vowels = 0;
                int consonants = 0;
                
                for (String retval: string1.split(" ")){
                     for (int i = 0; i < retval.length(); i++)
                {
                        char ch = retval.charAt(i);
                        if (ch == 'a' || ch == 'e' || ch == 'i' || 
                                        ch == 'o' || ch == 'u')
                        {
                                vowels++;
                        }
                        else
                        { 
                                consonants++;
                        }
                }
            System.out.println(retval.substring(0, 1).toUpperCase() + retval.substring(1)+" has "+vowels+" vowels and "+consonants+" cosonants");
         vowels=0;
         consonants=0;
      }
    }
}
/*
run:
Enter a string and I'll count the vowels
Darrell
Darrell has 2 vowels and 5 cosonants
BUILD SUCCESSFUL (total time: 6 seconds)
*/