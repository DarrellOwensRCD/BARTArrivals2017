
package javaapplication1;

/**
 *Darrell Owens
 * CIS 26a
 * Random via case/switch
 * 2/13/2017
 */
public class RandomNumber {
    public static void main(String[] args)
    {   
    
    int i = (int) (10* Math.random());

     switch (i){
         case 0: 
         System.out.println(" The number is 0");
         break;
         case 1:
         System.out.println(" The number is 1");
         break;
         
         case 2: 
         System.out.println(" The number is 2");
         break;
         
         case 3:
         System.out.println(" The number is 3");
         break;
         
         case 4:
         System.out.println(" The number is 4");
         break;
         
         case 5:
         System.out.println(" The number is 5");
         break;
         
         case 6:
         System.out.println(" The number is 6");
         break;
         
         case 7:
         System.out.println(" The number is 7");
         break;
         
         case 8:
         System.out.println(" The number is 8");
         break;
         
         case 9:
         System.out.println(" The number is 9");
         break;
         
         case 10:
         System.out.println(" The number is 10");
         break;
 
     }
    }
}

