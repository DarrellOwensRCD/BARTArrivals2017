package javaapplication1;

/**
 Weight/Height ratio
 */
import java.util.Scanner;
public class TestingInput
{
    
    public static void main(String[] args)
    { 
        for (int i =1; i < 5; i++ ){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Give me your weight, and I'll tell you your condition. ");
        double weight = scanner.nextDouble();
        System.out.println("Give me your height, and I'll tell you your condition. ");
        double height = scanner.nextDouble();
        
        double grade= weight/height;
        
        if (grade <= 2.1)
        {
            System.out.println("His height ration is normal");
            
        }
        else if (grade <=2.3)
        {
            System.out.println("You are slightly above average");
        }
        else if (grade <= 2.5  )
        {
            System.out.println("You need to lose 5% of your weight");
        }
        else if (grade <=3)
        {
            System.out.println("You need to lose 5% of your weight");
        }
    }
}
}
/*
run:
run:
Give me your weight, and I'll tell you your condition. 
145
Give me your height, and I'll tell you your condition. 
72
His height ration is normal
Give me your weight, and I'll tell you your condition. 
163
Give me your height, and I'll tell you your condition. 
72
You are slightly above average
Give me your weight, and I'll tell you your condition. 
165
Give me your height, and I'll tell you your condition. 
68
You need to lose 5% of your weight
Give me your weight, and I'll tell you your condition. 
185
Give me your height, and I'll tell you your condition. 
65
You need to lose 5% of your weight
BUILD SUCCESSFUL (total time: 20 seconds)

*/