/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ExamAttempts;

/**
 * Darrell Owens 
 * 3/5/2017
Programs messing with classes
* Conductors
* Objects
* Reference variables. 
 */
class Ingridents{ //Create variables
    int sugar;
    int salt; 
    int butter;
    int water;
    String Drink;
   
    
    Ingridents(int a, int b, int c, int d, String e){ //Create conductor (reference placeholders)
        sugar=a; 
        salt=b; 
        butter=c; 
        water= d;
        Drink= e;
    }
    
    double servingsMade(double amount ){  //Another subclass, designed to return calculation values and refeence variable
        return amount * water; 
    }
    
    void Drinks(){                       //Subclass that is an object. Will relay output without Main class.
    System.out.println("Recommended drink: "+ Drink + " At least: "+ water+ " ounces.");
    }  
    void Space(){
    System.out.println("  ");
    }
}

class MaltOMeal {
    public static void main (String[] args){
        for (int i=0; i<3; i++){
        Ingridents Boy= new Ingridents(7, 2, 3, 10, "Apple Juice");  //Transfering variable placeholders from "Ingridents" values  
        Ingridents Girl= new Ingridents (6, 1, 4, 8, "Orange Juice"); //With main class values
        
        double servings=2;
     
        int boyGlut= Boy.sugar+ Boy.salt+ Boy.butter;      //"Boy" references the new variable I made. ".sugar" (for example) references...
        int girlGlut= Girl.sugar+ Girl.salt+ Girl.butter;  //the variables up in "Intgridents". And their corresponding values in main. 
        double servingSizeB= Boy.servingsMade(servings);   //Assinging a translated object into a value. Boy is new variable/object. servingsMade is class reference. 
        double servingSizeG= Girl.servingsMade(servings);  //and (servings) means swapping "amount" for mainclass translation which is "servings". 
        
        System.out.println("If the boy eats Malt O Meal, he will consume a total glutton of "+ boyGlut+ " grams."); 
        System.out.println("Recommended serving size is: "+servingSizeB);
        Boy.Drinks();                                      //The objects output. Running the return from Drinks() sub-class. 
        System.out.println("                                                                ");
        System.out.println("Girl eats Malt o Meal, she will consume a total gluton of "+ girlGlut+ " grams.");
        System.out.println("Recommended serving size is "+ servingSizeG);
        Girl.Drinks();
        Boy.Space();
    } 
  }
}
