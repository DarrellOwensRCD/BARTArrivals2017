
package ExamAttempts;

/**
Darrell Owens
* Question 2
* Correct Version 
 */
class WH {
    double weight;
    double height;
    
    WH( double a, double b){
    weight=a;
    height=b;
    }
    
    double BMIcalculated(double BMIcalc)
    {   
        
        BMIcalc=weight/height; 
        if (BMIcalc<= 2.1)
        {
            System.out.println("Weight ratio normal");     
        }
        else if (BMIcalc<=2.3)
        {
           System.out.println("Slightly above average.");
        }
        else if (BMIcalc<= 2.5  )
        {
           System.out.println("Lose 5% of weight.");
        }
        else
        {
            System.out.println("Lose 5% of weight.");
        }
        return BMIcalc; 
    }
}
   
    class HealthDemo{
        public static void main (String[] args) {
            
            WH Robert= new WH(145, 72);
            WH Fred = new WH(163, 72);
            WH Sam = new WH(165, 68);
            WH Richard = new WH(185, 65);
            
          double  ratio=0;
          System.out.print("Robert's ");
          Robert.BMIcalculated(ratio);
          System.out.print("Fred's weight is ");
          Fred.BMIcalculated(ratio);
          System.out.print("Sam needs to  ");
          Sam.BMIcalculated(ratio);
          System.out.print("Richard needs to ");
          Richard.BMIcalculated(ratio);     
    }
}    
    
/*
run:
Robert's Weight ratio normal
Fred's weight is Slightly above average.
Sam needs to  Lose 5% of weight.
Richard needs to Lose 5% of weight.
BUILD SUCCESSFUL (total time: 5 seconds)
*/


    