
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class BARTAPIurl {
    public static void main (String[] args){
        try{
            
        String url="http://webservices.nextbus.com/service/publicJSONFeed?command=predictions&a=sf-muni&stopId=14756";
        URL obj = new URL(url);
        HttpURLConnection con= (HttpURLConnection) obj.openConnection();
        
        int responseCode=con.getResponseCode();
        System.out.println("\nSending 'GET' request to URL: " + url);
        System.out.println("Response Code: " + responseCode);
        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();
        while ((inputLine = in.readLine()) != null){
            response.append(inputLine);
        }
        in.close();
        //System.out.println(response.toString());
        
        JSONObject myresponse=new JSONObject(response.toString());  //Find way to
        System.out.println(myresponse);
        }
        catch (Exception e){
            System.out.println(e);
        }
    }
}
