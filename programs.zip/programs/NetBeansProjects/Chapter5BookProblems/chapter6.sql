class numbers{
  int [] remove(int [] data, int idx1) {
    int a = data.length;
    int [] newdata=new int[a];
    int f=new.dat
    int k=0;
    int e= idx1+1;
    
    
    for (int l=0; l<idx1; l++){
      newdata[l]=data[l];
    }
    
    for (int i=0; i<data.length-idx1; i++){
      newdata[i]=data[i+idx1];
      }
    
    return newdata;
    }
  }

public class numberstesters{
  public static void main (String[] args){
    numbers NT= new numbers();
    int [] holder2=new int[4];
    int idx=2;
    int [] data1= {10, 12, 13, 14};
    
    
    holder2=NT.remove(data1, idx);
    
    for (int c=0; c<holder2.length-1; c++){
    System.out.print(holder2[c]+" ");
    }
  }
}
    