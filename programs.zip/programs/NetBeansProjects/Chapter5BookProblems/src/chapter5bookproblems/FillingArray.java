/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chapter5bookproblems;

/**
 *
 * @author Owner
 */

public class FillingArray {
public static void main(String[] args) { 
    
    int SIZE=30;
    int[] array= new int[SIZE];
 
    
    for (int i=0; i<SIZE; i*=2){ //Its an obvious fibonacci pattern 
        array[i]=i;
    }
         

    for (int k : array)
    { 
        System.out.print(k+ " ");
    }   
  } 
} 
/*
0 1 1 2 3 5 8 13 21 34 55 89 144 233 377 610 987 1597 2584 
4181 6765 10946 17711 28657 46368 75025 121393 196418 317811 
514229 BUILD SUCCESSFUL (total time: 0 seconds)
*/


    
