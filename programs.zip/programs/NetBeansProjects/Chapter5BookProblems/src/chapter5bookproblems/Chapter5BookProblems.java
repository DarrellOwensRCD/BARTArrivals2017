/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chapter5bookproblems;

/**
 *
 * @author Owner
 */
import java.io.*;
public class Chapter5BookProblems{
    public static void main ( String args[] ) 
    {
        String array= new String ("I love Java");  
        System.out.println(array.length()); //length is 11
        System.out.println(array.charAt(4)); //position 4 in array ("v")
    }
}
/*
run:
11
v
BUILD SUCCESSFUL (total time: 0 seconds)
*/