/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chapter5bookproblems;



/**
 *
 * @author Owner
 */
public class NewClass {
        public static void main ( String args[] ) 
    {
        String[] arr={"Oakland", "Berkeley", "Albany", "San Francisco", "San Leandro", "Daly City"};
        //Bubble sort for Strings
        for ( int j = 0 ; j < arr.length ; j++ )
        {
            for( int i = j + 1 ; i < arr.length ; i++ )
            {
                if ( arr[ i ].compareTo( arr[ j ] ) < 0 ) 
                {
                    String t = arr[ j ];
                    arr[ j ] = arr[ i ];
                    arr[ i ] = t;
                }
            }
            System.out.println( arr[ j ] );
        }
    }
}
