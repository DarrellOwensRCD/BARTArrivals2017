/*
-RCD Project-
 
-Task 2: Ensure last cell number is stated
-Task 3: Make into program, give to RCD
 */
package newpackage;

import org.apache.poi.ss.usermodel.DataFormatter;
import java.io.BufferedReader; //Web Request Data
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner; //API scanner
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.json.JSONArray; //Language of API
import org.json.JSONObject;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import java.io.File;

class prototype {

    int valid = 0, nValid = 0, bAdd = 0, counter = 0, counter1 = 0; //Class variables to be used as counters
    int fiveMi = 0, tenMi = 0, twentyMi = 0, beyondMi = 0;        //and also check marks for executable structures to occur
    boolean addressCheck = true;
    StringBuffer URL_final;
    String protoAddress;
    String protoCity;
    String protoState;
    String chanceURL;
    String targetLoc;
    float Riv_lat; //Insert lat/long on the project site
    float Riv_lon;
    double m = 1609.344;
    int chances = 0;

    float distance_formula(float lat1, float lng1, float lat2, float lng2) { //This calculates the distance
        double earthRadius = 6371000; //meters
        double dLat = Math.toRadians(lat2 - lat1);
        double dLng = Math.toRadians(lng2 - lng1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(dLng / 2) * Math.sin(dLng / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        float dist = (float) (earthRadius * c);

        return dist;
    }

    void network(String url) {//This function will take the string url and connect it to the Internet.
        try {                 //Any failure here likely means your Internet connection is down or unavailable. 
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            int responseCode = con.getResponseCode();
            //System.out.println("\nSending 'GET' request to URL: " + url);
            //System.out.println("Response Code: " + responseCode);
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            URL_final = response;

        } catch (Exception e) {
            System.out.println("Network Error");

        }
        counter++;
        counter1++;
    }

    void url_constructor(String a, String b, String c) { //Cheating google by swapping numerous api-keys
        //Should work for up to 10,000 applicants, give a few hundred more
        String API_KEY = "AIzaSyDj009-kXq3UjPI-B-5kd_PZ5BH8QvnuEk";
        String API_KEY2 = "AIzaSyByBwSbuq_SQnMLyQpLGsoqNQzy5-PRXBA";
        String API_KEY3 = "AIzaSyAsMLHAmUUM99P36-vwWoQ1IhW_bgJ3OKY";
        String API_Key4 = "AIzaSyD2iLH3DrTOS2FCQBzvMEz_vE0yNZB4DQM";
        String API_KEY5 = "AIzaSyCm-wY3pdv7QFylLKfvQJa055_689ux-OY";
        String API = "";
        if (counter1 < 2500) {
            API = API_KEY5;
            //System.out.println(early_url);
            //network(early_url);
        } else if (counter1 < 5000) {
            API = API_KEY2;
            //System.out.println(early_url);
            //network(early_url);
        } else if (counter1 < 7500) {
            API = API_Key4;
        } else if (counter1 < 10000) {
            API = API_KEY3;
        } else if (counter1 < 12500) {
            API = API_KEY;
        }

        String early_url = "https://maps.googleapis.com/maps/api/geocode/json?address=" + a + ",+" + b + ",+" + c + "&key=" + API;
        //System.out.println(early_url);
        chanceURL = early_url;
        network(early_url);
        coordinate_conversion();
    }

    void formatter() {
        //Preparing each word to be address eligible 
        //Find white spaces and replaces with URL-mandated plus signs
        protoAddress = protoAddress.replaceAll(" ", "+");
        protoCity = protoCity.replaceAll(" ", "+");
        protoState = protoState.replaceAll(" ", "+");
        /* System.out.print(protoAddress+ " ");
       System.out.print(protoCity+ " ");
       System.out.println(protoState); */
        url_constructor(protoAddress, protoCity, protoState);
    }

    void capture_excel(int choice, String iFile) { //Excel function that captures information from a .xlsl document, *provided*
        //the first row is a title, and the 2nd row onwards are addresses
        DataFormatter formatter = new DataFormatter();

        try {
            FileInputStream fis = new FileInputStream(new File(iFile));
            try {
                XSSFWorkbook wb = new XSSFWorkbook(fis);

                XSSFSheet sheet = wb.getSheetAt(0);
                //System.out.println("This program will finish the last row cell: "+ sheet.getLastRowNum()+ "\nIs this correct?");
                //Start here
                for (int i = 1; i <=choice; i++) { //Set iterations here. First row is title.
                    try {
                        Row row = sheet.getRow(i);
                        org.apache.poi.ss.usermodel.Cell address = row.getCell(0);
                        org.apache.poi.ss.usermodel.Cell city = row.getCell(2);
                        org.apache.poi.ss.usermodel.Cell state = row.getCell(3);
                        protoAddress = address.getStringCellValue();
                        protoCity = city.getStringCellValue();
                        protoState = state.getStringCellValue();
                        formatter();
                    } catch (java.lang.IllegalStateException e) {
                        System.out.println("\nBad address format, couldn't use Applicant #" + (counter) + "\nSpreadsheet Location: Row " + (counter + 1) + ", Column A." + "\n");
                        counter++;
                        bAdd++;
                    }
                }
                //return sheet.getLastRowNum();
            } catch (IOException ex) {
                System.out.println("Failure to create a workbook instance.");
            }
        } catch (FileNotFoundException e) {
            System.out.println("The Excel spreadsheet wasn't found.");
        }
        //return -1;
    }

    void test() { //This is a minature version, used to test the one address you offer as a RCD property 
        try {
            JSONObject starter = new JSONObject(URL_final.toString());
            JSONArray results = starter.getJSONArray("results");
            JSONObject temp = results.getJSONObject(0);
            String forAdd = temp.optString("formatted_address");
            System.out.println("\nLocation Found: " + forAdd);
            targetLoc = forAdd;
            JSONObject geometry = temp.getJSONObject("geometry");
            JSONObject location = geometry.getJSONObject("location");
            String lat = location.optString("lat");
            String lng = location.optString("lng");
            System.out.println("Latitude: "+lat);
            System.out.println("Longitude: "+ lng);
            Riv_lat = Float.valueOf(lat);
            Riv_lon = Float.valueOf(lng);
            addressCheck = true;
        } catch (Exception e) {
            System.out.println("Not a valid address. \nExample ideal entry: 2220 Oxford St, Berkeley, CA");
            System.out.println("The program is receptive to some guessing but it has to be coherent. Try again...");
            addressCheck = false;
        }
    }

    void coordinate_conversion() { //Will find the lat/lon from the JSON page Google offers
        try {
            JSONObject starter = new JSONObject(URL_final.toString());
            JSONArray results = starter.getJSONArray("results");
            JSONObject temp = results.getJSONObject(0);
            String forAdd = temp.optString("formatted_address");
            JSONObject geometry = temp.getJSONObject("geometry");
            JSONObject location = geometry.getJSONObject("location");
            String lat = location.optString("lat");
            String lng = location.optString("lng");
            System.out.println("Applicant: #" + (counter - 1) + " | Location: " + forAdd);
            //System.out.println("Unformatted: " + protoAddress);
            System.out.println("Latitude: " + lat);
            System.out.println("Longitude: " + lng);
            float lan = Float.valueOf(lat);
            float lon = Float.valueOf(lng);
            float meters = distance_formula(lan, lon, Riv_lat, Riv_lon);
            double miles = (meters / m);
            if (miles <= 5) {
                fiveMi++;
            } else if (miles <= 10) {
                tenMi++;
            } else if (miles <= 20) {
                twentyMi++;
            } else {
                beyondMi++;
            }

            System.out.print("Distance from RCD site: ");
            System.out.printf("%.2f", miles);
            System.out.println(" miles.");
            if (chances > 0) {
                System.out.println("Success on attempt number: " + chances);
            }
            System.out.println();
            valid++;
            chances = 0;
        } catch (Exception e) {
            if (chances == 0) {
                chances = 1;
                counter = counter - 1;
                System.out.println("\nRe-Attempt: " + (chances) + "\n");
                network(chanceURL);
                coordinate_conversion();
            } else if (chances == 1) {
                chances = 2;
                counter = counter - 1;
                System.out.println("\nRe-Attempt: " + (chances) + "\n");
                network(chanceURL);
                coordinate_conversion();
            } else if (chances == 2) {
                chances = 0;
                System.out.println("\nTotal Failure after 3 tries \nApplicant: " + counter + "\n Excel Row: " + (counter - 1));
                nValid++;
            }
            /*
            while(chances<2){
                chances++;
                System.out.println("\nAttempt: "+ (chances)+ "\n");
                network(chanceURL);
                coordinate_conversion();
            }
            if(chances==2){
                chances=0;
                System.out.println("\nTotal Failure after 3 tries \n");
                nValid++; 
            } */
        }
    }

    void proximity() { //Calculates percentage after all information has been accumulated. 
        float veryClose = ((float) fiveMi / valid) * 100;
        float close = ((float) tenMi / valid) * 100;
        float far = ((float) twentyMi / valid) * 100;
        float veryFar = ((float) beyondMi / valid) * 100;
        System.out.print("Percentage that live within 5 miles: ");
        System.out.println(String.format("%.0f%%", veryClose));
        System.out.print("Percentage that live within 10 miles: ");
        System.out.println(String.format("%.0f%%", close));
        System.out.print("Percentage that live within 20 miles: ");
        System.out.println(String.format("%.0f%%", far));
        System.out.print("Percentage that live beyond 20 miles: ");
        System.out.println(String.format("%.0f%%", veryFar));
    }

    void end() { //Stats on API reliability at the end
        System.out.println("\nSuccessful Addresses: " + valid);
        System.out.println("API Error: " + nValid);
        System.out.println("Bad address by user: " + bAdd);
        System.out.print("Error Rate/ Rejected Applicants: ");
        float errorR = (float) ((bAdd + nValid) / (bAdd + nValid + valid));
        System.out.println(String.format("%.0f%%", errorR));
        System.out.println(errorR);
    }

    void TOS() { //Information on the program provided at the start
        try {
            File file = new File("TOSRCD1.txt");
            
            FileReader fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            StringBuffer stringBuffer = new StringBuffer();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                stringBuffer.append(line);
                stringBuffer.append("\n");
            }
            fileReader.close();
            System.out.println(stringBuffer.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    void TOS2(){
        System.out.println("!This is the RCD Location Applicant Sorter!\n" +
"\n" +
"What is does: Take an Excel sheet of applicants and finds their\n" +
"distance relative to a project's site.\n" +
"\n" +
"********************************************\n" +
"*****WARNING AND INSTRUCTIONS - RCD 2018****\n" +
"********************************************\n" +
"\n" +
"Before you do anything, make sure you have: \n" +
"> The *FULL FILE PATH*\n" +
"Example of a full file path:\n" +
"C:\\Users\\darrell\\Downloads\\Riviera_pre-app_pool.xlsx\n" +
"--------------------------------------------\n" +
"Instructions for converting non-xlsl Excel document\n" +
"into xlsx \n" +
"(IF IT'S ALREADY .XLSX, SKIP TO NUMERICAL LISTED INSTRUCTONS)\n" +
"\n" +
"-Go to Excel, and open your spreadsheet. \n" +
"-Click on the left pane, \"FILE\".\n" +
"-Look down ont the side pane and click \"EXPORT\"\n" +
"-Click \"CHANGE FILE TYPE\"\n" +
"-Click \"WORKBOOK\", file type\n" +
"-Then copy that file path, not the non-.xslx \n" +
"version\n" +
"--------------------------------------------\n" +
"***************\n" +
"*Instructions *\n" +
"***************\n" +
"0) Skip this prompt about \"refreashing API keys\", it will be the very last thing and you\n" +
"probably don't need it.\n" +
"\n" +
"1) Insert the full file path when ordered below. Program\n" +
"will prompt you again if you're wrong, or the file doesn't exist.\n" +
"\n" +
"2) You will then be asked to request the amount of\n" +
"results you want. If your document has 1000 \n" +
"applicants, and you type \"10\", you will get\n" +
"the first 10 rows of applicants (assuming \n" +
"the first row is the header, 11 rows, 2-11). Pressing\n" +
"0 by default does all cells minus header.\n" +
"Regardless of how many you choose, this will finish by printing out what percentage\n" +
"of those 10 or however many inserted live within \n" +
"proximity to the site. \n" +
"\n" +
"3) You then need to insert where the project site is. \n" +
"Insert the location, preferrably by: \n" +
"[Address, Street, City, State] format, however \n" +
"the API is pretty smart and may figure it out if \n" +
"you mess up. It should return a guess, or if it can't, \n" +
"ask you again. Press yes, and this will be the program's\n" +
"basis for distance. \n" +
"\n" +
"\n" +
"\n" +
"--------------------------------------------------------\n" +
"\n" +
"Sit back and relax after this. 5,000 applicants takes\n" +
"about 30 minutes. Max amount of addresses is around 10,000, \n" +
"and it takes about an hour.\n" +
"\n" +
"Each applicant upon successful scanning of information and location will print out the following: \n" +
"-Applicant number.\n" +
"-An Address from Google.\n" +
"-Latitude & Longitutde\n" +
"-Distance from the target RCD site. \n" +
"\n" +
"This is important so that you can see it's working. The address will be more formatted than what I inserted, i.e. it'll have zipcodes, country, indicating\n" +
"Google returned this information with the bit of address I sent. Same concept happens when you insert a target site and it asks you if this address is correct. \n" +
"It may look same, but it has more info like country and zipcode for the Google API to explain to you what it specifically found. \n" +
"\n" +
"When this is done, it'll print out the following:\n" +
"\n" +
"Percentage that live within 5 miles: 42%\n" +
"Percentage that live within 10 miles: 25%\n" +
"Percentage that live within 20 miles: 16%\n" +
"Percentage that live beyond 20 miles: 18%\n" +
"\n" +
"Successful Addresses: 11578\n" +
"API Error: 146\n" +
"Bad address by user: 7\n" +
"Error percentage/Disqualified Applicants: 1%\n" +
"\n" +
"\n" +
"-------------------------------------------\n" +
"There will be two types of error addresses:\n" +
"-------------------------------------------\n" +
"\n" +
"1) \"API error\" means Google failed to find the location. Often these are random, and the\n" +
"algorithm is designed to minimize it. Because of the speed in which I'm processing applications, Google sometimes gets a brain freeze.\n" +
"When Google fails to get an address, I request it two more times.\n" +
"The program will print \"Re-Attempt 1\", \"Re-Attempt 2\" (during the 2nd attempt). If all three attempts fail,\n" +
"the program will state it failed entirely, and indicate what number applicant, and the corresponding Excel row number.\n" +
"You may check it to see what may be the issue with the address, though its likely just Google messing up.\n" +
"\n" +
"2) \"Bad Address by User\" means I couldn't even get it from the Excel spreadsheet because something was inserted incoherently.\n" +
"Commonly issues are the first column should have a full address \"1137 MLK Jr Way\", but instead only have the \"1137\" bit in column A,\n" +
"and then \"MLK Jr Way\" in column B. Really bad formmating. Keep the full address, preferrably w/o apt numbers, in Column A. The program doesn't\n" +
"attempt to re-attempt this address because its fundmentally flawed.\n" +
"---------\n" +
"3 hidden error) \"API error through limit\". Google API has a limit. A little over 2500 requests at day, i.e. 2,500 RCD applicants a day. \n" +
"I've trickled Google into sending me 4 API keys so now this program can do 10,000 applicants a day. When 10,000 is breached, it should go on for \n" +
"maybe a few more dozen if not hundred applicants or more (using Stargell test data, I was able to easily go 11,170 without error, \n" +
"but frankly it's in its own hands. I wouldn't go any further than 11,500. After a while, Google will cut of information resulting \n" +
"in numerous \"API errors\". If API errors happen repeatedly in a row, you need to stop, it mean's its reached its limit for the day.\n" +
"\n" +
"Provided you're not doing more than 11,000 requests a day, this should not happen.\n" +
"\n" +
"\n" +
"---------------------------------------------------------\n" +
"\n" +
"\n" +
"This program uses Google Geocoding API for \n" +
"Resources for Community Development, 2018. \n" +
"If outdated or repeated errors persist, send me an email at \n" +
"darrellowens225@gmail.com \n" +
"for quick troubleshooting. \n" +
"\n" +
"*********************************************************");
    }

}

public class RCD { // Main function 
    public static void main(String[] args) {
        prototype RCD = new prototype();
        
        boolean clear = true;
        String file = null;
        int x = 0;
        int row=0;
        clear=false;
        RCD.TOS2(); //Terms of Service and Instructions
        while (!clear) {
            boolean con1 = false, con2 = false, con3 = false;
            char cond = 'n';
            System.out.println("\nCOPY AND PASTE FULL PATH FILE FROM LOCAL DRIVE OF EXCEL SPREADSHEET:");
            Scanner sheet = new Scanner(System.in);
            file = sheet.nextLine();
            //Begin test
            int SIZE = file.length();
            SIZE = SIZE - 1;
            File f = new File(file);

            while (!((file.charAt(SIZE) == 'x' && file.charAt(SIZE - 1) == 's' && file.charAt(SIZE - 2) == 'l' && file.charAt(SIZE - 3) == 'x') && (f.exists()))) {
                System.out.println("Either the file isn't a .xlsx file, or its a errornous file path, or both. Make sure its a real xlsx file and try again.");
                sheet = new Scanner(System.in);
                file = sheet.nextLine();
                SIZE = file.length();
                SIZE = SIZE - 1;
                f = new File(file);
            }

            System.out.println("\nSuccess! This file has been identified.");
            //end test

            System.out.println("\nReport all applications (or cells) by pressing 0, or a particular number (choose the corresponding cell number)");
            Scanner choice = new Scanner(System.in);
            while (!choice.hasNextInt()) {
                System.out.println("That is not a number. Insert an interger.");
                choice = new Scanner(System.in);
            }
            x = choice.nextInt();

            while (cond == 'n' || cond == 'N') {
                RCD.addressCheck = false;
                while (!RCD.addressCheck) {
                    System.out.println("\nInsert the Address, City, State of this RCD Project's Location. Seperate by commas.");
                    Scanner choice1 = new Scanner(System.in);
                    String site = choice1.nextLine();
                    site = site.replaceAll(" ", "+");
                    String url_site = "https://maps.googleapis.com/maps/api/geocode/json?address=" + site + "&key=AIzaSyDj009-kXq3UjPI-B-5kd_PZ5BH8QvnuEk";
                    RCD.network(url_site);
                    RCD.test();
                }
                System.out.println("\nIs this address correct?\nPress 'y' for YES, Press 'n' for NO");
                Scanner reader = new Scanner(System.in);
                char choice2 = reader.next().charAt(0);
                cond = choice2;

                System.out.println("\n------\nReview\n------");
                System.out.println("Filename: " + file);
                System.out.println("Target Location: " + RCD.targetLoc);
                
                if (x == 0) {
                    DataFormatter formatter = new DataFormatter();
                    try {
                        FileInputStream fis = new FileInputStream(new File(file));
                        try {
                            XSSFWorkbook wb = new XSSFWorkbook(fis);
                            XSSFSheet sheet1 = wb.getSheetAt(0);
                            row = sheet1.getLastRowNum();
                            x=row;
                        } catch (IOException e) {
                            System.out.println("ERROR! Try again.");
                        }

                    } catch (FileNotFoundException e) {
                        System.out.println("ERROR! Try again, no file found.");
                    }
                } else {
                    row = x+1;
                }
                System.out.println("Prints all applicants to row #" + row);
                System.out.println("\nIf this information is correct, press 'y' key, if you want to retry, press 'n' key");
                Scanner reader2 = new Scanner(System.in);
                char choice3 = reader.next().charAt(0);
                if (choice3 == 'y' || choice3 == 'Y') {
                    clear = true;
                }
            }
        }
        //System.out.println(RCD.Riv_lat +" "+  RCD.Riv_lon);
        System.out.println("\nAwait coordinates. If program crashes or you get error statements multiple times in a row, then \nkill the program.");
        System.out.println("Addresses should print below. Occasional error statements means the address was bad or API failed. \nP.O boxes default to central city coordinates.");
        
        RCD.capture_excel(x, file);
        RCD.proximity();
        RCD.end();
    }
}
