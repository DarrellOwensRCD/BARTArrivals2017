
package FilePackage;
//Importing a .txt file and converting binary contents.
//Filepath: C:\Users\darrell\Desktop\binary.txt

import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;

class ReadFile{
    private String path;
    public ReadFile(String file_path){
        path=file_path;
    }
    public String OpenFile() throws IOException {
        FileReader FR = new FileReader(path);
        BufferedReader textReader = new BufferedReader(FR);
        
        String textData=null;
        
        textData= textReader.readLine();
        return textData;
    }
}
public class BinaryFileConv {
    public static void main(String[] args) {
        String file_name ="C:\\Users\\darrell\\Desktop\\binary.txt"; //1010101 101011 (int array)
        String file_name2= "C:\\Users\\darrell\\Desktop\\binary2.txt";// 1010101 (int)
        
        try{
            ReadFile file= new ReadFile(file_name);
            String aryLines= file.OpenFile();
            int numbers=Integer.parseInt(aryLines); //This works, but only with non-arrays!
            
        System.out.println(numbers + " "+ numbers+1);
        }
        
        catch (IOException e) {
            System.out.println(e.getMessage());
        }
        catch (NumberFormatException x){
            System.out.println ("Undoable, proceeding to print String: ");
            
            try {
            ReadFile file= new ReadFile(file_name);
            String aryLines= file.OpenFile(); 
            System.out.println(aryLines);
            }
            catch (IOException a){
                System.out.println(a.getMessage());
            }
        }
        
        finally { 
            System.out.println("Program terminated");
        }
        System.out.println("Test");
    } 
}
/*
run:
1001000 10010001
Program terminated
BUILD SUCCESSFUL (total time: 0 seconds)
*/