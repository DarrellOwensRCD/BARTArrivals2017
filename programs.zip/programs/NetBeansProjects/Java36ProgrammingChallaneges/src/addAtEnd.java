class arrayAd{
    int [] plus1;
    int add;
    arrayAd(int [] a, int b){
        plus1=a;
        add=b;     
    }   
    void newArray(){
        int length=plus1.length+1;
        int [] newArray = new int [length];
        
        for(int i=0; i<length; i++){
            if(i==length-1){
                newArray[i]=add;
            }
            else 
                newArray[i]=plus1[i];
        }
        for (int x: newArray)
            System.out.print(x+" ");
    }
    
}
public class addAtEnd {
    public static void main(String args[]) {
    int data []= {12, 13, 14, 15};
    int intx=17;
    arrayAd AE= new arrayAd(data, intx);
    
    AE.newArray();
}   
}
/*
12 13 14 15 17 BUILD SUCCESSFUL (total time: 0 seconds)
*/
