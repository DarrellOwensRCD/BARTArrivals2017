//Darrell Owens
//Java 36
//Challenge Program 1#
//4/2/2017
import static java.lang.Math.pow;
class Sphere {
    private int X, Y, Z;   //Private types
    private int radius;
   
    
    void setCoordinates (int a, int b, int c) {
    X=a;
    Y=b;
    Z=c;
    }
    void setRadius (int d){
        radius=d;
    }
    
    int getX (){
        return X;
    }
    int getY (){
        return Y;
    }
    int getZ () {
        return Z;
    }
    int getRadius(){
        return radius;
    }
    
    double CalculatingVolume (double pi){
        return (double) ((4* pi) * (pow (radius, 3)))/3;
    }
   
    double CalculatingSurfaceArea (double pi){
        return (double) ((4*pi) * (pow (radius, 2)));
    }
    
}

class SphereTester {
    public static void main( String[] args){
        Sphere testCo = new Sphere ();
        Sphere testRa= new Sphere ();
        
        double pi1=3.14;
        
        testCo.setCoordinates(10, 20, 30); //Can't reference radius or X, Y, Z 
        testRa.setRadius(5);               //Can only reference relaying methods
                                           //Because they're not private
                                           //Using co-od 10,20 30; Radius: 5                 
        System.out.println("Cordinates are...\n" + "X: " + testCo.getX());
        System.out.println("Y: " + testCo.getY() + "\nZ: " + testCo.getZ());
        System.out.println("***************************************");
        System.out.println("Volume: " + testRa.CalculatingVolume(pi1));
        System.out.println("Surface Area: " + testRa.CalculatingSurfaceArea(pi1));
        
    }
}
/*
run:
Cordinates are...
X: 10
Y: 20
Z: 30
***************************************
Volume: 523.3333333333334
Surface Area: 314.0
BUILD SUCCESSFUL (total time: 0 seconds)
*/
