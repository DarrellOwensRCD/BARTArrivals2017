//This version returns a value rather than using a void
//Both works the same.
class string2char{
    char [] charconvert(String characters, int a){
    char stringver [] = new char[a];
    
    for(int i=0; i<a; i++){
    stringver[i]= characters.charAt(i);
    }
    return stringver;
  }
}
public class CharArraytoString {
    public static void main (String[] args){
        string2char C2S= new string2char();
        String mainchrs= "Stop coding";
        int a=mainchrs.length();
        char [] mainchar=new char[a];
        mainchar=C2S.charconvert(mainchrs,a); 
        
        for (char x: mainchar){
           System.out.print(x+" "); 
        }
    }
}    
/*
S t o p   c o d i n g BUILD SUCCESSFUL (total time: 0 seconds)
*/