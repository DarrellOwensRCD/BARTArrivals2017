class toString{
    void ChartoStr(char [] b){
       String chconv= new String(b);
       System.out.println(chconv);
    }   
}
public class CharLineTester {
    public static void main (String[] args)
    throws java.io.IOException{
        toString CL= new toString();
        String mainString;
        int n=5;
        char[] a= new char[n];
        char c;
        System.out.println("Type a character: ");
        for(int i=0; i<n; i++){
            a[i]=(char)System.in.read(); 
        }
      CL.ChartoStr(a);
        
    }
}
