//Darrell Owens
//4/2/2017
//CIS 36
//Challenge Program 3
public interface TagMakerDirectory{
  void FullName();
  void Company();
  void Stars();
  void AnnualConference();
  void Spaces();
}
class TagMaker implements TagMakerDirectory {
    String name;
    String organization;
    
    TagMaker(String a, String b){
        name=a;
        organization=b;
    }
    
    public void FullName(){ 
        System.out.println(name);
    }
    public void Company(){
        System.out.println(organization);
    }
    
    public void Stars(){
        for (int i=0; i<40; i++){
            System.out.print("#");
        }
        System.out.println();
    }
    
    public void AnnualConference (){
        System.out.print("###");
        for(int k=0; k<9; k++){
            System.out.print(" ");
        }
        System.out.print("Annual Conference");
        for (int m=0; m<8; m++){
            System.out.print(" ");
        }
        System.out.println("###");
    }
    
    public void Spaces(){
    System.out.print("###");
    
        for(int n=0; n<34; n++){
            System.out.print(" ");
        }
        System.out.println("###");
    }   
}

class TagTester {
    public static void main(String[] args){
        
        String x = null, y = null;
        
        String[] name= {"Clark Kent", "Luke Skywalker", "Hank Hill", " "};
        String[] occupations= {"Daily Planet", "Rebel Alliance", "Propane Accessories", " "};
        for (int b=0; b<4; b++){
            
            x=name[b];
            y=occupations[b];

       TagMaker TT = new TagMaker (x,y); //x=name array, y=occupation array       
 
        TT.Stars(); //40 pound signs
        TT.AnnualConference(); //Header "Annual Conference", 9 spaces, 3 pound sign
        TT.Stars();
        System.out.print("### Name: ");
        TT.FullName(); //Name array object
        TT.Spaces();
        TT.Stars();
        System.out.print("### Organization: " );
        TT.Company(); //Occupation array object
        TT.Spaces();
        TT.Stars();
        System.out.println(" ");
        }
    }
}
/*
run:
########################################
###         Annual Conference        ###
########################################
### Name: Clark Kent
###                                  ###
########################################
### Organization: Daily Planet
###                                  ###
########################################
 
########################################
###         Annual Conference        ###
########################################
### Name: Luke Skywalker
###                                  ###
########################################
### Organization: Rebel Alliance
###                                  ###
########################################
 
########################################
###         Annual Conference        ###
########################################
### Name: Hank Hill
###                                  ###
########################################
### Organization: Propane Accessories
###                                  ###
########################################
 
########################################
###         Annual Conference        ###
########################################
### Name:  
###                                  ###
########################################
### Organization:  
###                                  ###
########################################
 
BUILD SUCCESSFUL (total time: 2 seconds)
*/
