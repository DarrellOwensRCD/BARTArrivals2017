class arrayAdd{
int size;

    void insert(int [] data1, int y, int idy){
        size=data1.length+1;
        int [] obArray= new int[size];
        
        
        
        for(int i=0; i<4; i++){
            if(i==idy){
                obArray[i]=y;
            }
            else
                obArray[i]=data1[i];
        }
        for (int l=0; l<size; l++){
            if(obArray[l]==0 && obArray[idy-1]==data1[idy-1]){
                obArray[l]=data1[idy];
            }    
        }
        for (int print: obArray)
            System.out.print(print+" ");
    }
    
}
public class ReplaceAtIndex {
    public static void main(String args[]) {
    arrayAdd AE= new arrayAdd ();
    int data []= {12, 13, 14, 15};
    int x=17;
    int idx=3;
    AE.insert(data, x, idx); 
    }     
}
/*
12 13 14 17 15 BUILD SUCCESSFUL (total time: 0 seconds)
*/
