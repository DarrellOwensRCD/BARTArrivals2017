class PersonFinalVer{ 
    String firstName;
    String lastName;
    String attribute;
    static int z;
    int q;
    
    PersonFinalVer(String firstName, String lastName, int q){
        this.firstName=firstName;
        this.lastName=lastName;
        this.q=q;
    }
    PersonFinalVer (String temp){
        attribute=temp;
    }
 public String toString(){
    return lastName+ " "+ firstName + " "+ (q+z);
}
void AttrOut(){
    System.out.println("    " + attribute );
    }
}
public class PersonTesterFinalVer {
    public static void main (String[] args){
    
    String x=null; 
    String y=null;
    String w=null;
    String[] employeesF = {"Fox", "Samus", "Master", "Captain"};
    String[] employeesL = {"McCloud", "Aran", "Hand", "Falcon"};
    String[] attributes= {"Good leader. Everyone mains.", "Difficult to work with, in melee", "Mysterious, but overrated", "Top tier employee."};
    Person.z=1000;
    int d;
    
    System.out.println("Name:     ID no:       Attributes: " + "\n"+ "-----------------------------");
    for(int i=0; i<4; i++)
    {
        x=employeesF[i];
        y=employeesL[i];
        w=attributes[i];
        d=i;

    PersonFinalVer Name = new PersonFinalVer(x, y, d);
    PersonFinalVer Attr = new PersonFinalVer(w);
   
    System.out.print(Name);
    Attr.AttrOut();
    
        }
    }  
}
/*
run:
Name:     ID no:       Attributes: 
-----------------------------
McCloud Fox 1000    Good leader. Everyone mains.
Aran Samus 1001    Difficult to work with, in melee
Hand Master 1002    Mysterious, but overrated
Falcon Captain 1003    Top tier employee.
BUILD SUCCESSFUL (total time: 0 seconds)

*/
