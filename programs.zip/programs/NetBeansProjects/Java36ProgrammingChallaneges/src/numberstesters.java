class numbers{
  void remove(int [] data, int idx1) {
    int a=data.length;
    int [] newdata=new int[a];
    int [] newdata1=new int[a-1];
    for (int i=0; i<newdata.length; i++){
      if (i==idx1)
        newdata[i]=0;
      else
        newdata[i]=data[i];
     
    }
    int m=0, n=0;
    
    while (m<newdata.length-1){
        if (newdata[m]==0) m++;
        
        newdata1[n]=newdata[m];
        m++;
        n++;
    }
    
    for (int x=0; x<newdata1.length; x++){
        System.out.print(newdata1[x]+ " ");
    }
    }
  }

public class numberstesters{
  public static void main (String[] args){
    numbers NT= new numbers();
    int [] holder2=new int[4];
    int idx=2;
    int [] data1= {10, 12, 13, 14};
    
    
   NT.remove(data1, idx);
    }
  }
/*
10 12 14 BUILD SUCCESSFUL (total time: 0 seconds)
*/
    