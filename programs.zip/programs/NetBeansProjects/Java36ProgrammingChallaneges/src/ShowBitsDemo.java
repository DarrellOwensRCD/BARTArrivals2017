class BitOut { 
  			int numBits; // number of bits to display
  			
  
              BitOut(int n) { 
                if(n < 1) n = 1; 
                if(n > 64) n = 64; 
                numBits = n; } // Display the sequence of bits. 
              
              void showBits(long val) { 
                long mask = 1; // left-shift a 1 into the proper position 
                mask <<= numBits-1; 
                int spacer = 8 - (numBits % 8); 
                String [] strconv=null;
                for(; mask != 0; mask >>>= 1) { 
                  if((val & mask) != 0) 
                    System.out.print("1"); 
                  
                  else System.out.print("0"); 
                  spacer++; 
                  
                  if((spacer % 8) == 0) { 
                    System.out.print(" "); 
                    spacer = 0; 
                  } 
                } 
                System.out.println();
                
              } //Place return here.
             } // Demonstrate showBits(). 
public class ShowBitsDemo { 
  public static void main(String[] args) {
    
    BitOut b = new BitOut(8); 
    BitOut i = new BitOut(32); 
    BitOut li = new BitOut(64); 
    System.out.println("123 in binary: "); 
    
    b.showBits(123); 
    System.out.println("\n87987 in binary: "); 
    i.showBits(87987); 
    System.out.println("\n237658768 in binary: "); 
    li.showBits(237658768); // you can also show low-order bits of any integer 
    
    System.out.println("\nLow order 8 bits of 87987 in binary: "); 
    b.showBits(87987); 
  } 
}

