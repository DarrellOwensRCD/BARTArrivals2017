public class ArrayGames{
public static void main(String[] args) { 
    
    int SIZE=50;
    double[] array= new double[SIZE];
    double n=0;
    for (int i=0; i<SIZE; i++){
        
      n+=2;
      array[i]=Math.pow(2, 1/n);  
    }
    
    for(int k=0; k<SIZE; k++)
    {
        n+=2;
        array[k]=n;
    }
    
    
    for (double x : array)
    {
        n+=2;
       
        System.out.println("2 ^ 1/"+n+"  "+ x);
    }
        
  } 
} 