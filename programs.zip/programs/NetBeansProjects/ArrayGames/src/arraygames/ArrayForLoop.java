/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraygames;

import java.util.Random;

/**
 *
 * @author Owner
 */
public class ArrayForLoop {
    public static void main(String[] args) {
    Random rand = new Random();
    int SIZE=20; 
    int [] array =new int[SIZE];
        for (int i=1; i<11; i++) //Using for-loop
            {
            System.out.println(" ");
            System.out.print(i+ " ");
            
             for (int k=0; k<SIZE; k++) //Using for-loop
            {
                array[k]=rand.nextInt(6)+1;
                System.out.print( array[k]);
                array[k]++;
            }     
                
           }    
    }
    
}
