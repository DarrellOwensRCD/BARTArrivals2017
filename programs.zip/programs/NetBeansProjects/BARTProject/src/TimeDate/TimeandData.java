package TimeDate;
import java.util.*;
public class TimeandData{
    public void PrintCalander() { 
    Locale locale1 = Locale.US;
    TimeZone tz1=  TimeZone.getTimeZone("PST");
    Calendar cal1 = Calendar.getInstance(tz1, locale1);
    
    System.out.println("Current, as of: "+ cal1.getTime());
}
}
class Chapter24LocalTimeLang {
    public static void main(String[] args) {
        Locale defLocale= Locale.getDefault();
        TimeandData PC= new TimeandData();
        
        System.out.println("Name: " + defLocale.getDisplayName());
        System.out.println("Country: " + defLocale.getDisplayCountry());
        
        //Manual creation of locale for China
        Locale chinaLocale = new Locale("cn", "CN");
        System.out.println("Country: " + chinaLocale.getDisplayCountry());
        
        //automatic
        System.out.println("Language: "+ Locale.FRANCE.getDisplayName());
        
        //data
        PC.PrintCalander();
    } 
}
/*
run:
Name: English (United States)
Country: United States
Country: China
Language: French (France)
Print: Tue May 16 16:38:44 PDT 2017 Canada PST
BUILD SUCCESSFUL (total time: 0 seconds)
*/