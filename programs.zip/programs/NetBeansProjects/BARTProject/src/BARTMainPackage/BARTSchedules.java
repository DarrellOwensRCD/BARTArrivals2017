//Placeholder 
package BARTMainPackage;
import TimeDate.TimeandData;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;
import java.util.TimeZone;
import java.util.Date;

class BARTArrivals1{
    static String [] timeTable5={"5:03", "5:10", "5:18", "5:25", "5:33", "5:40", "5:48", "5:55"};
    static String [] timeTable6={"6:03", "6:10", "6:18", "6:25", "6:33", "6:40", "6:48", "6:55"};
    static String [] timeTable7={"7:03", "7:10", "7:18", "7:25", "7:33", "7:40", "7:48", "7:55"};
    SimpleDateFormat timeFor= new SimpleDateFormat("HH:mm");


   //test starts
    void Hr5(int hr, int min){
        //Have a program that can sort the closest number given from "min" in the static array
        //Place here
        //Consider placing times in main and then converting into date-types, then processing calculations in a method.
        Date TT5D = null;
        long x;
        try{
             //Time transfers correctly! Goal: Recieve time information, find nearest, and subsititute highest value
             //Next, find way to convert scanner input into long type for calculations!
             //re-insert for-loop if need be
             for (int i=0; i<timeTable5.length; i++)
                TT5D=timeFor.parse(timeTable5[i]);
                x=TT5D.getTime();
                
                String date3 = timeFor.format(new Date(x));

              System.out.println("Next train in: " + date3);
        }
        catch (ParseException e){
            System.out.print("Failure");
            e.printStackTrace();
        }
        finally{
            System.out.println("Success!");
        }
        System.out.println("This is the BART Timetable during this hour: ");
        for (int i=0; i<timeTable5.length; i++){
            System.out.println(timeTable5[i]);
        }
    }
    //test block
    void Hr6(int hr, int x){
        
    }
    void Hr7(int hr, int x){
        
    }
}
  
public class BARTSchedules {
    public static void main (String[] args){
       TimeandData CT= new TimeandData();
       BARTArrivals1 BA= new BARTArrivals1();
       Scanner scanner = new Scanner(System.in);

        int hour, minute;
        System.out.println("Insert current hour: ");
        hour=scanner.nextInt();
        System.out.println("Insert current minute: ");
        minute=scanner.nextInt();
        
        switch(hour) {
            case 5: BA.Hr5(hour, minute);
            case 6: BA.Hr6(hour, minute);
            case 7: BA.Hr7(hour, minute);
        }
        
        CT.PrintCalander();
    }  
}
