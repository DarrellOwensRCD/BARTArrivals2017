/*
-RCD Project-
 
-Task 2: Ensure last cell number is stated
-Task 3: Make into program, give to RCD
 */
package appCreate;

import org.apache.poi.ss.usermodel.DataFormatter;
import java.io.BufferedReader; //Web Request Data
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner; //API scanner
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.json.JSONArray; //Language of API
import org.json.JSONObject;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import java.io.File;

class prototype {

    int valid = 0, nValid = 0, bAdd = 0, counter = 0, counter1 = 0; //Class variables to be used as counters
    int fiveMi = 0, tenMi = 0, twentyMi = 0, beyondMi = 0;        //and also check marks for executable structures to occur
    boolean addressCheck = true;
    StringBuffer URL_final;
    String protoAddress;
    String protoCity;
    String protoState;
    String chanceURL;
    String targetLoc;
    float Riv_lat; //Insert lat/long on the project site
    float Riv_lon;
    double m = 1609.344;
    int chances = 0;

    float distance_formula(float lat1, float lng1, float lat2, float lng2) { //This calculates the distance
        double earthRadius = 6371000; //meters
        double dLat = Math.toRadians(lat2 - lat1);
        double dLng = Math.toRadians(lng2 - lng1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(dLng / 2) * Math.sin(dLng / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        float dist = (float) (earthRadius * c);

        return dist;
    }

    void network(String url) {//This function will take the string url and connect it to the Internet.
        try {                 //Any failure here likely means your Internet connection is down or unavailable. 
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            int responseCode = con.getResponseCode();
            //System.out.println("\nSending 'GET' request to URL: " + url);
            //System.out.println("Response Code: " + responseCode);
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            URL_final = response;

        } catch (Exception e) {
            System.out.println("Network Error");

        }
        counter++;
        counter1++;
    }

    void url_constructor(String a, String b, String c) { //Cheating google by swapping numerous api-keys
        //Should work for up to 10,000 applicants, give a few hundred more
        String API_KEY = "AIzaSyDj009-kXq3UjPI-B-5kd_PZ5BH8QvnuEk";
        String API_KEY2 = "AIzaSyByBwSbuq_SQnMLyQpLGsoqNQzy5-PRXBA";
        String API_KEY3 = "AIzaSyAsMLHAmUUM99P36-vwWoQ1IhW_bgJ3OKY";
        String API_Key4 = "AIzaSyD2iLH3DrTOS2FCQBzvMEz_vE0yNZB4DQM";
        String API_KEY5 = "AIzaSyCm-wY3pdv7QFylLKfvQJa055_689ux-OY";
        String API = "";
        if (counter1 < 2500) {
            API = API_KEY;
            //System.out.println(early_url);
            //network(early_url);
        } else if (counter1 < 5000) {
            API = API_KEY2;
            //System.out.println(early_url);
            //network(early_url);
        } else if (counter1 < 7500) {
            API = API_Key4;
        } else if (counter1 < 10000) {
            API = API_KEY3;
        } else if (counter1 < 12500) {
            API = API_KEY5;
        }

        String early_url = "https://maps.googleapis.com/maps/api/geocode/json?address=" + a + ",+" + b + ",+" + c + "&key=" + API;
        //System.out.println(early_url);
        chanceURL = early_url;
        network(early_url);
        coordinate_conversion();
    }

    void formatter() {
        //Preparing each word to be address eligible 
        //Find white spaces and replaces with URL-mandated plus signs
        protoAddress = protoAddress.replaceAll(" ", "+");
        protoCity = protoCity.replaceAll(" ", "+");
        protoState = protoState.replaceAll(" ", "+");
        /* System.out.print(protoAddress+ " ");
       System.out.print(protoCity+ " ");
       System.out.println(protoState); */
        url_constructor(protoAddress, protoCity, protoState);
    }

    void capture_excel(int choice, String iFile) { //Excel function that captures information from a .xlsl document, *provided*
        //the first row is a title, and the 2nd row onwards are addresses
        DataFormatter formatter = new DataFormatter();

        try {
            FileInputStream fis = new FileInputStream(new File(iFile));
            try {
                XSSFWorkbook wb = new XSSFWorkbook(fis);

                XSSFSheet sheet = wb.getSheetAt(0);
                //System.out.println("This program will finish the last row cell: "+ sheet.getLastRowNum()+ "\nIs this correct?");
                //Start here
                for (int i = 1; i <=choice; i++) { //Set iterations here. First row is title.
                    try {
                        Row row = sheet.getRow(i);
                        org.apache.poi.ss.usermodel.Cell address = row.getCell(0);
                        org.apache.poi.ss.usermodel.Cell city = row.getCell(2);
                        org.apache.poi.ss.usermodel.Cell state = row.getCell(3);
                        protoAddress = address.getStringCellValue();
                        protoCity = city.getStringCellValue();
                        protoState = state.getStringCellValue();
                        formatter();
                    } catch (java.lang.IllegalStateException e) {
                        System.out.println("\nBad address format, couldn't use Applicant #" + (counter) + "\nSpreadsheet Location: Row " + (counter + 1) + ", Column A." + "\n");
                        counter++;
                        bAdd++;
                    }
                }
                //return sheet.getLastRowNum();
            } catch (IOException ex) {
                System.out.println("Failure to create a workbook instance.");
            }
        } catch (FileNotFoundException e) {
            System.out.println("The Excel spreadsheet wasn't found.");
        }
        //return -1;
    }

    void test() { //This is a minature version, used to test the one address you offer as a RCD property 
        try {
            JSONObject starter = new JSONObject(URL_final.toString());
            JSONArray results = starter.getJSONArray("results");
            JSONObject temp = results.getJSONObject(0);
            String forAdd = temp.optString("formatted_address");
            System.out.println("\nLocation Found: " + forAdd);
            targetLoc = forAdd;
            JSONObject geometry = temp.getJSONObject("geometry");
            JSONObject location = geometry.getJSONObject("location");
            String lat = location.optString("lat");
            String lng = location.optString("lng");
            System.out.println("Latitude: "+lat);
            System.out.println("Longitude: "+ lng);
            Riv_lat = Float.valueOf(lat);
            Riv_lon = Float.valueOf(lng);
            addressCheck = true;
        } catch (Exception e) {
            System.out.println("Not a valid address. \nExample ideal entry: 2220 Oxford St, Berkeley, CA");
            System.out.println("The program is receptive to some guessing but it has to be coherent. Try again...");
            addressCheck = false;
        }
    }

    void coordinate_conversion() { //Will find the lat/lon from the JSON page Google offers
        try {
            JSONObject starter = new JSONObject(URL_final.toString());
            JSONArray results = starter.getJSONArray("results");
            JSONObject temp = results.getJSONObject(0);
            String forAdd = temp.optString("formatted_address");
            JSONObject geometry = temp.getJSONObject("geometry");
            JSONObject location = geometry.getJSONObject("location");
            String lat = location.optString("lat");
            String lng = location.optString("lng");
            System.out.println("Applicant: #" + (counter - 1) + " | Location: " + forAdd);
            //System.out.println("Unformatted: " + protoAddress);
            System.out.println("Latitude: " + lat);
            System.out.println("Longitude: " + lng);
            float lan = Float.valueOf(lat);
            float lon = Float.valueOf(lng);
            float meters = distance_formula(lan, lon, Riv_lat, Riv_lon);
            double miles = (meters / m);
            if (miles <= 5) {
                fiveMi++;
            } else if (miles <= 10) {
                tenMi++;
            } else if (miles <= 20) {
                twentyMi++;
            } else {
                beyondMi++;
            }

            System.out.print("Distance from RCD site: ");
            System.out.printf("%.2f", miles);
            System.out.println(" miles.");
            if (chances > 0) {
                System.out.println("Success on attempt number: " + chances);
            }
            System.out.println();
            valid++;
            chances = 0;
        } catch (Exception e) {
            if (chances == 0) {
                chances = 1;
                counter = counter - 1;
                System.out.println("\nRe-Attempt: " + (chances) + "\n");
                network(chanceURL);
                coordinate_conversion();
            } else if (chances == 1) {
                chances = 2;
                counter = counter - 1;
                System.out.println("\nRe-Attempt: " + (chances) + "\n");
                network(chanceURL);
                coordinate_conversion();
            } else if (chances == 2) {
                chances = 0;
                System.out.println("\nTotal Failure after 3 tries \nApplicant: " + counter + "\n Excel Row: " + (counter - 1));
                nValid++;
            }
            /*
            while(chances<2){
                chances++;
                System.out.println("\nAttempt: "+ (chances)+ "\n");
                network(chanceURL);
                coordinate_conversion();
            }
            if(chances==2){
                chances=0;
                System.out.println("\nTotal Failure after 3 tries \n");
                nValid++; 
            } */
        }
    }

    void proximity() { //Calculates percentage after all information has been accumulated. 
        float veryClose = ((float) fiveMi / valid) * 100;
        float close = ((float) tenMi / valid) * 100;
        float far = ((float) twentyMi / valid) * 100;
        float veryFar = ((float) beyondMi / valid) * 100;
        System.out.print("Percentage that live within 5 miles: ");
        System.out.println(String.format("%.0f%%", veryClose));
        System.out.print("Percentage that live within 10 miles: ");
        System.out.println(String.format("%.0f%%", close));
        System.out.print("Percentage that live within 20 miles: ");
        System.out.println(String.format("%.0f%%", far));
        System.out.print("Percentage that live beyond 20 miles: ");
        System.out.println(String.format("%.0f%%", veryFar));
    }

    void end() { //Stats on API reliability at the end
        System.out.println("\nSuccessful Addresses: " + valid);
        System.out.println("API Error: " + nValid);
        System.out.println("Bad address by user: " + bAdd);
        System.out.print("Error Rate/ Rejected Applicants: ");
        float errorR = (float) ((bAdd + nValid) / (bAdd + nValid + valid));
        System.out.println(String.format("%.0f%%", errorR));
    }

    void TOS() { //Information on the program provided at the start
        try {
            File file = new File("TOSRCD1.txt");
            FileReader fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            StringBuffer stringBuffer = new StringBuffer();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                stringBuffer.append(line);
                stringBuffer.append("\n");
            }
            fileReader.close();
            System.out.println(stringBuffer.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

public class RCD { // Main function 

    public static void main(String[] args) {
        prototype RCD = new prototype();
        boolean clear = true;
        String file = null;
        int x = 0;
        int row=0;
        clear=false;
        RCD.TOS(); //Terms of Service and Instructions
        while (!clear) {
            boolean con1 = false, con2 = false, con3 = false;
            char cond = 'n';
            System.out.println("\nCOPY AND PASTE FULL PATH FILE FROM LOCAL DRIVE OF EXCEL SPREADSHEET:");
            Scanner sheet = new Scanner(System.in);
            file = sheet.nextLine();
            //Begin test
            int SIZE = file.length();
            SIZE = SIZE - 1;
            File f = new File(file);

            while (!((file.charAt(SIZE) == 'x' && file.charAt(SIZE - 1) == 's' && file.charAt(SIZE - 2) == 'l' && file.charAt(SIZE - 3) == 'x') && (f.exists()))) {
                System.out.println("Either the file isn't a .xlsx file, or its a errornous file path, or both. Make sure its a real xlsx file and try again.");
                sheet = new Scanner(System.in);
                file = sheet.nextLine();
                SIZE = file.length();
                SIZE = SIZE - 1;
                f = new File(file);
            }

            System.out.println("\nSuccess! This file has been identified.");
            //end test

            System.out.println("\nReport all applications (or cells) by pressing 0, or a particular number (choose the corresponding cell number)");
            Scanner choice = new Scanner(System.in);
            while (!choice.hasNextInt()) {
                System.out.println("That is not a number. Insert an interger.");
                choice = new Scanner(System.in);
            }
            x = choice.nextInt();

            while (cond == 'n' || cond == 'N') {
                RCD.addressCheck = false;
                while (!RCD.addressCheck) {
                    System.out.println("\nInsert the Address, City, State of this RCD Project's Location. Seperate by commas.");
                    Scanner choice1 = new Scanner(System.in);
                    String site = choice1.nextLine();
                    site = site.replaceAll(" ", "+");
                    String url_site = "https://maps.googleapis.com/maps/api/geocode/json?address=" + site + "&key=AIzaSyDj009-kXq3UjPI-B-5kd_PZ5BH8QvnuEk";
                    RCD.network(url_site);
                    RCD.test();
                }
                System.out.println("\nIs this address correct?\nPress 'y' for YES, Press 'n' for NO");
                Scanner reader = new Scanner(System.in);
                char choice2 = reader.next().charAt(0);
                cond = choice2;

                System.out.println("\n------\nReview\n------");
                System.out.println("Filename: " + file);
                System.out.println("Target Location: " + RCD.targetLoc);
                
                if (x == 0) {
                    DataFormatter formatter = new DataFormatter();
                    try {
                        FileInputStream fis = new FileInputStream(new File(file));
                        try {
                            XSSFWorkbook wb = new XSSFWorkbook(fis);
                            XSSFSheet sheet1 = wb.getSheetAt(0);
                            row = sheet1.getLastRowNum();
                        } catch (IOException e) {
                            System.out.println("ERROR! Try again.");
                        }

                    } catch (FileNotFoundException e) {
                        System.out.println("ERROR! Try again, no file found.");
                    }
                } else {
                    row = x+1;
                }
                System.out.println("Prints all applicants to row #" + row);
                System.out.println("\nIf this information is correct, press 'y' key, if you want to retry, press 'n' key");
                Scanner reader2 = new Scanner(System.in);
                char choice3 = reader.next().charAt(0);
                if (choice3 == 'y' || choice3 == 'Y') {
                    clear = true;
                }
            }
        }
        //System.out.println(RCD.Riv_lat +" "+  RCD.Riv_lon);
        System.out.println("\nAwait coordinates. If program crashes or you get error statements multiple times in a row, then \nkill the program.");
        System.out.println("Addresses should print below. Occasional error statements means the address was bad or API failed. \nP.O boxes default to central city coordinates.");
        
        RCD.capture_excel(x, file);
        RCD.proximity();
        RCD.end();
    }
}
