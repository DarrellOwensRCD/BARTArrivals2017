package appCreate;
//Darrell Owens PROJECT CIS 27 5/13/2018
//

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import javax.swing.JFrame;
import org.json.JSONArray;
import org.json.JSONObject;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;

class URL_class {
    
    boolean Directional_Condition=false;
    int FINALGLOBE = 0;
    int midpoint=0;
    String centerscn;
    String bartpt1;
    String bartpt2;
    String globalTEST=null;
    String globalCOLOR = null;
    String globalROUTE = null;
    String tempBARTLines;
    StringBuffer URL_final;
    String latitude, longitude, lat2, lon2;
    String geoAPI = "AIzaSyDj009-kXq3UjPI-B-5kd_PZ5BH8QvnuEk";
    String gMapAPI = "AIzaSyB_5Js3iCys-RouXPQ4XJesXW0woigjzv0";
    String geoCodeAPI = "AIzaSyDj009-kXq3UjPI-B-5kd_PZ5BH8QvnuEk";
    int globalSIZE;
    String busRouteURL;
    int busCHECK;
    int bartCHECK = 0;
    int BARTMapCheck = 0;
    String busPt1;
    String busPt2;
    String tempBusSTOP = null;
    String tempBusStopChoiceMarker;
    String bartDirZoomCenter;
    //Relaying to Bart direction map
    String Start[] = null;
    String End[] = null;
    String Route[] = null;
    int dirSIZE;
    //Ending
    HashMap<String, String> BARTD = new HashMap<String, String>(); //Convert stns to lat/long
    String agencies() {
        System.out.println("Transit agency list: ");
        String agency_url = "http://webservices.nextbus.com/service/publicJSONFeed?command=agencyList";
        network(agency_url);
        try {
            JSONObject agency_s = new JSONObject(URL_final.toString());
            JSONArray agency = agency_s.getJSONArray("agency");
            for (int i = 0; i < agency.length(); i++) {
                JSONObject subA = agency.getJSONObject(i);
                String titles = subA.optString("title");
                System.out.println((i + 1) + " " + titles);
            }
            Scanner select1 = new Scanner(System.in);
            int select = select1.nextInt();
            JSONObject subA = agency.getJSONObject(select - 1);
            String agencyCho = subA.optString("tag");
            return agencyCho;
        } catch (Exception a) {
            System.out.println("Error in the agency");
            return null;
        }

    }

    /*Station stops by line*/    void progress_bar(String temp_route, String start_stn, String end_stn) {

        char[] new_array;
        new_array = temp_route.toCharArray();
        new_array[5] = '=';
        String route = new String(new_array);
        String url = "http://api.bart.gov/api/route.aspx?cmd=routeinfo&" + route + "&key=MW9S-E7SL-26DU-VV8V&json=y";
        globalROUTE = route;
        network(url);
        //constructing polygon START
        String APIS;
        try {
            JSONObject page_c = new JSONObject(URL_final.toString());
            JSONObject root_c = page_c.getJSONObject("root");
            JSONObject routes_c = root_c.getJSONObject("routes");
            JSONObject route_c = routes_c.getJSONObject("route");
            JSONObject config_c = route_c.getJSONObject("config");
            JSONArray stn_c = config_c.getJSONArray("station");
            
            String train_line = route_c.optString("color");
            String hex = route_c.optString("hexcolor");
            System.out.println("----------");
            System.out.println(train_line + "-line");
            globalCOLOR = hex;
            String index = null;
            int m = 0;
            int n = 0;
            int starti, endi;
            while (!start_stn.equals(index)) {
                index = stn_c.getString(m);
                m++;
            }

            while (!end_stn.equals(index)) {
                index = stn_c.getString(n);
                n++;
            }
            starti = m;
            endi = n - 1;
            int stops = ((endi - starti) + 1);
            //Poly const
            APIS=("|" + translatorBART(start_stn)+"|");
            //end
            if (stops == 0) {
                System.out.println("The next stop is your destination stop.");
            } 
           else {
                System.out.println(stops + " stops.");
                System.out.println("----------");
                midpoint=endi/2;
               for (int i = starti; i <= endi; i++) {
                    if (i == endi) {
                        String station = stn_c.getString(i);
     
                        System.out.println("--> " + translator(station));
                        APIS+=(translatorBART(end_stn));
                    } else {
                        String station = stn_c.getString(i);
                        System.out.println((i - (starti - 1)) + ". " + translator(station));
                        APIS+=(translatorBART(station)+ "|");
                    }
                } 
            } 
            //Find 
            String polyColor=globalCOLOR.replaceAll("#", "x");
            String partialPath="&size=900x612&path=color:0"+ polyColor +"|weight:7"+APIS;
            bartDirZoomCenter="https://maps.googleapis.com/maps/api/staticmap?center="+translatorBART(start_stn)+"&zoom=";
            if(globalTEST==null){
                globalTEST=partialPath; //line up of polygons 
            }
            else{
               globalTEST+=partialPath; 
            }
            
        } catch (Exception e) {
            System.out.println("Failure in the progress bar method");
        }

    }

    /*Provides directions*/    void direction_url() {
        try {
            System.out.println("This is a directional system. Starting station...");
            String stn_1, stn_2;
            stn_1 = stn_dictionary(); //Prints list of statiojs
            System.out.println("Ending station...");
            stn_2 = stn_dictionary(); //Prints list of stations and returns abbreviations
            System.out.println("What time of departue: ");
            Scanner input = new Scanner(System.in);
            String time = input.nextLine();
            String url = "http://api.bart.gov/api/sched.aspx?cmd=depart&orig=" + stn_1 + "&dest=" + stn_2 + "&date=" + time + "&key=MW9S-E7SL-26DU-VV8V&b=0&a=1&l=1&json=y";

            network(url); //Prepares url to be connected to the internet, assigned class variable URL_final
            //System.out.println(URL_final.toString());
            JSONObject page_c = new JSONObject(URL_final.toString());
            JSONObject root_c = page_c.getJSONObject("root");
            JSONObject sch_c = root_c.getJSONObject("schedule");
            JSONObject req_c = sch_c.getJSONObject("request");

            System.out.println("--------------------------------------------");
            System.out.println("Starting Station: " + translator(root_c.optString("origin")));
            System.out.println("--------------------------------------------");
            JSONObject trip_c = req_c.getJSONObject("trip");

            String time_dur = trip_c.optString("@tripTime");
            System.out.println("Trip time: " + time_dur + " minutes.");
            System.out.println("Arrive at: " + sch_c.optString("time"));
            JSONArray leg_c = trip_c.getJSONArray("leg");
            //Making map arrays
            Start = new String[leg_c.length()];
            End = new String[leg_c.length()];
            Route = new String[leg_c.length()];
            //end
            for (int i = 0; i < leg_c.length(); i++) {
                JSONObject legc_c = leg_c.getJSONObject(i);
                System.out.println("---------");
                System.out.println(legc_c.optString("@origTimeMin"));
                System.out.println("---------");
                System.out.println("Board the " + translator(legc_c.optString("@trainHeadStation")) + "-bound train.");

                //System.out.println(legc_c.optString("@line")); //This is temporary, used to construct progress bar for line
                String line = legc_c.optString("@line");
                String s = legc_c.optString("@origin");
                String e = legc_c.optString("@destination");

                progress_bar(line, s, e);
                Start[i] = s;
                End[i] = e;
                Route[i] = line;
                dirSIZE = leg_c.length();
                System.out.println("---------");
                System.out.println(legc_c.optString("@destTimeMin"));
                System.out.println("---------");
                System.out.println("Depart from the train at " + translator(legc_c.optString("@destination")));
                String transfer = legc_c.optString("@transfercode");
                if (transfer.equals("T") || transfer.equals("S")) {
                    System.out.println("Wait on the platform for the timed transfer.");
                } else if (transfer.equals("N")) {
                    System.out.println("Wait on the platform for your transfer train.");
                }
                
            }
            System.out.println("----------------------------------------------------------");

        } catch (Exception c) {
            System.out.println("Failure in the directional method");
        }
    }

    /*parses all urls*/    void network(String url) {
        try {
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            int responseCode = con.getResponseCode();
            //System.out.println("\nSending 'GET' request to URL: " + url);
            //System.out.println("Response Code: " + responseCode);
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            URL_final = response;
        } catch (Exception e) {
            System.out.println("Failure in the network");
        }
    }

    /*Full stn name from abbr.*/    String translator(String abb_stn) {
        try {
            String url = "http://api.bart.gov/api/stn.aspx?cmd=stns&key=MW9S-E7SL-26DU-VV8V&json=y";
            network(url);
            JSONObject stn_list = new JSONObject(URL_final.toString());
            //System.out.println(stn_list);
            JSONObject stn_root = stn_list.getJSONObject("root");
            JSONObject stn_stns = stn_root.getJSONObject("stations");
            JSONArray stn_stn = stn_stns.getJSONArray("station");
            String stn_index = null;
            String full_name = null;
            int i = 0;
            while (!abb_stn.equals(stn_index)) {
                JSONObject name_ob = stn_stn.getJSONObject(i);
                stn_index = name_ob.optString("abbr");
                //System.out.print(stn_index);
                i++;
            }
            JSONObject final_name = stn_stn.getJSONObject(i - 1);
            full_name = final_name.optString("name");

            return full_name;
        } catch (Exception e) {
            System.out.println("Failure in the translator");
            return null;
        }
    }

    /*Station select*/    String stn_dictionary() {
        try {
            Scanner input = new Scanner(System.in);
            String url = "http://api.bart.gov/api/stn.aspx?cmd=stns&key=MW9S-E7SL-26DU-VV8V&json=y";
            network(url);
            JSONObject stn_list = new JSONObject(URL_final.toString());
            JSONObject stn_root = stn_list.getJSONObject("root");
            JSONObject stn_stns = stn_root.getJSONObject("stations");
            JSONArray stn_stn = stn_stns.getJSONArray("station");

            System.out.println("Choose station: ");

            for (int i = 0; i < stn_stn.length(); i++) {
                JSONObject name_ob = stn_stn.getJSONObject(i);
                String stn_fullName = name_ob.optString("name");
                System.out.println((i + 1) + " " + stn_fullName);
            }

            int stn_choice = input.nextInt();
            JSONObject name_abb1 = stn_stn.getJSONObject(stn_choice - 1);
            String name_abb2 = name_abb1.optString("abbr");
            //System.out.println("Your choice: " + name_abb2);
            return name_abb2;
        } catch (Exception b) {
            System.out.println("Error in the stn_dictionary method");
            return null;
        }
    }

    /*Partial BART map print*/
    void BARTHashMap(){ //call this at the start of the program, once
         //map to hold bart abbreviations as keys, and formatted lat,long as values
        String url = "http://api.bart.gov/api/stn.aspx?cmd=stns&key=MW9S-E7SL-26DU-VV8V&json=y";
        network(url);
        try{
            String mapPage=URL_final.toString(); //Copy the entire page
            JSONObject root1 = new JSONObject(mapPage);
            JSONObject stns1=root1.getJSONObject("root");
            JSONObject stn1=stns1.getJSONObject("stations");
            JSONArray arr1=stn1.getJSONArray("station");
            for(int i=0; i<arr1.length(); i++){
                JSONObject LL = arr1.getJSONObject(i);
                String LatSTN=LL.optString("gtfs_latitude");
                String LonSTN=LL.optString("gtfs_longitude");
                String abbSTN=LL.optString("abbr");
                String finalLL=LatSTN +","+ LonSTN;
                BARTD.put(abbSTN, finalLL);
            }
           
        }
        catch(Exception e){
            System.out.println("Failure to capture dictionary of stations.");
        }
    }
    String translatorBART(String abbr){
            String result= BARTD.get(abbr);
            return result;
   
    }
    String BART_line_dir(){
        try{
            String temp="https://maps.googleapis.com/maps/api/staticmap?center="+centerscn+"&zoom=";
            String temp2="&size=600x600&maptype=terrain&" + globalTEST + "&key=AIzaSyB_5Js3iCys-RouXPQ4XJesXW0woigjzv0&json=y";
            bartpt1=temp;
            bartpt2=temp2;
            return temp;
        }
        catch(Exception e){
            System.out.println("Failure during the actual program");
            return null;
        }
    }
    void BART_MapDirection() {
        int on = 0;
        String url = "http://api.bart.gov/api/stn.aspx?cmd=stns&key=MW9S-E7SL-26DU-VV8V&json=y";
        network(url);
        System.out.println("TEST");
        try {
            String tempBa = "";
            String[] result = new String[dirSIZE];
            JSONObject referenceMAP = new JSONObject(URL_final.toString());
            String stn_dic = referenceMAP.toString();
            JSONObject root1 = referenceMAP.getJSONObject("root");
            JSONObject root2 = root1.getJSONObject("stations");
            JSONArray root3 = root2.getJSONArray("station");
            int SIZE = root3.length();
            System.out.println("TEST" + dirSIZE);
            for (int i = 0; i < dirSIZE; i++) {
                String nROUTE = Route[i].replaceAll(" ", "=");
                String info = "http://api.bart.gov/api/route.aspx?cmd=routeinfo&" + nROUTE + "&key=MW9S-E7SL-26DU-VV8V&json=y";//BARTroutes
                System.out.println(info);
                network(info);
                JSONObject line = new JSONObject(URL_final.toString());
                String stn_lines = line.toString();
                JSONObject root = line.getJSONObject("root");
                JSONObject routes1 = root.getJSONObject("routes");
                JSONObject routes2 = routes1.getJSONObject("route");
                String hex = routes2.optString("hexcolor");
                JSONObject config1 = routes2.getJSONObject("config");
                JSONArray arr1 = config1.getJSONArray("station");
                //System.out.println("TEST");
                for (int n = 0; n < arr1.length(); n++) { //List from route API
                    String abbr = arr1.getString(n);//Choose station from route, go up 1
                    System.out.println("TEST" + arr1.length());

                    if (abbr.equals(Start[i]) || on == 1) { //Then die when you hit the last station 
                        on = 1;
                        for (int z = 0; z < SIZE; z++) {
                            JSONObject value = root3.getJSONObject(z);
                            String lat = value.optString("gtfs_latitude");
                            String lon = value.optString("gtfs_longitude");
                            String name = value.optString("name");
                            System.out.println(name);
                            tempBa += "|" + lat + "," + lon;
                            if (abbr.equals(End[i])) {
                                on = 0;
                                break;
                            }
                        } //new
                    } //end

                }
                result[i] = tempBa;

            }
            for (int k = 0; k < dirSIZE; k++) {
                System.out.println(result[k]);
            }
        } catch (Exception e) {
            System.out.println("Failure in the BART Map Direction method");
        }

    }

    /*BART Map print*/
    String BART_MapCreation() {
        //int no=0;
        //System.out.println("TEST"+ (no+=1));
        try {

            String url = "http://api.bart.gov/api/stn.aspx?cmd=stns&key=MW9S-E7SL-26DU-VV8V&json=y";
            network(url);

            // System.out.println("TEST"+ (no+=1));
            JSONObject referenceMAP = new JSONObject(URL_final.toString());
            String stn_dic = referenceMAP.toString();
            JSONObject root1 = referenceMAP.getJSONObject("root");
            JSONObject root2 = root1.getJSONObject("stations");
            JSONArray root3 = root2.getJSONArray("station");
            int SIZE = root3.length();

            // System.out.println("TEST"+ (no+=1));
            String Pitts = "http://api.bart.gov/api/route.aspx?cmd=routeinfo&route=1&key=MW9S-E7SL-26DU-VV8V&json=y";//yellow
            String Rich = "http://api.bart.gov/api/route.aspx?cmd=routeinfo&route=8&key=MW9S-E7SL-26DU-VV8V&json=y";//red
            String Fremont = "http://api.bart.gov/api/route.aspx?cmd=routeinfo&route=11&key=MW9S-E7SL-26DU-VV8V&json=y";//blue
            String Dublin = "http://api.bart.gov/api/route.aspx?cmd=routeinfo&route=6&key=MW9S-E7SL-26DU-VV8V&json=y";//green
            String RichFr = "http://api.bart.gov/api/route.aspx?cmd=routeinfo&route=3&key=MW9S-E7SL-26DU-VV8V&json=y";//orange
            String Oak = "http://api.bart.gov/api/route.aspx?cmd=routeinfo&route=20&key=MW9S-E7SL-26DU-VV8V&json=y";//airport
            String tempBa = "";
            String fiURL = "";
            int weightSIZE = 12;
            String[] array = null; //All routes in an array
            array = new String[6];
            array[1] = Pitts;
            array[2] = Fremont;
            array[3] = Rich;
            array[4] = Dublin;
            array[0] = RichFr;
            array[5] = Oak;
            // System.out.println("TEST"+ (no+=1));
            //make a starter url
            for (int i = 0; i < 6; i++) { //Get line
                network(array[i]);
                JSONObject line = new JSONObject(URL_final.toString());
                String stn_lines = line.toString();
                JSONObject root = line.getJSONObject("root");
                JSONObject routes1 = root.getJSONObject("routes");
                JSONObject routes2 = routes1.getJSONObject("route");
                String hex = routes2.optString("hexcolor");
                JSONObject config1 = routes2.getJSONObject("config");
                JSONArray arr1 = config1.getJSONArray("station");
                //  System.out.println("TEST"+ (no+=1));
                for (int n = 0; n < arr1.length(); n++) { //run through each station of the line to get abbr
                    //  System.out.println("TEST HERE");
                    String stn1 = arr1.getString(n);
                    // System.out.print(stn1);
                    for (int z = 0; z < SIZE; z++) {
                        //System.out.println("TEST"+ (no+=1));
                        JSONObject dict1 = root3.getJSONObject(z); //run through station list and match it with abbr
                        if (stn1.equals(dict1.optString("abbr"))) {
                            //  System.out.println("TEST"+ (no+=1));
                            String lat = dict1.optString("gtfs_latitude"); //capture lat long and add to string
                            String lon = dict1.optString("gtfs_longitude");
                            // System.out.println(lat+ ","+lon);
                            tempBa += "|" + lat + "," + lon;
                            //break;
                        }
                    }
                }
                //write code to seperate polygons 
                //System.out.println("TEST"+ (no+=1));
                String color = hex.replaceAll("#", "x");

                fiURL += ("&path=color:0" + color + "FF|weight:" + (weightSIZE -= 2) + tempBa);
                tempBa = "";

            }
            //System.out.println(fiURL);
            String final_url = "&" + fiURL + "&key=AIzaSyB_5Js3iCys-RouXPQ4XJesXW0woigjzv0";
            //System.out.print(final_url);
            return final_url;

        } catch (Exception e) {
            System.out.println("Failed to make a URL for a BART map");
            return "&";
        }

    }

    /*BART ETA*/    void URL_ETA(String url_stn) {
        try {
            String send_to_dic = null;
            String url_0 = "http://api.bart.gov/api/etd.aspx?cmd=etd&orig=";
            String API_key = "&key=MW9S-E7SL-26DU-VV8V";
            String url_1 = "&json=y";
            String url = url_0 + url_stn + API_key + url_1;
            network(url); //Calling URL processor
            //System.out.println(url);
            //System.out.println(URL_final.toString());
            JSONObject page_c = new JSONObject(URL_final.toString());
            JSONObject root_c = page_c.getJSONObject("root");
            JSONArray stn_c = root_c.getJSONArray("station");

            for (int i = 0; i < stn_c.length(); i++) {
                JSONObject stn_ob = stn_c.getJSONObject(i);
                String stn_name = stn_ob.optString("name");
                send_to_dic = stn_ob.optString("abbr");
                System.out.println("***********************************");
                System.out.println("Station: " + stn_name);
                System.out.println("***********************************");
                JSONArray etd_c = stn_ob.getJSONArray("etd");

                for (int n = 0; n < etd_c.length(); n++) {
                    JSONObject des_c = etd_c.getJSONObject(n);
                    String train_des = des_c.optString("destination");
                    System.out.println("----------------------");
                    System.out.println(train_des);
                    System.out.println("----------------------");
                    JSONArray est_c = des_c.getJSONArray("estimate");
                    for (int l = 0; l < est_c.length(); l++) {
                        JSONObject est_obj = est_c.getJSONObject(l);
                        String minutes = est_obj.optString("minutes");
                        String length = est_obj.optString("length");
                        String platform = est_obj.optString("platform");

                        if (minutes.equals("Leaving")) {
                            System.out.println(length + "-car " + train_des + "-train now boarding, platform " + platform);
                        } else if (minutes.equals("1")) {
                            System.out.println(length + "-car " + train_des + "-train now approaching, platform " + platform);
                        } else {
                            System.out.println(minutes + " minutes.");
                            System.out.println(length + "-car train.");
                        }
                        System.out.println();
                    }
                    System.out.println();
                }
                System.out.println();
            }
            System.out.println();

            System.out.println("Show Map or Picture of BART station? (y/n)");
            Scanner reader = new Scanner(System.in);
            char choice = reader.next().charAt(0);
            if (choice == 'y') {
                station_info(send_to_dic);
            }
        } catch (Exception a) {
            System.out.println("An error occured in URL_ETA.");
        }
    }

    void mapGui() { //This prints out a map image, size is the size of picture, small, med, large
        int process = 1;
        int condition = 0;
        Scanner select0 = new Scanner(System.in);
        
        while (process != 0) {
            JFrame test = new JFrame("Google Maps");
            String imageUrl = null;
            if(Directional_Condition==true){
                System.out.println("DIRECTIONAL MAP");
                //Scanner select0 = new Scanner(System.in);
               // int cho = select0.nextInt();
                String zoom=null;
                try{
                        System.out.println("Press 1 for Close-Up | Press 2 for Bird's Eye | Press 3 for Regional \nPress 4 for Wide-Regional | Press 5 for Central BART MAP");
                        int cho2 = select0.nextInt();
                        if (cho2 == 1) {
                            zoom = "20";
                        } else if (cho2 == 2) {
                            zoom = "15";
                        } else if (cho2 == 3) {
                            zoom = "13";
                        } else if (cho2 == 4 || cho2 == 5) {
                            zoom = "10";
                        }
                        imageUrl=bartDirZoomCenter+zoom+globalTEST+"&key="+gMapAPI;
                        
                    String destinationFile = "image.jpg";
                    URL url = new URL(imageUrl);
                    InputStream is = url.openStream();
                    OutputStream os = new FileOutputStream(destinationFile);
                    byte[] b = new byte[2048];
                    int length;
                    while ((length = is.read(b)) != -1) {
                        os.write(b, 0, length);
                    }
                    is.close();
                    os.close();
                        
                }
                catch(Exception e){
                    System.out.println("Error in the Map GUI--Directional polygon");
                }
            
            }   
         
            else{    
                System.out.println("Picture Options");
                System.out.println("Press 1 for STREETVIEW | Press 2 for MAP");

                int cho = select0.nextInt();

                try {
                    //String latitude = "37.873915";
                    //String longitude = "-122.282552";
                    String POV = null;
                    String zoom = null;
                    String streetTemp = null;
                    String mapTemp = null;
                    
                    if (cho == 1) { //Streetview
                        System.out.println("Press 1 for North | Press 2 for South | Press 3 for West | Press 4 for East");
                        int cho1 = select0.nextInt();

                        if (cho1 == 1) {
                            POV = "0";
                        } else if (cho1 == 2) {
                            POV = "180";
                        } else if (cho1 == 3) {
                            POV = "270";
                        } else if (cho1 == 4) {
                            POV = "90";
                        } else {
                            POV = "360";
                        }

                        streetTemp = "https://maps.googleapis.com/maps/api/streetview?size=612x612&location=" + latitude
                                + "," + longitude
                                + "&fov=90&heading=" + POV + "&pitch=10&key=" + gMapAPI;
                        imageUrl = streetTemp;
                    } else {//Static map
                        if (BARTMapCheck == 1) { //Prints out BART Map
                            System.out.println("Press 1 for Close-Up | Press 2 for Bird's Eye | Press 3 for Regional \nPress 4 for Wide-Regional | Press 5 for Central BART MAP");
                            int cho2 = select0.nextInt();
                            if (cho2 == 1) {
                                zoom = "20";
                            } else if (cho2 == 2) {
                                zoom = "15";
                            } else if (cho2 == 3) {
                                zoom = "13";
                            } else if (cho2 == 4 || cho2 == 5) {
                                zoom = "10";
                            }
                            String mapTemp1;
                            String mapTemp2;
                            if (cho2 == 5) {
                                mapTemp1 = "https://maps.googleapis.com/maps/api/staticmap?center=37.782199,-122.081548&zoom=" + zoom + "&size=900x612&maptype=roadmap&markers=color:blue%7C" + latitude + ","
                                        + longitude;
                                mapTemp2 = BART_MapCreation();
                            } else {
                                mapTemp1 = "https://maps.googleapis.com/maps/api/staticmap?center=" + latitude
                                        + "," + longitude + "&zoom=" + zoom + "&size=900x612&maptype=roadmap&markers=color:blue%7C" + latitude + ","
                                        + longitude;
                                mapTemp2 = BART_MapCreation();
                            }

                            mapTemp = mapTemp1 + mapTemp2;
                        } 
                        else if (FINALGLOBE == 1) {
                            mapTemp = BARTstnco();
                        } 

                        else {
                            System.out.println("Marker on Ground Zero? (y/n) ");
                            Scanner reader = new Scanner(System.in);
                            char c = reader.next().charAt(0);

                            if (condition == 1) { //After first run
                                System.out.println("Adjust height");
                                System.out.println("Press 1 for Close-Up | Press 2 for Bird's Eye | Press 3 for Regional");
                                int cho2 = select0.nextInt();
                                if (cho2 == 1) {
                                    zoom = "20";
                                } else if (cho2 == 2) {
                                    zoom = "15";
                                } else if (cho2 == 3) {
                                    zoom = "13";
                                }

                                if (c == 'n') {
                                    mapTemp = "https://maps.googleapis.com/maps/api/staticmap?center="
                                            + latitude + "," + longitude + "&zoom=" + zoom + "&size=612x612&key=" + gMapAPI;
                                } else if (c == 'y') {
                                    mapTemp = "https://maps.googleapis.com/maps/api/staticmap?center=" + latitude
                                            + "," + longitude + "&zoom=" + zoom + "&size=612x612&maptype=roadmap&markers=color:red%7Clabel:C%7C" + latitude + ","
                                            + longitude + "&key=" + gMapAPI;
                                } else if (c == 'z') {
                                    mapTemp = BARTstnco();
                                }

                            } else { //For first run, default scope
                                if (c == 'n') {
                                    mapTemp = "https://maps.googleapis.com/maps/api/staticmap?center="
                                            + latitude + "," + longitude + "&zoom=15&size=612x612&key=" + gMapAPI;
                                } else if (c == 'y') {
                                    mapTemp = "https://maps.googleapis.com/maps/api/staticmap?center=" + latitude
                                            + "," + longitude + "&zoom=15&size=612x612&maptype=roadmap&markers=color:red%7Clabel:C%7C" + latitude + ","
                                            + longitude + "&key=" + gMapAPI;
                                } else if (c == 'z') {
                                    mapTemp = BARTstnco();
                                }
                            }
                        }
                        imageUrl = mapTemp;
                        //System.out.println(imageUrl);
                    }
                    
            
                    //END
                    //shared thing, everyhing below is untouched
                    // String imageUrl = streetTemp;
                    String destinationFile = "image.jpg";
                    // read the map image from Google
                    // then save it to a local file: image.jpg
                    //
                    URL url = new URL(imageUrl);
                    InputStream is = url.openStream();
                    OutputStream os = new FileOutputStream(destinationFile);
                    byte[] b = new byte[2048];
                    int length;
                    while ((length = is.read(b)) != -1) {
                        os.write(b, 0, length);
                    }
                    is.close();
                    os.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    System.exit(1);
                }
            }
            // create a GUI component that loads the image: image.jpg
            //
            ImageIcon imageIcon = new ImageIcon((new ImageIcon("image.jpg"))
                    .getImage().getScaledInstance(630, 600,
                            java.awt.Image.SCALE_SMOOTH));
            test.add(new JLabel(imageIcon));
            // show the GUI window
            test.setVisible(true);
            test.pack();

            System.out.println("***Press 1 to Repeat | Press 0 to exit Map GUI***");
            process = select0.nextInt();
            condition = 1;
        }
        condition = 0;

    }

    void coordinate_conversion(String i) { //Search a specific location for lat/long
        String tempU = "https://maps.googleapis.com/maps/api/geocode/json?address=" + i + "&key=" + geoCodeAPI;
        //System.out.println(tempU);
        network(tempU);
        try {
            JSONObject starter = new JSONObject(URL_final.toString());
            JSONArray results = starter.getJSONArray("results");
            JSONObject temp = results.getJSONObject(0);
            String forAdd = temp.optString("formatted_address");
            JSONArray ac = temp.getJSONArray("address_components");
            JSONObject get = ac.getJSONObject(3);
            String hood = get.optString("long_name");

            JSONObject geometry = temp.getJSONObject("geometry");
            JSONObject location = geometry.getJSONObject("location");
            latitude = location.optString("lat");
            longitude = location.optString("lng");
            System.out.println("Location Found: " + forAdd);
            System.out.println("Neighborhood: " + hood);

            System.out.println("Show Map or Picture of location? (y/n)");
            Scanner reader = new Scanner(System.in);
            char choice = reader.next().charAt(0);
            if (choice == 'y') {
                mapGui();
            }
        } catch (Exception e) {
            System.out.println("Failure");
        }
    }

    void station_info(String stn) {
        String pUrl = "http://api.bart.gov/api/stn.aspx?cmd=stninfo&orig=" + stn + "&key=MW9S-E7SL-26DU-VV8V&json=y";
        network(pUrl);
        //System.out.println(URL_final);
        try {
            JSONObject starter = new JSONObject(URL_final.toString());
            JSONObject rt = starter.getJSONObject("root");
            JSONObject stns = rt.getJSONObject("stations");
            JSONObject st = stns.getJSONObject("station");
            latitude = st.optString("gtfs_latitude");
            longitude = st.optString("gtfs_longitude");
            mapGui();
        } catch (Exception e) {
            System.out.println("Failure");
        }
    }

    String BARTstnco() {

        String lat = null;
        String lon = null;
        String Proto = "https://maps.googleapis.com/maps/api/staticmap?center=";
        String Proto1 = "&zoom=20&size=600x600&maptype=roadmap&"
                + "key=AIzaSyB_5Js3iCys-RouXPQ4XJesXW0woigjzv0";

        String bUrl = "http://api.bart.gov/api/stn.aspx?cmd=stns&key=MW9S-E7SL-26DU-VV8V&json=y";
        network(bUrl);
        String bart_line;
        String yellow = "";
        int SIZE = 0;
        String stn_dic = null;
        JSONArray global = null;
        try {
            JSONObject referenceMAP = new JSONObject(URL_final.toString());
            stn_dic = referenceMAP.toString();
            JSONObject root1 = referenceMAP.getJSONObject("root");
            JSONObject root2 = root1.getJSONObject("stations");
            JSONArray root3 = root2.getJSONArray("station");
            global = root3;
            SIZE = root3.length();

        } catch (Exception e) {
            System.out.println("BART map failed to print");
        }
        try {
            //Yellow
            String tempBa = "";
            String Pitts = "http://api.bart.gov/api/route.aspx?cmd=routeinfo&" + globalROUTE + "&key=MW9S-E7SL-26DU-VV8V&json=y";
            network(Pitts);
            JSONObject starterBP = new JSONObject(URL_final.toString());
            JSONObject root1 = starterBP.getJSONObject("root");
            JSONObject root2 = root1.getJSONObject("routes");
            JSONObject route = root2.getJSONObject("route");
            JSONObject con = route.getJSONObject("config");
            JSONArray stn = con.getJSONArray("station");
            //System.out.println("CHECK");
            for (int i = 0; i < stn.length(); i++) {
                String test = stn.getString(i);
                for (int n = 0; n < SIZE; n++) {
                    JSONObject ref = global.getJSONObject(n);
                    if (test.equals(ref.optString("abbr"))) {
                        lat = ref.optString("gtfs_latitude");
                        lon = ref.optString("gtfs_longitude");
                        tempBa += "|" + lat + "," + lon;
                        break;
                    }
                }
            }
            String s = globalCOLOR.replaceAll("#", "x");
            tempBARTLines = "path=color:0" + s + "|weight:10" + tempBa;
            //TEST
            String final_yellow = "https://maps.googleapis.com/maps/api/staticmap?center=37.829065,-122.267040&"
                    + "&zoom=9&size=600x600&maptype=terrain&" + tempBARTLines + "&key=AIzaSyB_5Js3iCys-RouXPQ4XJesXW0woigjzv0&json=y";
            //System.out.println(globalROUTE);
            //System.out.println(globalCOLOR);
            return final_yellow;

            //Blue
            //Green
            //Red           
        } catch (Exception e) {
            System.out.println("Failure in the map");
            return null;
        }

    }

}

class ACT extends URL_class {

    String agency = null;
    String tempBusLines = null;

    ACT(String age) {
        agency = age;
    }

    String ACT_routeprint() {
        try {
            String ACT_route0 = "http://webservices.nextbus.com/service/publicJSONFeed?command=routeList&a=" + agency;
            //System.out.println(ACT_route0);
            System.out.println("All Transit Serivce: ");
            network(ACT_route0);
            String choice;
            JSONObject ACTbuslist = new JSONObject(URL_final.toString());
            JSONArray ACT_route = ACTbuslist.getJSONArray("route");
            for (int i = 0; i < ACT_route.length(); i++) {
                JSONObject ACTlines = ACT_route.getJSONObject(i);
                String line = ACTlines.optString("tag");
                String name = ACTlines.optString("title");
                if (line.equals(name)) {
                    System.out.println((i + 1) + ". " + line);
                } else {
                    System.out.println((i + 1) + ". " + name);
                }
            }
            Scanner input = new Scanner(System.in);
            int choice1 = input.nextInt();
            JSONObject chosing = ACT_route.getJSONObject(choice1 - 1);
            choice = chosing.optString("tag");
            return choice;
        } catch (Exception e) {
            System.out.println("Error in the AC line print out");
            return null;
        }

    }

    String ACT_stops(String tag) { //Prints directions and stops
        try {
            System.out.println("--------------");
            System.out.println("Line: " + tag);
            System.out.println("--------------");
            String rd = "http://webservices.nextbus.com/service/publicJSONFeed?command=routeConfig&a=" + agency + "&r=" + tag;
            //System.out.println(rd);
            network(rd);
            String dirname;
            JSONObject ACTstoplist = new JSONObject(URL_final.toString());
            JSONObject route = ACTstoplist.getJSONObject("route");

            JSONArray direction = route.getJSONArray("direction");

            System.out.println("Direction: ");
            for (int i = 0; i < direction.length(); i++) {

                JSONObject titledir = direction.getJSONObject(i);
                dirname = titledir.optString("title");
                System.out.println((i + 1) + " " + dirname);
            }
            Scanner input = new Scanner(System.in);
            int dirchoi = input.nextInt();
            JSONArray stop = route.getJSONArray("stop"); //STOP from top of page

            JSONObject stopT = direction.getJSONObject(dirchoi - 1);
            String dirTit = stopT.optString("title");
            JSONArray stopTag = stopT.getJSONArray("stop");//Stop under direction
            System.out.println("List of stops via : " + dirTit);
            String lat = null; //VARIABLES FOR MAP BELOW
            String lon = null;
            String c = "&markers=color:green%7C";

            String tempLine = "";
            String tempPoly = "";
            for (int i = 0; i < stopTag.length(); i++) {

                JSONObject tagl = stopTag.getJSONObject(i);
                String tag_no = tagl.optString("tag");
                //System.out.println(tag_no);
                int n = 0;
                while (true) { //translator
                    JSONObject tag2 = stop.getJSONObject(n);
                    String tagF = tag2.optString("tag");
                    String stop_name = tag2.optString("title");

                    if (tag_no.equals(tagF)) {
                        lat = tag2.optString("lat");//This is to prints out the url map and does all stops
                        lon = tag2.optString("lon");
                        tempLine += c + lat + "," + lon; //prints the stops
                        tempPoly += "|" + lat + "," + lon; //prints the polygon line
                        System.out.println((i + 1) + " " + stop_name);
                        break;
                    }
                    n++;
                }
            }
            tempBusLines = tempLine;
            // #b3ffe1 path=color:0xb3ffe1|weight:4|
            Scanner input0 = new Scanner(System.in); //Chose your bus stop
            int choice5 = input0.nextInt();
            JSONObject tagl = stopTag.getJSONObject(choice5 - 1);
            String tag_no = tagl.optString("tag");
            int k = 0;
            String stop_Id = null; 
            String stop_name = null;
            String latH = null;
            String lonH = null;
            while (true) { //finding specific tag id and stop ID
                JSONObject tag2 = stop.getJSONObject(k);
                String tagF = tag2.optString("tag");
                stop_name = tag2.optString("title");
                stop_Id = tag2.optString("stopId");

                if (tag_no.equals(tagF)) {
                    latH = tag2.optString("lat");//This is to print out the url map
                    lonH = tag2.optString("lon");
                    tempBusLines += "&path=color:0x23A638|weight:7" + tempPoly;
                    tempBusStopChoiceMarker = "&markers=color:red%7C" + latH + "," + lonH;
                    break;
                }
                k++;
            }
            //System.out.println("RESULT: " + stop_Id + " " + stop_name);
            //Starting map pointers
            /*   JSONObject ACT1= new JSONObject(URL_final.toString());
            JSONObject r1= ACT1.getJSONObject("route");
            JSONArray r2=r1.getJSONArray("stop");
            
      //      globalSIZE=r2.length();
      //      String hold_lats[]=new String [globalSIZE];
           String c="&markers=color:green%7C";
            String tempLine = "";
            for(int z=0; z<r2.length(); z++){
                JSONObject r3=r2.getJSONObject(z);
                String a=r3.optString("lat");
                String b=r3.optString("lon");
                //System.out.println(a);//This works but cant get it out
                //System.out.println(b);
                tempLine+=c+a+","+b;
                
            } */
            //tempBusLines=tempLine;
            tempBusSTOP = latH + "," + lonH;
            //System.out.println(tempBusSTOP);
            return stop_Id;
        } catch (Exception e) {
            System.out.println("Error in the stop print out");
            return null;
        }
    }

    void ACTeta(String tag) {
        try {
            String url = "http://webservices.nextbus.com/service/publicJSONFeed?command=predictions&a=" + agency + "&stopId=" + tag;
            network(url);
            JSONObject ACTetas = new JSONObject(URL_final.toString());
            //System.out.println(url);
            try {
                //System.out.println("Trying multi-route");

                JSONArray pred = ACTetas.getJSONArray("predictions");
                JSONObject stopname = pred.getJSONObject(0);
                String stopTitle = stopname.optString("stopTitle");
                System.out.println("********************************************");
                System.out.println("Location: " + stopTitle);
                System.out.println("********************************************");
                for (int i = 0; i < pred.length(); i++) {

                    try {
                        JSONObject etaob = pred.getJSONObject(i);
                        String route_name = etaob.optString("routeTitle");
                        try {
                            JSONObject dir = etaob.getJSONObject("direction");
                            String title = dir.optString("title");
                            System.out.print(route_name);
                            System.out.println(" - " + title);
                            try {
                                JSONArray predi = dir.getJSONArray("prediction");
                                System.out.println("-----------------------------------");
                                for (int a = 0; a < predi.length(); a++) {
                                    JSONObject upre = predi.getJSONObject(a);
                                    String minutes = upre.optString("minutes");
                                    if (minutes.equals("0")) {
                                        System.out.println("Arriving");
                                    } else if (minutes.equals("1")) {
                                        System.out.println("1 minute, approaching");
                                    } else {
                                        System.out.println(minutes + " minutes.");
                                    }
                                }

                            } catch (Exception e) {
                                JSONObject predic = dir.getJSONObject("prediction");
                                System.out.println("-----------------------------------");
                                String minutes = predic.optString("minutes");
                                System.out.println(minutes + "-minutes");
                            }
                            System.out.println();
                        } catch (Exception j) {
                            JSONArray dir = etaob.getJSONArray("direction");
                            for (int b = 0; b < dir.length(); b++) {
                                JSONObject dirob = dir.getJSONObject(b);
                                String title = dirob.optString("title");

                                System.out.print(route_name);
                                System.out.println(" - " + title);
                                try {
                                    JSONArray predi = dirob.getJSONArray("prediction");
                                    System.out.println("-----------------------------------");
                                    for (int a = 0; a < predi.length(); a++) {
                                        JSONObject upre = predi.getJSONObject(a);
                                        String minutes = upre.optString("minutes");
                                        System.out.println(minutes + " minutes.");
                                    }

                                } catch (Exception e) {
                                    JSONObject predic = dirob.getJSONObject("prediction");
                                    System.out.println("-----------------------------------");
                                    String minutes = predic.optString("minutes");
                                    System.out.println(minutes + "-minutes");
                                }
                                System.out.println();
                            }
                        }
                    } catch (Exception b) {
                        // System.out.println("Catched, to no line print"); //This will run "THIS LINE ISNT RUNNING"
                        JSONObject etaob = pred.getJSONObject(i);
                        String route_name = etaob.optString("routeTitle");
                        System.out.print(route_name);
                        String direction = etaob.optString("dirTitleBecauseNoPredictions");
                        System.out.println(" - " + direction);
                        System.out.println("-----------------------------------");
                        System.out.println("This line is current not in service");
                        System.out.println();

                    }
                }
            } catch (Exception a) { //Single route
                // System.out.println("Catched, to single route");

                try {
                    JSONObject pre = ACTetas.getJSONObject("predictions");
                    String stopLoc = pre.optString("stopTitle");
                    System.out.println("****************************");
                    System.out.println("Location: " + stopLoc);
                    System.out.println("****************************");
                    String routeno = pre.optString("routeTitle");
                    JSONObject dirs = pre.getJSONObject("direction");
                    System.out.print(routeno);
                    String direction = dirs.optString("title");
                    System.out.println(" - " + direction);
                    System.out.println("-----------------------------------");
                    JSONArray pred = dirs.getJSONArray("prediction");
                    for (int i = 0; i < pred.length(); i++) {
                        JSONObject eta = pred.getJSONObject(i);
                        String minutes = eta.optString("minutes");
                        System.out.println(minutes + "- minutes");
                    }
                    System.out.println();
                } catch (Exception c) {
                    JSONObject pre = ACTetas.getJSONObject("predictions");
                    String routeno = pre.optString("routeTitle");
                    System.out.print(routeno);
                    String nodir = pre.optString("dirTitleBecauseNoPredictions");
                    System.out.println(" - " + nodir);
                    System.out.println("-----------------------------------");
                    System.out.println("No directions at this time");
                    System.out.println();

                }
            }
        } catch (Exception e) {
            System.out.println("error in the AC Transit ETA");
        }
        bus_info();
    }

    void bus_info() {
        String holder = "https://maps.googleapis.com/maps/api/staticmap?center=" + tempBusSTOP + "&zoom=";
        String holder2 = "&size=600x600&maptype=roadmap" + tempBusLines + "&key=" + gMapAPI;
        busPt1 = holder;
        busPt2 = holder2;
    }

    void busGui() { //prints bus map and locations
        int process = 1;
        int condition = 0;
        while (process != 0) {
            JFrame test = new JFrame("Google Maps");
            System.out.println("Picture Options for Bus Routes");
            System.out.println("Press 1 for STREETVIEW | Press 2 for ROUTE MAP");
            Scanner select0 = new Scanner(System.in);
            int cho = select0.nextInt();

            try {
                //String latitude = "37.873915";
                //String longitude = "-122.282552";
                String POV = null;
                String zoom = null;
                String streetTemp = null;
                String mapTemp = null;
                String imageUrl = null;
                if (cho == 1) { //Streetview
                    System.out.println("Press 1 for North | Press 2 for South | Press 3 for West | Press 4 for East");
                    int cho1 = select0.nextInt();

                    if (cho1 == 1) {
                        POV = "0";
                    } else if (cho1 == 2) {
                        POV = "180";
                    } else if (cho1 == 3) {
                        POV = "270";
                    } else if (cho1 == 4) {
                        POV = "90";
                    } else {
                        POV = "360";
                    }

                    streetTemp = "https://maps.googleapis.com/maps/api/streetview?size=612x612&location=" + tempBusSTOP
                            + "&fov=90&heading=" + POV + "&pitch=10&key=" + gMapAPI;
                    imageUrl = streetTemp;
                } else {//ROUTE MAP printing line, stops and polygons
                    //System.out.println("Marker on Ground Zero? (y/n) ");
                    //Scanner reader = new Scanner(System.in);//After first run
                    System.out.println("Adjust height");
                    System.out.println("Press 1 for Close-Up | Press 2 for Bird's Eye | Press 3 for Regional");
                    int cho2 = select0.nextInt();
                    if (cho2 == 1) {
                        zoom = "17";
                    } else if (cho2 == 2) {
                        zoom = "15";
                    } else if (cho2 == 3) {
                        zoom = "13";
                    }

                    mapTemp = "https://maps.googleapis.com/maps/api/staticmap?center="
                            + tempBusSTOP + "&zoom=" + zoom + "&size=612x612&" + tempBusStopChoiceMarker + "&" + tempBusLines + "&key=" + gMapAPI;
                    //System.out.println(mapTemp);
                    imageUrl = mapTemp;

                }
                //END
                //shared thing, everyhing below is untouched
                // String imageUrl = streetTemp;
                String destinationFile = "image.jpg";
                // read the map image from Google
                // then save it to a local file: image.jpg
                //
                URL url = new URL(imageUrl);
                InputStream is = url.openStream();
                OutputStream os = new FileOutputStream(destinationFile);
                byte[] b = new byte[2048];
                int length;
                while ((length = is.read(b)) != -1) {
                    os.write(b, 0, length);
                }
                is.close();
                os.close();
            } catch (IOException e) {
                e.printStackTrace();
                System.exit(1);
            }

            // create a GUI component that loads the image: image.jpg
            //
            ImageIcon imageIcon = new ImageIcon((new ImageIcon("image.jpg"))
                    .getImage().getScaledInstance(630, 600,
                            java.awt.Image.SCALE_SMOOTH));
            test.add(new JLabel(imageIcon));
            // show the GUI window
            test.setVisible(true);
            test.pack();

            System.out.println("***Press 1 to Repeat | Press 0 to exit Map GUI***");
            process = select0.nextInt();
            condition = 1;
        }
        condition = 0;

    }
}
//NOTE, for the multi-routes you did a series of conditions but you ought do it for the single-routers

public class bartApp {

    public static void main(String[] args) {

        URL_class bart = new URL_class(); //(Prints picture)
        bart.BARTHashMap();
        
        int choice = 1;
        Scanner select0 = new Scanner(System.in);
        String whatever = bart.BART_MapCreation();
        while (choice != 0) {
            System.out.println("This is my Geocoding Project.\nSelect 1 for BART Arrivals \nSelect 2 for BART directions \nSelect 3 for Bus Arrivals "
                    + "\nSelect 4 for Location and Distance Inquiry");
            int select = select0.nextInt();
            if (select == 1) {
                bart.BARTMapCheck = 1;
                String result;
                result = bart.stn_dictionary();
                bart.URL_ETA(result);
                bart.BARTMapCheck = 0;
            } else if (select == 2) {
                bart.direction_url();
                //System.out.println(bart.centerscn + " TEST " + bart.globalTEST);
            
                bart.Directional_Condition=true;
                bart.mapGui();
                bart.Directional_Condition=false;
          
            } else if (select == 3) {
                    
                char stop_option='y';
                String agency = bart.agencies();
                ACT ac = new ACT(agency);
                while(stop_option=='y'){
                    String tag, ID;
                    tag = ac.ACT_routeprint();
                    ID = ac.ACT_stops(tag);
                    ac.ACTeta(ID);
                    ac.busGui();
                    System.out.println("Choose another stop 'y' or return to main menu 'n'?");
                    Scanner reader = new Scanner(System.in);
                    stop_option=reader.next().charAt(0);
                }
                

            } else if (select == 4) {
                System.out.println("Find a location via address");
                System.out.println("Be as specific as possible. If you want a city, type [Oakland, CA]");
                System.out.println("If you want a specific location, type [2139 MLK Jr Way Apt4, Oakland, CA]");
                System.out.print("Address: ");
                Scanner ss = new Scanner(System.in);
                String s = ss.nextLine();
                String temp = s.replaceAll(" ", "+");
                bart.coordinate_conversion(temp);

            }
            System.out.println("***Press any number to repeat the program, or press 0 to kill the program.***");
            Scanner reader = new Scanner(System.in);
            choice = reader.nextInt();
            if (choice == 0) {
                break;
            }
        }
    }
}
