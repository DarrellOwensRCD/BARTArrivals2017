package VehicleDemo;

/**
Darrell Owens
* 2/28/2017
* Practice Program 5
 */
class Dogs2{ //class created 
    int dogs;    //variables made
    int bones;
    int days;
    
    Dogs2(int d, int b, int da){ //relayed variables with argument in declaration sub class
    dogs=d;
    bones=b;
    days=da;
}
    int range(){ //new class to caluate range via return 
        return days * bones;
    }
    
    double waterNeeded(int water){ //new class to calculate water needed via return with force (double)
        return (double) water * days;
    }
}
class DogsConDemo {                                 //main class here
    public static void main(String[] args) {
        Dogs2 poodle = new Dogs2 (7, 16, 21);  //this parallels declared variables with arguments up top. Corresponding positions get sent to 
        Dogs2 pitbull = new Dogs2 (2, 14, 12); //corresponding letters which was relayed primariy Dog2 class declarations. 
        
        double gallons; 
        int dist = 252;
        
      gallons = poodle.waterNeeded(dist);
        
        System.out.println("To go "+ dist + " miles with poodle's bones would require "+ gallons + " gallons of water.");
        
        gallons = pitbull.waterNeeded(dist); //values relayed here
        int daysandbonespit=pitbull.range(); //to be carried off by declared variables
        
        System.out.println("To go "+ dist + " miles with pitbull bones would require "+ gallons + " gallons of water." + daysandbonespit );     
        
    }
    
}
/*
To go 252 miles with poodle's bones would require 5292.0 gallons of water.
To go 252 miles with pitbull bones would require 3024.0 gallons of water.
BUILD SUCCESSFUL (total time: 0 seconds)
*/
