/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VehicleDemo;

/**
Darrell Owens
2/28/2017
Practice Program 4
 */
class DogItems1 { //Declared variables
    int dogs;
    int bones;
    int days;
    
    int range() { //solutions to a calculation put in subclasses
        return days * bones;
    }
    
    double waterNeeded (int water){ //same(double) is a force mechanism 
        return (double) water * days;
    }
}
class ForcingDoublesDogs {
    public static void main(String[] args){
        DogItems1 poodle = new DogItems1(); //variables (objects) created by referencing classes twice
        DogItems1 pitbull = new DogItems1();
        double gallons;
        int dist = 252;
        
        
        poodle.dogs = 7;     //new objects are assigned the foreign class declared variables 
        poodle.bones = 16;
        poodle.days = 21; 
        
        pitbull.dogs =2;
        pitbull.bones = 14;
        pitbull.days= 12;
        
        gallons = poodle.waterNeeded(dist); //Same here. Relaying waterNeeded reference 
        //the dist is the argument "water" made in waterNeeded. dist==water. Different variable names for different classes, same function, same purpose
        
        System.out.println("To go "+ dist + " miles with poodle's bones would require "+ gallons + " gallons of water.");
        
        gallons = pitbull.waterNeeded(dist);
        
        System.out.println("To go "+ dist + " miles with pitbull bones would require "+ gallons + " gallons of water.");     
    }
}
/*
run:
To go 252 miles with poodle's bones would require 5292.0 gallons of water.
To go 252 miles with pitbull bones would require 3024.0 gallons of water.
BUILD SUCCESSFUL (total time: 0 seconds)
*/