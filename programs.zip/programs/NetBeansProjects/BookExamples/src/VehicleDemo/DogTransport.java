/*
Darrell Owens
2/28/2017
Practice Program #2
 */
package VehicleDemo;

class Dogs1 {
  int passengers;
  int bones;
  int day;
  
  void range(){
    System.out.println("Transport can carry " + bones * day + " bones per day." );         
  }
}

class DogTransport{
  public static void main(String[] args) {
    Dogs1 poodle = new Dogs1();
    Dogs1 pitbull = new Dogs1();
    
    int range1, range2;
    
    poodle.passengers = 7;
    poodle.bones = 16;
    poodle.day = 21;
    
    pitbull.passengers = 2;
    pitbull.bones = 14;
    pitbull.day = 12;
    
    System.out.print ("Poodle transport can carry " + poodle.passengers + ". ");
    poodle.range(); 
    System.out.print ("Pitbull transport can carry " + pitbull.passengers + ". ");
    pitbull.range();
  }
}
    