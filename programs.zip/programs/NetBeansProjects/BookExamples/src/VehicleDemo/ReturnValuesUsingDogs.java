/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VehicleDemo;

/**
Darrell Owens
2/28/2017
Practice Program 3
 */
class DogItems0 {
    int dogs;
    int bones;
    int days;
    
    int range() {
        return days * bones;
    }
}
class ReturnValuesUsingDogs {
    public static void main (String[] args){
        DogItems0 poodle = new DogItems0();
        DogItems0 pitbull = new DogItems0();
         
        int range1, range2;
        
        poodle.dogs=7;
        poodle.bones=16;
        poodle.days=21;
        
        pitbull.dogs=2;
        pitbull.bones=14;
        pitbull.days=12;
        
        range1 = poodle.range();
        range2= pitbull.range();
        
        System.out.println("Transport can carry " + poodle.dogs + " poodles. Carrying " + range1 + " bones for "+ poodle.days + " days." );
        System.out.println("Transport can carry " + pitbull.dogs + " pitbull. Carrying " + range2 + " bones for"+ pitbull.days + " days.");   
    }
}
/*
run:
Transport can carry 7 poodles. Carrying 336 bones for 21 days.
Transport can carry 2 pitbull. Carrying 168 bones for12 days.
BUILD SUCCESSFUL (total time: 0 seconds)
*/
