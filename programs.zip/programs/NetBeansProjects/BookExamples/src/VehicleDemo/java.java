package VehicleDemo;

/**
 *Darrell Owens 
 * 2/27/2017
 * CIS JAVA 26a
 * Practice program 1#
 */


class Dogs000 {
    int amount;
    int bone;
    int week;
}

class TwoDogs000 {
public static void main(String[] args) {

Dogs000 pitbull = new Dogs000();
Dogs000 poodle = new Dogs000();
int range1, range2;


poodle.amount = 10; //poodles
poodle.bone = 16;    //bone amount 
poodle.week = 7;         //a week
    
    pitbull.amount = 2; //pitbulls
    pitbull.bone=14; //bone amount
    pitbull.week = 7;   //a week

        range1 = poodle.bone * poodle.week;
        range2 = pitbull.bone * pitbull.week;

        System.out.println( poodle.amount + " poodles will eat " + range1 + " bones in a week.");
        System.out.println(pitbull.amount + " pitbulls will eat "+ range2 + " bones in a week.");
    }
}
/*
10 poodles will eat 112 bones in a week.
2 pitbulls will eat 98 bones in a week.
BUILD SUCCESSFUL (total time: 0 seconds)
*/