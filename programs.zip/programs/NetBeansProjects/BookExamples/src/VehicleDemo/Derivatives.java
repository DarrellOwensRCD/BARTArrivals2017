/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VehicleDemo;

/**
 * Darrell Owens
 * This calculates simple derivatives like 6x^3; 
 */
import java.io.IOException; //char
import java.util.Scanner;  //int

class NumberTypes{
    char variable; 
    int constant; 
    int power; 
    double e;
}
public class Derivatives {
    public static void main(String[] args) throws IOException{
    Scanner scanner = new Scanner(System.in);
        
    NumberTypes derivative = new NumberTypes();
        
        int c, p; 
        char x;
    
        System.out.println("I'll differenciate your f(x). What is your constant?");
        c = scanner.nextInt();
        
        System.out.println("And your variable-type ex: x, y, g, ect...");
        x = (char)System.in.read();
        
        System.out.println("To the power of? 0 means 1, fyi");
        p = scanner.nextInt(); 

                
        derivative.variable = x; 
        derivative.constant = c*p;
        derivative.power = p-1; 
        derivative.e = 2.718281828; 
        
 
        
        if (c==0 && p==1) //tested
        {
            System.out.println("Answer is 1");
        } 
        else if (derivative.variable=='e')
        {
            System.out.println("Answer is "+ derivative.constant * derivative.e );
        }
        else if ( p == 1 && derivative.power==0)
        {
            System.out.println ("Answer is " + derivative.constant);
        }
        
        else if (derivative.power <= 1) //tested
        {
            System.out.println("Answer is "+ derivative.constant + derivative.variable);
        }
        
        else if (c==0) //test
        {
            System.out.println ("Answer is " + p + derivative.variable + "^" + derivative.power);
        }
  
        else 
        {
            System.out.println("Answer is "+ derivative.constant + derivative.variable + "^" + derivative.power);
        }
        
    }
    
}
