/**
 * Darrell Owens 2/20/2017
 * This is a meaningless program to attempt classes
 *  Asks for name and age, relays it to class, and cites it in an output
 */
import java.util.Scanner;
public class AgeandInfo {
    int personAge; 
    int personYear;
    String personName;
    int year=2017;
    
    public AgeandInfo (String name){ //conductor
        System.out.println("Subject's name is: "+ name); //Output for name is done out of main
        personName=name; 
    }
    
    public void setAge (int age){
        personAge=age;               //age gets assigned to personAge (relayed)
    }
    
    public int getAge( ){
        System.out.println("Recieved age is: "+ personAge); //after relay to int personAge, it gets sent here. 
        return personAge;                                   
    }
    
    public int findYear( ){
        int yearFound; 
        yearFound=year-personAge;
        System.out.println("Which means you're born in  " + yearFound );
        return yearFound;
    }
    
    
    public static void main (String []args){
        
        Scanner scanner = new Scanner(System.in); //Establish input header
        
        System.out.println("Your name please: ");
        String nameholder = scanner.next();
        
        System.out.println("And your age: ");
        int inputage = scanner.nextInt();
        
        AgeandInfo myAge= new AgeandInfo (nameholder); //Relays info. to "AgeandInfo" class, defines marker
        
        myAge.setAge(inputage); //Holds int and relays to setAge
        
        myAge.getAge(); //Get Age is marked for output
        
        myAge.findYear(); //Marked for output from findYear

    }   //myAge. is a reference to the class setAge where the number is assigned
}       //thus myAge. references the class, and .personAge cites the variable, together is the same as a simple personAge in class "getAge". 

/*
Your name please: 
Darrell
And your age: 
20
Subject's name is: Darrell
Recieved age is: 20
Which means you're born in  1997
BUILD SUCCESSFUL (total time: 7 seconds)
*/