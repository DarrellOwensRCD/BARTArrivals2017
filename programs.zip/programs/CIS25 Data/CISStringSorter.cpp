#include <iostream>
using namespace std;
int main(){
	string array= "darrell";
	int hold;
	int x=7;
	cout<<array<<endl;
	for(int i=0; i<x; i++){
		for(int n=0; n<x-1; n++){
			if(array[n] > array[n+1]){
				hold=array[n];
				array[n]=array[n+1];
				array[n+1]=hold;
			}
		}
	}
	
	for (int z=0; z<x; z++){
		if (array[z]==array[z+1]){
			cout<<array[z]<<" duplicated\n";
			
		}
	}
}
