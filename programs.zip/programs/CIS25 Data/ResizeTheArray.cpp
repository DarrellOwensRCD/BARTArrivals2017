//Darrell Owens
//10/18/2017
//New Array twice as large (dynamic)
#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;
int main(){
	srand( time(NULL));
	int *sampleArray=new int[10];
	int *newArray=new int[20];
	for (int i=0; i<10; i++){
		sampleArray[i]=(rand() % 1000)+1;
	}
	cout<<"Sample Array: "<<endl;
	for (int x=0; x<10; x++){
		cout<<sampleArray[x]<<' ';
	}
	for(int n=0; n<10; n++){
		newArray[n]=sampleArray[n];
	}

	for(int a=10; a<20; a++){
		newArray[a]=(rand() % 1000)+1;
	}
	cout<<endl;
	cout<<"New Array with filled values"<<endl;
	for(int y; y<20; y++){
		cout<<newArray[y]<<' ';
	}
	delete[] sampleArray;
	delete[] newArray;
	return 0;
}

