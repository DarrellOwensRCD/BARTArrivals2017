#include <iostream>
using namespace std;
class Weight{
public:
    float Value, x;
    int weight;
    Weight(){
        Value=100;
    }
	public:
	void Set(int i){
	    cout<<"Setting value from weight_conversion file"<<endl;
		Value=i;
	}
	void Get(){
		x= Value/9.807;
	}
	void mercury(){
	x*=3.8;

    }
    void mars(){
        x*= 3.8;

    }
    void venus(){
        x*=9.1;

    }
    void moon(){
        x*=1.6;
    }
    void allConvos(){

        cout<<"Your weight on Mercury is "<<x*3.8<<endl;
        cout<<"Your weight on Venus is  "<<x*9.1<<endl;
        cout<<"Your weight on Mars is   "<<x*3.8 <<endl;
        cout<<"Your weight on the moon is "<<x*1.6<<endl;
    }
};

