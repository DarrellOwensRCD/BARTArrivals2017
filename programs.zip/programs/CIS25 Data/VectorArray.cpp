//Darrell Owens
//10/18/2017
//New Array twice as large (vector)
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <vector>
#include <Python.h>
using namespace std;
int main(){
	int SIZE=10;
	int SIZE2=20;
	vector<int> sampleVector;
	sampleVector.resize(SIZE);
	cout<<"Sample Vector: \n";
	
	for (int i=0; i<SIZE; i++){
		sampleVector[i]=(rand() % 1000)+1;
	}
	for( int x : sampleVector){
		cout<<x<<' ';
	}
	cout<<endl;
	sampleVector.resize(SIZE2);
	for (int i=0; i<SIZE2; i++){
		sampleVector[i]=(rand() % 1000)+1;
	}
	cout<<"Sample Vector resized: \n";
	for(int x: sampleVector){
		cout<<x<<' ';
	}
}




