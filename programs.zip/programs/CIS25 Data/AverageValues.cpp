#include <iostream>
#include <string>
using namespace std;
int main()
{
    double value;
    double sum=0;
    double odd=0;
    cout<<"Give a value and I will sum all values between it\nstarting with value 1 and its odds"<<endl;
    cin>>value;
    
    for (int i=1; i<=value; i++){
        sum=sum+i;
        if (i%2 !=0){
            odd=odd+i;
        }
 
    }
    cout<<"The average of 1 through "<<value<<" is "<<sum/value<<endl;
    cout<<"Sum of only odd numbers is "<<odd<<endl;
    return 0;
}
