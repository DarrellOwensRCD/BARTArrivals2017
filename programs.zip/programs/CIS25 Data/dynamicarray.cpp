//Darrell Owens
//CIS 25
//Final: Program 2
//12/12/2017
#include <iostream>
using namespace std;
int main(){
	float* Arr_a=NULL; //Dynamic Arrays initialized, and without sizes.
	float* Arr_b=NULL;
	float* Arr_c=NULL;
	int n,m;
	float holda, holdb; 
	cout<<"How big do you want Array A to be?"<<endl;
	cin>>n;
	cout<<"How big do you want Array B to be?"<<endl;
	cin>>m;
	Arr_a=new float[n]; //Inputting sizes
	Arr_b=new float[m];
	int SIZE=m+n;   //Size of Dynamic Array C calculated. 
	Arr_c=new float[SIZE]; //Dynamic Array C's size allocated.
	
	cout<<"Filling Array A: "<<endl;
	
	for (int i=0; i<n; i++){
		cout<<"Enter value ";
		cin>>holda;
		Arr_a[i]=holda;
	}
	cout<<endl;
	cout<<"Filling Array B: "<<endl;
	for (int i=0; i<m; i++){
		cout<<"Enter value ";
		cin>>holdb;
		Arr_b[i]=holdb;
	}
	
	for(int i=0; i<SIZE; i++){ //Loop to fill Array C 
		if(i<m){
			Arr_c[i]=Arr_b[i];
		}
		else{
			Arr_c[i]=Arr_a[i-m];
		}
	}
	cout<<endl;
	cout<<"Values of Dynamic Array A"<<endl;
	for(int i=0; i<n; i++){
		cout<<Arr_a[i]<<" ";
	}
	cout<<endl;
	cout<<"Values of Dynamic Array B"<<endl;
	for(int i=0; i<m; i++){
		cout<<Arr_b[i]<<" ";
	}
	cout<<endl;
	cout<<"Values of Dynamic Array C"<<endl;
	for (int i=0; i<SIZE; i++){
		cout<<Arr_c[i]<<" ";
	}
	delete [] Arr_a;  //Destroying memory
	delete [] Arr_b;
	delete [] Arr_c;
	Arr_a=NULL;
	Arr_b=NULL;
	Arr_c=NULL;
	return 0;
}
