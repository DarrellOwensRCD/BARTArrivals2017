//Darrell Owens
//12/11/2017
//CIS 25 
//Final Exam: Problem 1
#include <iostream>
using namespace std;
void time_converter(int secs){
	int day=secs/ 86400;
	int seconds=secs % 86400;
	int hour=seconds/3600;
	seconds=secs % 3600;
	int minute=seconds/60;
	seconds= seconds % 60;
	
	if (day>=1){
		if(day>=1 && hour==0 && minute==0 && seconds==0){
			if (day==1){
				cout<<"1 Day"<<endl;
			}
			else{
				cout<<day<<" days."<<endl;
			}
		}
		else{
			if (hour==0){
				if(minute==0 && seconds!=0){
					cout<<day<<" days and "<<seconds<<" seconds."<<endl;
				}
				else if(minute!=0 && seconds==0){
					cout<<day<<" days and "<<minute<< " minutes"<<endl;
				}
				else{
					cout<<day<<" days, "<<minute<<" minutes, and "<<seconds<<"seconds."<<endl;
				}
			}
			else{
				if (minute==0 && seconds==0){
					cout<<day<<" days, and "<<hour<<" hours."<<endl;
				}
				else{
					if (seconds==0 && minute!=0){
						cout<<day<<" days, "<<hour<<" hours, "<<minute<<" and minutes."<<endl;
					}
					else if(seconds!=0 && minute==0){
						cout<<day<<" days, "<<hour<<" hours, and "<<seconds<<" seconds."<<endl;
					}
					else{
						cout<<day<<" days, "<<hour<<" hours, "<<minute<<" minutes, and "<<seconds<<" seconds."<<endl;
					}
				}
			}
		}
	}
	else if(day==0 && hour >=1){
		if (hour==1 && minute==0 && seconds ==0){
			cout<<"1 hour"<<endl;
		}
		else if(minute !=0 && seconds==0){
			cout<<hour<<" hours, and "<<minute<<" minutes."<<endl;
		}
		else{
			cout<<hour<<" hours, "<<minute<<" minutes, and "<<seconds<<" seconds."<<endl;
		}
	}
	else if (day==0 && hour==0 &&minute>=1){
		if (minute==1 && seconds==0){
			cout<<"1 minute"<<endl;
		}
		else{
			if (seconds==0){
				cout<<minute<<" minutes."<<endl;
			}
			else{
				cout<<minute<<" minutes, and "<<seconds<<" seconds"<<endl;
			}
		}
	}
	else{
		if (seconds==1){
			cout<<"1 second."<<endl;
		}
		else{
			cout<<seconds<<" seconds."<<endl;
		}
	}
}
int main(){
	int secsM;
	cout<<"Insert time in seconds"<<endl;
	cin>>secsM;
	if (secsM>604800){
		cout<<"This will not convert anything beyond 7 days, try again"<<endl;
		cin>>secsM;
	}
	else if (secsM<1){
		cout<<"No negative numbers, try again."<<endl;
		cin>>secsM;
	}
	
	time_converter(secsM);
	
	return 0;
}
