#include <iostream>
using namespace std;
int main(){
	int number, choice;
	cout<<"Enter number: \n";
	cin>>number;
	cout<<" 1) Is Input divisible by 5 and 6 \n";
	cout<<" 2) Is Input divisible by 5 or 6 \n";
	cout<<" 3) Is Input divisible by 5 or 6, not by both \n";
	cin>>choice;
	
	if (choice == 1){
		if(number % 5==0 && number % 6==0){
			cout<<"Its divisible by 5 and 6"<<endl;
		}
		else
			cout<<"Not divisible by 5 and 6\n";
	}
	
	else if(choice==2){
		if(number%5==0 || number%6==0){
			cout<<"It is divisble by five or 6\n";
		}
		else
			cout<<"It's not divisble by either five, nor six\n";
		
	}
	else if(choice==3){
		if((number%5==0 ^ number%6==0)){
			cout<<"Its divisible by five or six but not both";
		}
		else
			cout<<"Its either divisible by both or by none at all\n";
	}
	else if(choice==0){
		cout<<"Any division with zero in the numerator is zero \n";
	}

	return 0;
}
