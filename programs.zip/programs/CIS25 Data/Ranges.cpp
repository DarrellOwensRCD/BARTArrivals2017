#include <iostream>
#include <limits>
using namespace std;
using std::numeric_limits;
int main()
{ 
    cout << "Min data for int is "<< numeric_limits<int>::min() << " and max is " << numeric_limits<int>::max()<<endl;
    cout << "Min data for unsigned int is "<< numeric_limits<unsigned int>::min() << " toand max is " << numeric_limits<unsigned int>::max()<<endl;
    cout << "Min data for long long is "<< numeric_limits<long long>::min() << " and max is " << numeric_limits<long long>::max()<<endl;
    cout << "Min data for char is "<< (int)numeric_limits<char>::min() << " and max is " << (int)numeric_limits<char>::max()<<endl;
    cout << "Min data for signed char is "<< (int)numeric_limits<signed char>::min() << " and max is " << (int)numeric_limits<signed char>::max()<<endl;
    cout << "Min data for unsigned char is "<< (int)numeric_limits<unsigned char>::min() << " and max is " << (int)numeric_limits<unsigned char>::max()<<endl;
    return 0;
}
