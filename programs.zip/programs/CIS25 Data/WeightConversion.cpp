#include <iostream>
#include "WeightConversion.h"
using namespace std;

float create(int i){
	return (float) i/9.807;
}
int main(){
	cout<<"Main function that'll send the numerical conversion"<<endl;
}
