// Final project
#include <iostream>
#include<iomanip>
#include <fstream>
using namespace std;
float loanAmount, 
        monthlyPayment,
        interestRate,
        totalPaid = 0,
        toAdd =0,
        interesttoAdd = 0,
        remaining;
        
int nMonth = 0;
double userIncome=0;

void getInfo();
void calculate();
void saveName(string &name);
void saveIncome(double uIncome);
void saveCar(string &car);
void printLastInfo();
void fileInfo();
//global variables

int main()
{
    cout << "\t\t.Loan calculator program. " << endl
        << "\tThis program will tell you whether this loan is a good financial decision." << endl;
    
    //to get and validate user input
    cout<<endl;
    printLastInfo();
    cout<<endl;
    fileInfo();
    getInfo();
    
    remaining = loanAmount;
    
    cout << "\tHere is a time table of your loan payoff progress" << endl;
    
    calculate();
    
    cout << "\n\tHere is the breakdown: " << endl;
    cout << "Your loan is " << loanAmount << endl;
    cout << "You have to pay back " << totalPaid << endl;
    cout << "You will be in this contract for " << nMonth << " months" << endl;
    cout << "You will be overpaying by " << (totalPaid / loanAmount) << " percent" << endl;
    return 0;
}


void getInfo()
{
    cout << "How much loan did you get approved for? ";
    cin >> loanAmount;
    cout << endl;
    while (loanAmount <= 0 )
    {
        cout << "Invalid input. What is the loan amount? ";  
        cin >> loanAmount;
    }
    
    cout << "What is the interest rate? ";
    cin >> interestRate;
    cout << endl;
    while (interestRate <= 0 )
    {
        cout << "Invalid input. What is the interest rate? ";  
        cin >> interestRate;
    }
    interestRate /= 100;
   
    cout << "How much are you willing to pay each month towards this loan? ";
    cin >> monthlyPayment;
    cout << endl;
    while (monthlyPayment <= 0 )
    {
        cout << "Invalid input. How much are you willing to pay each month towards this loan? ";  
        cin >> monthlyPayment;
    }
    while(monthlyPayment < loanAmount * interestRate / 12)
    {
        cout << "That's not enough. Based on your interest rate the monthly amount cannot be less than $" 
            << (loanAmount * interestRate / 12) << endl
            << "Try again ";
        cin >> monthlyPayment;
    }
}
void calculate()
{
      cout << "Month #, interest added, amount paid, dept remaining." << endl;
    
    while (remaining > 0)
    {
        interesttoAdd = remaining * interestRate / 12;
        nMonth++;
        remaining += interesttoAdd;
        
        if(remaining > monthlyPayment)
            toAdd = monthlyPayment;
        else
            toAdd = remaining;
            
        cout << fixed << setw (10) << setprecision (3) << endl;
        cout << "Month " << nMonth << ": $" << interesttoAdd << ", $"
            << toAdd << ", $" << remaining << endl;
        totalPaid += toAdd;
        remaining -= toAdd;
    }
}
void fileInfo()

{

    string name, car;

    cout << "What is your first name? Without any spaces-";

    cin >> name;
    saveName(name);

    cout << "What car are you trying to purchase?";

    cin >> car;
    saveCar(car);

    cout<<"Enter your annual income, after taxes: ";

	cin>>userIncome;
	saveIncome(userIncome);
}
void saveIncome(double uIncome){	
    ofstream fileOUT("income.txt"); // open filename.txt in append mode
    fileOUT << uIncome; // append "some stuff" to the end of the file
    fileOUT.close(); // close the file
}
void saveName(string &name){
	ofstream fileOUT("name.txt"); 
    fileOUT << name;
    fileOUT.close(); 	
}
void saveCar(string &car){
	ofstream fileOUT("car.txt");
    fileOUT << car;
    fileOUT.close();	
}
void printLastInfo(){
	string i, c, n;
	ifstream readFile1("name.txt");
	ifstream readFile2("income.txt");
	ifstream readFile3("car.txt");
	cout<<"Data on file from last user: "<<endl;
	while(getline(readFile1, n)){
		if(n.length()==0){
			cout<<"Empty file"<<endl;
		}
		else{
			cout<<"Name "<<n<<endl;
		}
	}
	readFile1.close();
	while(getline(readFile2, c)){
		if(c.length()==0){
			cout<<"Empty file"<<endl;
		}
		else{
			cout<<"Car: "<<c<<endl;
		}
	}
	readFile2.close();
	while(getline(readFile3, i)){
		if(i.length()==0){
			cout<<"Empty file"<<endl;
		}
		else{
			cout<<"Income: "<<i<<endl;	
		}
	}
	readFile3.close();
	cout<<endl;
}
