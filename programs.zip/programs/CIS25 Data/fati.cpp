#include <iostream>
using namespace std;
class converter{ 
	public: 
	
	int days=24;
	
	int hours=60;
	
	int minutes=60;
	
	int seconds;
	converter(int input_seconds ){	
	
		days = input_seconds / 60 / 60 / 24;
		
		hours = (input_seconds / 60 / 60) % 24;
		
		minutes = (input_seconds / 60) % 60;
		
		seconds = input_seconds % 60;
	}
	
	int return_days(){
		
		return days;
		
	}
	
	int return_hours(){
		
		return hours;
		
	}
	
	int return_minutes(){
		
		return minutes;
		
	}
	
	int return_seconds(){
		
		return seconds;
		
	}
	
};
int main(){
	int user_seconds;
	
	cout<<"Input in seconds the time, and this will convert it into days, hours, minutes, and seconds: "<<endl;
	
	cin>>user_seconds;
	while (user_seconds>=604800){
		
		cout<<"This is invalid--please insert a smaller time frame below 7 days: "<<endl;
		
		cin>>user_seconds;
		
	}
	
	converter time(user_seconds);
	
	if(user_seconds==60){
		
		cout<<time.return_minutes()<<" minute.";
		
	}
	else if(user_seconds==3600){
		cout<<time.return_minutes()<<" hour.";
	}
	else if(user_seconds==86400){
		cout<<time.return_hours()<<" day"
	}
	
	cout<<"Days: "<<time.return_days()<<"; Hours: "<<time.return_hours()<<"; Minutes: "<<time.return_minutes()<<"; Seconds: "<<time.return_seconds()<<endl;
	return 0;
}
