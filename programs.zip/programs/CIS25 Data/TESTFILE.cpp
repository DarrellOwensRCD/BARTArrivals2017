// Example program
#include <iostream>
using namespace std;

int main()
{
 string word="darrell";
 int count=0;
 for(;;){
     if(word[count]=='\0'){
     	break;
	 }
	 else{
	 	count=count+1;
	 }
 }

cout<<"Amount of words in string is..."<<count<<endl;
 return 0;
}
