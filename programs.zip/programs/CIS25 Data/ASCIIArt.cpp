//Darrell Owens
//9/11/2017
//CIS 25: Task 2
#include <iostream>
using namespace std;
int main(){
cout<<"  	    '__' \n";
cout<<"            (oo)	\n";
cout<<"    +========\\/ \n";
cout<<"   / || %%% ||  	\n";
cout<<"  *  ||-----||  	\n";
cout<<"     \"\"     \"\"	\n";	
return 0;
}
