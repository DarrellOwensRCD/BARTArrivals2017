//Darrell Owens
//CIS 25: Assignment 6 Functions
//Edited with Quit Request
//0/13/2017
#include <iostream>
using namespace std;
void mercury(float& x){
	x*=3.8;

}
void mars(float& x){
	x*= 3.8;

}
void venus(float& x){
	x*=9.1;

}
void moon(float& x){
	x*=1.6;
}
void allConvos(float x){
	
	cout<<"Your weight on Mercury is "<<x*3.8<<endl;
	cout<<"Your weight on Venus is  "<<x*9.1<<endl;
	cout<<"Your weight on Mars is   "<<x*3.8 <<endl;
	cout<<"Your weight on the moon is "<<x*1.6<<endl;
}

int main(){
	float weight;
	int input;
	cout<<endl;
	cout<<"Give me your weight and I'll print it's values on the following planets"<<endl;
	cin>>weight;
		
	if(weight <1){
		cout<<"Doesn't work--enter a valid weight"<<endl;
		cin>>weight;
	}
		
	int choice; 
	do{	
		float mass=(float)weight/9.807;
	
			
		cout<<"Press 1 for Mercury weight "<<endl;
		cout<<"Press 2 for Mars Weight "<<endl;
		cout<<"Press 3 for Venus weight " <<endl;
		cout<<"Press 4 for Earth's Moon weight "<<endl;
		cout<<"Press 5 for All Conversions"<<endl;
		cout<<"Press 6 to quit"<<endl;
		cin>>choice;
		
	switch(choice){
		case 1: 
		{
			mercury(mass);
			cout<<"Weight on Mercury: "<<mass<<endl;
		break;
		}
		case 2:
		{
			mars(mass);
			cout<<"Weight on Mars: "<<mass<<endl;
		break;
		}

		case 3:
		{
			venus(mass);
			cout<<"Weight on Venus: "<<mass<<endl;
			break;
		}
		case 4: 
		{
			moon(mass);
			cout<<"Weight on Moon: "<<mass<<endl;
			break;
		}
		case 5:{
			allConvos(mass);
			break;
		}
	}
} while (choice !=6);

cout<<"Thank you, this program will terminate"<<endl;
	return 0;
}
