//Darrell Owens
//CIS 25: PrintPattern 
//Assignment 2
//8/26/2017
#include <iostream>
using namespace std;
int main(){

cout<<"* * * * *      * * * * *     * * * * *         *"<<endl;
cout<<" * * * * *     *       *      *     *         * *"<<endl;
cout<<"* * * * *      *       *       *   *         *   *"<<endl;
cout<<" * * * * *     *       *        * *           * *"<<endl;
cout<<"* * * * *      * * * * *         *             *"<<endl;
cout<<"   (a)            (b)           (c)           (d)"<<endl;

return 0;
}
