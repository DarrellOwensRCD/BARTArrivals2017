//Darrell Owens
#include <iostream>
using namespace std;
int main()
{

cout<<"Hello World, from Visual C++"<<endl;
	return 0;
}


