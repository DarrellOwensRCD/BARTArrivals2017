#include <iostream>
using namespace std;
int biggerarray(int list_1[], int list_2[]){
	int first_sum=0;
	int second_sum=0;
	int loop_1=0;
	while(loop_1<3){
		first_sum+=list_1[loop_1];
		second_sum+=list_2[loop_1];
		loop_1++;
	}
	cout<<"The largest array is "<<endl;
	
	if (first_sum> second_sum){
		int loop_2=0;
		while(loop_2<3){
			cout<<list_1[loop_2]<<endl;
			loop_2++;
		}
		return first_sum;
	}
	else if (first_sum<second_sum) {
		int loop_3=0;
		while (loop_3<3){
			cout<<list_2[loop_3]<<endl;
			loop_3++;
		}
		return second_sum;
	}
	else if(first_sum==second_sum){
		cout<<"The arrays are equal"<<endl;
	}
	else{
		cout<<"Error!";
	}
	
}
int main(){
	int numbers_1[]={20, 1, 3};
	int numbers_2[]={34, 12, 34};
	int answer=0;
	cout<<"This will find the bigger array!"<<endl;
	answer=biggerarray(numbers_1, numbers_2);
	cout<<"The sum is "<<answer;
}

