//Darrell Owens
//8/27/2017
//CIS 25
//Assignment 2
#include <iostream>
using namespace std;
int main()
{
	int g;
	cout<<"What's your course percentage?\n";
	cin>>g;
	
	if (g<70) {
		cout<<"D or lower";
	}
	else if ( g<=80) {
		cout<<"C"<<endl;
	}
	else if (g<=90){
		cout<<"B"<<endl;
	}
	else if (g<=100){
		cout<<"A, congrats"<<endl;
	}
	else {
		cout<<"You inserted something wrong"<<endl;
	}
	return 0;
}


