#include <iostream>
using namespace std;
int main(){

//A: Basic for loop)
	for (int i=2; i<=100; i+=2){
		cout<<i<<endl;
	}


//B: Prints to 100 via 50 iterations)
	int i=2;
	for (int k=0; k<50; k++){
		cout<<i<<endl;
		i+=2;
	} 


//C Prints to 100 via decrements to 0)
	int i=2;
	for (int n=100; n>0; n-=2){
		cout<<i<<endl;
		i+=2;
	}



//D: Infinite loop with break statement)
	int i=2;
	for(;;){
		cout<<i<<endl;
		i+=2;
		if (i>100)
		break;
	}

	
//E: Printing to 100 using while-loop)
	int i=2;
	while(i<=100){
		cout<<i<<endl;
		i+=2;
	}

//F: Printing to 100 using do-while loop)
	int i=2;
	do{
		cout<<i<<endl;
		i+=2;
	} while(i<=100);
	
}
