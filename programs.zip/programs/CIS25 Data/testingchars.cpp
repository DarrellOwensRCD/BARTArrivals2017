// Example program
#include <iostream>
#include <string>
using namespace std;
int main()
{
 char a='a';
 for (int i=0; i<30; i++){
    cout<<a;
    a++;
 }
}

