//Darrell Owens
//Constructor Overloading
//11.8.2017
//CIS 25
#include <iostream>
using namespace std;
class apple{
	public: 
	apple(int apple, int pear){
		oz=apple+pear;
	}
	apple (int apple, double pear){
		oz=(apple+pear);
	}
	
	void print(){
		cout<<"Same constructor, different paramaters "<<oz<<endl;
	}
	protected: 
		double oz;
		
};
int main(){
	apple a(12, 20);
	a.print();
	apple b(12, 20.5);
	b.print();
	
return 0;
}


