//Darrell Owens
//12/11/2017
//CIS 25 
//Final Exam: Problem 1
#include <iostream>
using namespace std;
class clock{ //Class data structure
	public: //variable members
		int day;
		int seconds;
		int hour;
		int minute;
		int secs;
	void setTime(int given){ //set method
			secs=given;	
			day=secs/ 86400;
			seconds=secs % 86400;
			hour=seconds/3600;
			seconds=secs % 3600;
			minute=seconds/60;
			seconds= seconds % 60;
	}
	int getDays(){ //get methods
		return day;
	}
	int getHours(){
		return hour;
	}
	int getMinutes(){
		return minute;
	}
	int getSeconds(){
		return seconds;
	}
};
int main(){	//main
	int time, result;
	char retry;
	clock a;		//Clock pointer (object)
	int da,hr,mi,sc; //getting by values set up
	
	while (retry!='n'){
	cout<<"Give me your time to convert to days, hours, seconds and minutes."<<endl;
	cin>>time;
	
		if (time>604800){
		cout<<"Sorry, no input greater than 7 days, try again: "<<endl;
		cin>>time;
	}
	a.setTime(time);
	 
	if(time>=86400){ 				//Get all values for days
		da=a.getDays();				
		hr=a.getHours();
		mi=a.getMinutes();
		sc=a.getSeconds();
		if( hr==0 && mi==0 && sc==0){
			cout<<"Days: "<<da<<endl;
		}
		else{
			cout<<da<<" Days, "<<hr<<" Hours, "<<mi<<" Minutes, and "<<sc<<" Seconds."<<endl;
		}
	}
	else if(time >=3600){          //Getting only hours minutes and seconds now
		hr=a.getHours();
		mi=a.getMinutes();
		sc=a.getSeconds();
		if(mi==0 && sc==0){
			cout<<"Hours: "<<hr<<endl;
		}
		else{
			cout<<hr<<" Hours, "<<mi<<" Minutes, and "<<sc<<" Seconds."<<endl;
		}
	}
	else if(time >=60 ){		//Getting only minutes, and seconds
		mi=a.getMinutes();
		sc=a.getSeconds();
		if(sc==0){
			cout<<"Minutes: "<<mi<<endl;
		}
		else{
			cout<<mi<<" Minutes, and "<<sc<<" Seconds."<<endl;
		}
	}
	else{					//default to seconds
		sc=a.getSeconds();
		cout<<sc<<" seconds."<<endl;
	}
	cout<<endl;
	cout<<"Try again? Press y to continue, press n for no"<<endl;
	cin>>retry;
	}
	cout<<"Bye, bye"<<endl;
	
	return 0;
}
