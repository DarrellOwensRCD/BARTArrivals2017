/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author darrell
 */
public class BookCalc {
    public static void main (String[] args){
        double sum=0;
        String [] book_names= {"Hellen Keller", "War and Peace", "James Bond"};
        double [] book_prices={16.88, 23.15,17.00};
        for (int i=0; i< book_names.length; i++ ){
            System.out.println(book_names[i]+ " $."+ book_prices[i]);
            sum=book_prices[i]+sum;
        }
        double tax=2.99*book_names.length;
        double total=sum+tax;
        System.out.println("Total tax: $." + (2.99*book_names.length));
        System.out.println("Total price: $."+ total);
    }
}
