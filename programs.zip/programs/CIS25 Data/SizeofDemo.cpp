//Sizeof Demo Program 
#include <iostream>  
using namespace std;  
int main()  
{  
   cout  << "The size of a char is: "  
         << sizeof( char )<<endl;
   cout  << "The size of a int is: "  
         << sizeof( int )<<endl; 
   cout  << "The size of a short int is: "  
         << sizeof( short int )<<endl; 
   cout  << "The size of a long int is: "  
         << sizeof( long int )<<endl; 
   cout  << "The size of a float is: "  
         << sizeof( float )<<endl; 
   cout  << "The size of a double is: "  
         << sizeof( double )<<endl; 
   cout  << "The size of a wchar_t is: "  
         << sizeof( wchar_t )<<endl; 
   return 0;
}  
