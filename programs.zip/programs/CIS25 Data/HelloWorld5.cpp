#include <iostream>
using namespace std;
int main(){
	cout<<"This is the fifth take!"<<endl;
	return 0;
}
