#include <iostream>
#include <fstream>
using namespace std;
void saveIncome(string &income){	
    ofstream fileOUT("income.txt"); // open filename.txt in append mode
    fileOUT << income; // append "some stuff" to the end of the file
    fileOUT.close(); // close the file
}
void saveName(string &name){
	ofstream fileOUT("name.txt"); 
    fileOUT << income;
    fileOUT.close(); 	
}
void saveCar(string &car){
	ofstream fileOUT("car.txt");
    fileOUT << income;
    fileOUT.close();	
}

int main(){
	string income, name, car;
	cout<<"Income: "<<endl;
	getline(cin, income);
	saveinfo(income);
	cout<<"Name: "<<endl;
	getline(cin, name);
	cout<<"Car: "<<endl;
	getline(cin, car);
	return 0; 
}
