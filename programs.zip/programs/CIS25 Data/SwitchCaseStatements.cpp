//Darrell Owens 
//CIS 25 
//Case Statement Months
//9/25/2017
#include <iostream>
using namespace std;
int main(){
	int i;
	cout<<"Provide the month by number and I'll return the days: "<<endl;
	cin>>i;
	switch(i){
	case 1: cout<<"There are 31 days in January\n";
	break;
	case 2: 
			int n;
			cout<<"What year is it?"<<endl;
			cin>>n;
			if ((n % 4 == 0) && !(n % 100 == 0)|| (n % 400 == 0)){
				cout<<"Leap year: 28 days in Feburary \n";
			}
			else{
				cout<<"Feburary has 29 days \n";
			}
			break; 
	case 3: cout<<"There are 31 days in March \n"; 
	break;
	case 4: cout<<"There are 30 days in April \n";
	break;
	case 5: cout<<"There are 31 days in May \n";
	break;
	case 6: cout<<"There are 30 days in June \n";
	break;
	case 7: cout<<"There are 31 days in July \n";
	break;
	case 8: cout<<"There are 31 days in August \n";
	break;
	case 9: cout<<"There are 30 days in September \n";
	break;
	case 10:cout<<"There are 31 days in October \n";
	break;
	case 11: cout<<"There are 30 days in November \n";
	break;
	case 12: cout<<"There are 31 days in December \n";
	break;
	
	default:
		cout<<"Your input is invalid"<<endl;
	}
	
	return 0;	
}
