#include <iostream>
#include <vector>
using namespace std;
class Vector{
	public:
	int count=0;
	vector<int> array(10);

	void fillVector(){
		if(count<10){
			array[count]=count+1;
			count++;
			cout<<"Array filled w/ "<<count+1<<endl;
			return fillVector;
		}
		else if(counter==10){
			cout<<"We're done"<<endl;
		}
	}

};
int main(){
	Vector a;
	a.fillVector();

	return 0;
}
