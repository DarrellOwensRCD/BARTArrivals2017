#include <iostream.h>
using namespace std;
int main() {
	cout<<"Goddamn, work!"<<endl;
	return 0;
}