#include <iostream>
#include <vector>
#include <ctime>
#include <algorithm>
using namespace std;
int main(){
 cout<<"Hello world"<<endl;
    return 0;
};

