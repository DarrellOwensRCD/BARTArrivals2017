#include <iostream>
#include <cctype>
#include <cstdlib>
#include <ctime>
using namespace std;
class Calculation{
	public:
	float *list=NULL;
	int gSIZE;
	void randomization(){
		srand (time(NULL));
		gSIZE=1000;
		list=new float [gSIZE];
		for(int i=0; i<gSIZE; i++){
			list[i]=(rand() % 1000)+1;
		}
	}
	
	void summation(){
		float sum;
		for(int i=0; i<gSIZE; i++){
			sum+=list[i];
		}
		cout<<"Sum of list is: "<<sum<<endl;
		delete[] list;
	}
	
	void user_sum(){
		
		float hold;
			cout<<"How many numbers? "<<endl;
			cin>>gSIZE;
			list=new float[gSIZE];
			for(int i=0; i<gSIZE; i++){
				cout<<i+1<<". ";
				cin>>list[i];
			}
	}
	void print(){
		for(int i=0; i<gSIZE; i++){
			cout<<list[i]<<" ";
		}
		delete[] list;
	}
	
};
int main(){
	Calculation a;
	a.randomization();
	a.summation();
	a.user_sum();
	a.print();
}
