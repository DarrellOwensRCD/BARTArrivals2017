//Darrell Owens
//CIS 25
//Weight Program
//11/4/2017
#include <iostream>
#include "weight_conversion3.cpp"
using namespace std;
int main(){
	Weight Object;
	int choice, weight1;
	float mass;
	cout<<"Give me your weight and I'll print it's values on the following planets"<<endl;
	cin>>weight1;

	if(weight1 <0){
		cout<<"Doesn't work--enter a valid weight"<<endl;
		cin>>weight1;
	}
	if(weight1!=0){
		Object.Set(weight1);
		Object.Get();
	}
	if(weight1==0){
        Object.Get();
	}

	do{
		cout<<"Press 1 for Mercury weight "<<endl;
		cout<<"Press 2 for Mars Weight "<<endl;
		cout<<"Press 3 for Venus weight " <<endl;
		cout<<"Press 4 for Earth's Moon weight "<<endl;
		cout<<"Press 5 for All Conversions"<<endl;
		cout<<"Press 6 to quit"<<endl;
		cin>>choice;

	switch(choice){
		case 1:
		{
			mercury(mass);
			cout<<"Weight on Mercury: "<<mass<<endl;
		break;
		}
		case 2:
		{
			mars(mass);
			cout<<"Weight on Mars: "<<mass<<endl;
		break;
		}

		case 3:
		{
			venus(mass);
			cout<<"Weight on Venus: "<<mass<<endl;
			break;
		}
		case 4:
		{
			moon(mass);
			cout<<"Weight on Moon: "<<mass<<endl;
			break;
		}
		case 5:{
			allConvos(mass);
			break;
		}
	}
} while (choice !=6);
}
