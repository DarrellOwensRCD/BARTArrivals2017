#include <iostream>
#include <string>
#include<time.h>
using namespace std;
int main(){
	string phrase="Today is a beautiful day";
	string user;
	int counter=0;
	int check;
	clock_t previousTime = clock();
	cout<<"Type this exactly: "<<phrase<< "\n press enter when done."<<endl;

		getline(cin, user);
	int numSecondsPassed = ( clock() - previousTime ) / CLOCKS_PER_SEC;
	for (int i=0; i<20; i++){
		cout<<phrase[i]<<endl;
	}

	for (int i=0; i<phrase.size(); i++){
		if(user[i]!=phrase[i]){
			cout<<"This was wrong: "<<user[i]<< " vs. "<<phrase[i]<<endl;
			counter=counter+1;
		}
		else{
			cout<<"This was same: "<<user[i]<<endl;
		}
		
	}
	cout<<"Here is the amount of errors: "<<counter<<endl;
	cout<<"Here is your time: "<<numSecondsPassed<<endl;
	return 0;
}
