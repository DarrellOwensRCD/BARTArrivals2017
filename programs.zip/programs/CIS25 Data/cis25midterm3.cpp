#include <iostream>
using namespace std;
void biggerArray(int array1[], int array2[], int x);
int main(){
	int arrayA[]={1, 2, 3, 4, 5};
	int arrayB[]={1, 2, 3, 4, 6};
	cout<<"Between Arrays: "<<endl;

	biggerArray(arrayA, arrayB, 5);
	
	return 0;
}
void biggerArray(int array1[], int array2[], int x){
	int sum1=0; 
	int sum2=0;
	
	for (int i=0; i<x; i++){
		sum1=sum1+array1[i];
		sum2=sum2+array2[i];
	}
	if (sum1> sum2){
		cout<<"Array 1 is the biggest with the following elements: "<<endl;
		for (int n=0; n<x; n++){
			cout<<array1[n]<<" ";
		}
		cout<<endl;
		cout<<"And a sum of "<<sum1;
	}
	else if(sum2> sum1){
		cout<<"Array 2 is the biggest with the following elements"<<endl;
		for(int m=0; m<x; m++){
			cout<<array2[m]<<" ";
		}
		cout<<endl;
		cout<<"And a sum of "<<sum2;
	}
	else{
		cout<<"Both arrays had the same value, with a following sum of "<<sum1;
	}
}

