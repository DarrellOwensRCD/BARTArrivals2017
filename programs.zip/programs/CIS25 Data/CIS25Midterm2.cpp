#include <iostream>
using namespace std;
void swap(int array[], int x);
int main(){
	cout<<"This is the array: ";
	int list[]={10, 7, 100, 65, 435};
	int y=5;
	for (int i=0; i<5; i++)
	cout<<list[i]<<" ";
	
	swap(list, y);
	
	return 0;
}
void swap(int array[], int x){
	int hold=array[0];
	int hold2=array[x-1];
	for (int i=0; i<x; i++){
		if (i==0){
			array[i]=hold2;
		}
		else if (i==(x-1)){
			array[i]=hold;
		}
		
	}
	cout<<endl;
	cout<<"Now, Array last position and first position swapped"<<endl;
	for (int z=0; z<x; z++){
		cout<<array[z]<<" ";
	}
}
