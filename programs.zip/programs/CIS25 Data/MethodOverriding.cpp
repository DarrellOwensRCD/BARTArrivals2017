//Darrell Owens
//11/8/2017
//CIS 25
//Overriding Method
#include <iostream>
using namespace std;
class Jedi{
	public:
		void starships(){
			cout<<"This is method overriding"<<endl;
		}
		void juice(int x, double y){
			cout<<"Called from method one\n";
		}
		void juice (int x, int z){
			cout<<"Called from method two\n";
		}
};
class Derived: public Jedi{
	public: 
		void starships(){
			Jedi::starships();
			cout<< "and I concure. "<<endl;
		}
};
int main(){
	Derived a;
	a.starships();
	a.juice(1, 2);
	a.juice(1, 2.5);
	return 0;
}
