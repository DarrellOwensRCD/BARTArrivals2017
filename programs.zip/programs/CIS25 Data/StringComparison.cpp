#include <iostream>
#include <string>
using namespace std;
int main(){
	string input3="WWWWW";
	string input []={"WWWWW", "HHHH"};
	int i=1;
	while(i<2){
		if(!input[i].compare(input3)){
			cout<<"They're same"<<endl;
		}
		else{
			cout<<"Strings are not the same"<<endl;
		}
		i++;
	}
	return 0;
}
