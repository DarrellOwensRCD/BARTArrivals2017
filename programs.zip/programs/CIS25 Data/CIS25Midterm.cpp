#include <iostream>
using namespace std;
int main(){
	int vowel=0;
	int consonants=0;
	int counter=0;
	string input;
	cout<<"Enter a string: "<<endl;
	cin>>input;
	
	for (int i=0; i<input.length(); i++){
		if(input[i]=='a'|| input[i]=='e' || input[i]=='i'|| input[i]=='o' || input[i]=='u' || input[i]=='y'){
			counter=counter+1;
		}
		
	}
	cout<<"The string has: "<<counter<<" vowels \n";
	cout<<"and has "<<input.length()-counter<<" consonants"<<endl;
	return 0;
}

