//Darrell Owens
//CIS 25
//Weight Program with Kilos
//11/7/2017
#include <iostream>
#include "Weight_Conversion.cpp"
using namespace std;
int main(){
	kilograms Object;
	int choice,  weight1;
	char weight2;
	float mass;
	cout<<"Give me your weight and I'll print it's values on the following planets (in pounds)"<<endl;
	cin>>weight1;
	
	cout<<"Would you like it in kilos (k) or stay in pounds (l)?"<<endl;
	cin>>weight2;

	if(weight1>0 && weight2=='l'){
		cout<<"Output will be in lbs"<<endl;
		Object.Set(weight1);
		Object.Get();
	}
	if(weight1 >0 && weight2=='k'){
		cout<<"Output will be in kilos"<<endl;
		Object.Set(weight1);
		Object.converterGet();
		Object.converterSet();
	}
	if(weight1==0 || weight1<0){
		cout<<"Default weight is 100 in constructor"<<endl;
        Object.Get();
	}

	do{
		cout<<endl;
		cout<<"Press 1 for Mercury weight "<<endl;
		cout<<"Press 2 for Mars Weight "<<endl;
		cout<<"Press 3 for Venus weight " <<endl;
		cout<<"Press 4 for Earth's Moon weight "<<endl;
		cout<<"Press 5 for All Conversions"<<endl;
		cout<<"Press 6 to change kilo/lbs"<<endl;
		cout<<"Press 7 to quit"<<endl;
		cin>>choice;

	switch(choice){
		case 1:
		{
			cout<<"Weight on Mercury: "<<Object.getmercury()<<endl;
		break;
		}
		case 2:
		{
			cout<<"Weight on Mars: "<<Object.getmars()<<endl;
		break;
		}

		case 3:
		{
			cout<<"Weight on Venus: "<<Object.getvenus()<<endl;
			break;
		}
		case 4:
		{
			cout<<"Weight on Moon: "<<Object.getmoon()<<endl;
			break;
		}
		case 5:{
			Object.getallConvos();
			break;
		}
		case 6:{
			char choice2;
			cout<<"Kilo (k) or Lbs (l)"<<endl;
			cin>>choice2;
			if (choice2 =='k'){
				cout<<"Converted to Kilos, now"<<endl;
				Object.Set(weight1);
				Object.converterGet();
				Object.converterSet();
			}
			if (choice2 =='l'){
				cout<<"Converted to Pounds, now"<<endl;
				Object.Set(weight1);
				Object.Get();				
			}
			break;
		}
	}
} while (choice !=7);
}

