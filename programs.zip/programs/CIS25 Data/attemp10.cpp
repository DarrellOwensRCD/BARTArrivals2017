#include <vector>
#include <iostream>
using namespace std;

int main(){
    vector<int> values(10);
    for (int i=0; i<10; i++){
        values[i]=i+1;
    }
    cout<<"Vector made, Values Filled"<<endl;
    for (int n=0; n<10; n++){
        cout<<values[n]<<" ";
    }
    cout<<endl;
    cout<<"Implementing a Vector iterator:"<<endl;
    for (vector<int>::iterator i = values.begin(); i != values.end(); ++i)
    {
        cout << *i << " ";
    }

    cout<<"\nCurrent vector size: "<<values.size()<<endl;
    values.resize (5);
    cout<<"Cutting the vector in half in size"<<endl;
    cout<<"Current vector size: "<<values.size()<<endl;
    cout<<"Demo of Pushback"<<endl;
    for (int k =1; k<10; k++){
        values.push_back(k+1);
    }
    for (int i=0; i<9; i++){
        cout<<values[i]<<" ";
    }
    cout<<"Demo of pop back"<<endl;
    cout<<"Size: "<<values.size()<<endl;
    values.pop_back();
    cout<<"Pop back!"<<endl;
    cout<<"Size: "<<values.size()<<endl;

}
