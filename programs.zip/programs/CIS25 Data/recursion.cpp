#include <iostream>
#include <cstdlib>
#include <ctime>
#include <vector>
using namespace std;
class Vector{
	protected:
	vector<double> array=vector<double>(100);
	vector<double> val{vector<double>(100,0)};
	
	
	public:
		int count=0;
		int count1=0;
		double sum=0;
	int fillVector(){
		if(count<100){
			array[count]= rand() % 100 + 1;
			count++;
			return fillVector();
		}
		else if(count==100){
			cout<<"Array filled with 100 random numbers"<<endl;
			return 0;
		}
	}
	
	int print(){
		if(count1<100){
			sum+=array[count1];
			count1++;
			return print();
		}
		else if (count1==100){
			cout<<"Sum of vector is "<<sum<<endl;
			return 0;
		}
	}

	
};
int main(){
	srand(time(NULL));
	Vector a;
	a.fillVector();
	a.print();
	
	return 0;
}
