#include<iostream>
#include <fstream>
#include<string>

using namespace std;



//function prototypes

void getInfo();

void fileInfo();

void calculations();

void suggestion();
void saveName(string &name);
void saveIncome(double uIncome);
void saveCar(string &car);
void printLastInfo();

//global variables

double loan_amount,

        interest_rate,

        interest,

        number_of_years,

        total_amount,

        monthly_amount,

        userIncome;



int main()

{     

    cout << "\t\t.Loan Calculator Program."

        << "\n\tProvide the needed information and we'll compute whether \n\tbuying this car is a good financial choice.\n";

	printLastInfo();

    fileInfo();

    getInfo();

    

    calculations();



    cout << "The interes you will pay in dollar amounts is " 

        << interest << endl;

    

    if ( total_amount >= (userIncome / 2))

    {

        cout << "Do not take the loan!" << endl;

        suggestion();

    }

    else if (total_amount > userIncome)

        cout << "You might be able to purchce the car, but the loan interest is way too high!" << endl;

    else

        cout << "Based on your income, the loan and the car are a safe decision." << endl;

        

	return 0;

}



/****************************************************

 * Function definition of fileInfo. 

 * Gets user information and saves on a file

****************************************************/

void fileInfo()

{

    string name, car;

    cout << "What is your first name? Without any spaces-";

    cin >> name;
    saveName(name);

    cout << "What car are you trying to purchase?";

    cin >> car;
    saveCar(car);

    cout<<"Enter your annual income, after taxes: ";

	cin>>userIncome;
	saveIncome(userIncome);
}

/****************************************************

 * Function definition of getInfo. 

 * Gets user information

 * Validates user input

****************************************************/

void getInfo()

{

    cout << "\n\tYou were given the option to purchace with a loan." << endl;

	

	cout<<"Enter the loan amount: ";

	cin>>loan_amount;

	while (loan_amount <= 0)

    {

        cout << "That is not a valid input. Try again." << endl;  

        cin>>loan_amount;

    }

    

	cout<<"Enter the interest rate: ";

	cin>>interest_rate;

	while (interest_rate <= 0)

    {

        cout << "That is not a valid input. Try again." << endl;  

        cin>>interest_rate;

    }

    

	cout<<"The number of years: ";

	cin>>number_of_years;

	while (number_of_years <= 0)

    {

        cout << "That is not a valid input. Try again." << endl;  

        cin>>number_of_years;

    }

}

/****************************************************

 * Function definition of calculations. 

 * Claulcates the total amount to be paid for the car

 * Caculates the amount to be paid every month

 * Calculates the amount of interest added to the cost

****************************************************/

void calculations()

{

    total_amount=(number_of_years*loan_amount)+(number_of_years*loan_amount*(interest_rate/100.00));

	monthly_amount=total_amount/(number_of_years*12);

	interest = total_amount-(number_of_years*loan_amount);



	cout<<"Total amount to be paid: "<<total_amount<<endl;

	cout<<"Total interest: "<<interest<<endl;

	cout<<"Monthly amount to be paid: "<<monthly_amount<<endl;   

}



/****************************************************

 * Function definition of suggestion. 

 * Suggests dealers with cheap cars

****************************************************/

void suggestion()

{

    string city;

    cout << "\tBuying this car with a loan isn't a smart financial move."

        << " Consider these dealerships that sell second hand cars." 

        << "Berkeley: Buggy bank"<< endl;

    

}
void saveIncome(double uIncome){	
    ofstream fileOUT("income.txt"); // open filename.txt in append mode
    fileOUT << uIncome; // append "some stuff" to the end of the file
    fileOUT.close(); // close the file
}
void saveName(string &name){
	ofstream fileOUT("name.txt"); 
    fileOUT << name;
    fileOUT.close(); 	
}
void saveCar(string &car){
	ofstream fileOUT("car.txt");
    fileOUT << car;
    fileOUT.close();	
}
void printLastInfo(){
	string i, c, n;
	ifstream readFile1("name.txt");
	ifstream readFile2("income.txt");
	ifstream readFile3("car.txt");
	cout<<"Data on file from last user: "<<endl;
	while(getline(readFile1, n)){
		if(n.length()==0){
			cout<<"Empty file"<<endl;
		}
		else{
			cout<<"Name "<<n<<endl;
		}
	}
	readFile1.close();
	while(getline(readFile2, c)){
		if(c.length()==0){
			cout<<"Empty file"<<endl;
		}
		else{
			cout<<"Car: "<<c<<endl;
		}
	}
	readFile2.close();
	while(getline(readFile3, i)){
		if(i.length()==0){
			cout<<"Empty file"<<endl;
		}
		else{
			cout<<"Income: "<<i<<endl;	
		}
	}
	readFile3.close();
	cout<<endl;
}
