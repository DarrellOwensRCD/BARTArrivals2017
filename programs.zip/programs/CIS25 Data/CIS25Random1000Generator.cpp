//Darrell Owens
//Assignment 11: More Arrays
//9/27/2017
//CIS 25
#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;
void printArray(int array[], int x);
void oddPrint(int array[], int x);
void evenPrint(int array[], int x);
void intSearch(int array[], int x, int loc, int start);
void maxVal(int array[], int x);
void minVal(int array[], int x);
void sortArray(int array[], int x);
void firstNum(int array[]);
void lastNum(int array[], int x);
int main(){
	int choice=0;
	srand( time(NULL));
	int z=1000;
	int list [1000]={};
	for(int i=0; i<z; i++){
		list[i]=(rand() % 1000)+1;
	}
	do{
		cout<<endl;
		cout<<"Press 1 for list print.\nPress 2 for sum of odd numbers and output.\nPress 3 for sum of even numbers and output.\nPress 4 for Array Search."<<endl;
		cout<<"Press 5 for max value. \nPress 6 for min value.\nPress 7 for sort function. \nPress 8 for first number in array. \nPress 9 for last number in array."<<endl;
		cout<<"Press 0 to quit"<<endl;
		cin>>choice;
		if (choice==1){
			printArray(list, z);
		}
		else if(choice ==2){
			oddPrint(list, z);
		}
		else if(choice ==3){
			evenPrint(list, z);
		}
		else if(choice ==4){
			int indexSearch;
			cout<<"What number are you searching for, I'll return the proper index."<<endl;
			cin>>indexSearch;
			int ini=0;
			intSearch(list, z-1, indexSearch, ini);
		}
		else if(choice ==5){
			maxVal(list, z);
		}
		else if(choice==6){
			minVal(list, z);
		}
		else if(choice ==7){
			sortArray(list, z);
		}
		else if(choice ==8){
			firstNum(list);
		}
		else if(choice==9){
			lastNum(list, z);
		}
		else {
				if(choice!=0){
				cout<<"Not valid, try again"<<endl;
			}
		}
	}while (choice!=0);
	return 0;
}
/*********************************************************/

void printArray(int array[], int x){
	for(int a=0; a<x; a++){
		cout<<array[a]<<" ";
	}
}
void oddPrint(int array[], int x){
	int sum=0;
	for(int b=0; b<x; b++){
		if(array[b] % 2 != 0){
			sum+=array[b];
			cout<<array[b]<<" ";
		}
	}
	cout<<"\n \n";
	cout<<"The sum of only odd numbers is: "<<sum<<endl;
}
void evenPrint(int array[], int x){
	int sum=0;
	for(int c=0; c<x; c++){
		if(array[c] % 2 == 0){
			sum+=array[c];
			cout<<array[c]<<" ";
		}
	}
	cout<<"\n \n";
	cout<<"The sum of only even numbers is: "<<sum<<endl;
}
void intSearch(int array[], int x, int loc, int start){
	int result=0;
	bool found = false;
	while (!found && (start< x)){
		int n=start+(x-start)/2;

		if(loc > array[n])
			start=n+1;
	
		else if (loc < array[n])
			x=n-1;
		else if (n==-1)
			cout<<"Value not found"<<endl;
		else{
			result=n;
			found=true;
			cout<<"Value at index : "<<n<<endl;
		}		
	}
}

void maxVal(int array[], int x){
	int maxHold=0;
	for (int i=0; i<x; i++){
		if (array[i]>maxHold){
			maxHold=array[i];
		}
	}
	cout<<"Largest value is: "<<maxHold<<endl;
}
void minVal(int array[], int x){
	int minHold=array[0];
	for (int i=0; i<x; i++){
		if (array[i]<minHold){
			minHold=array[i];
		}
	}
	cout<<"Smallest value is: "<<minHold<<endl;
}
void sortArray(int array[], int x){
	int hold=0;
	for(int i=0; i<x; i++){
		for(int n=0; n<x-1; n++){
			if(array[n] > array[n+1]){
				hold=array[n];
				array[n]=array[n+1];
				array[n+1]=hold;
			}
		}
	}
	for(int i=x-1; i>=0; i--){
		cout<<array[i]<<" ";
	}
}
void firstNum(int array[]){
	cout<<"First number is: "<<array[0]<<endl;
}
void lastNum(int array[], int x){
	cout<<"Last number is: "<<array[x-1]<<endl;
}
