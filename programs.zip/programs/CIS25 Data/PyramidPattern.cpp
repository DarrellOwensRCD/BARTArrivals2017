#include <iostream>
using namespace std;
int main()
{
    int k=1;
    int z=2;
    int space=2*9-2;
    
    for(int i=1; i<9; i++){ //line
        for (int n=k; n>0; n--){ //Left side of pyramid
            cout<<n;
            
        }
        for (int a=space; a>0; a--){ //Spaces inbetween
            cout<<" ";
        }
        for (int b=1; b<z; b++){ //Right side of the pyramid
            cout<<b;
            
        }
        cout<<endl;
        k++;
        z++;
        space=space-2;
    }
    cout<<"  "<<"(a)"<<"       "<<"(b)"<<endl;
    return 0;
}
/*
1                1
21              12
321            123
4321          1234
54321        12345
654321      123456
7654321    1234567
87654321  12345678
  (a)       (b)

--------------------------------
Process exited after 0.0752 seconds with return value 0
Press any key to continue . . .

*/
