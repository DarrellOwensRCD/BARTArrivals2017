#include <iostream>
#include <vector>
using namespace std;
class Vector{
    public:
    void array(int n){
        cout<<"Making a vector, iterating and filling values"<<endl;
        vector<int> list(10); //make a vector
        for (vector<int> :: iterator i=list.begin(); i!=list.end();){ //vector iterator
            list.insert (list.begin() + 5, 1.4142); //fills a vector
        }
        cout<<"Resizing a vector to size "<<n<<endl;
        list.resize(n);
        for(vector<int>:: iterator i=list.begin(); i!=list.end(); ++i){
                cout<<*i<<endl;
        }
    }
};
int main(){
    Vector a;
    int b=5;
    cout<<"Filling and creating values for a vector, size 10"<<endl;
    a.array(b);

    return 0;
};
