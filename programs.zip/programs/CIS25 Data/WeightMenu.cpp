//Darrell Owens
//CIS 25 
//Weight Program 
//9/6/2017
#include <iostream>
using namespace std;
int main(){
	double weight;
	
	cout<<"Give me your weight and I'll print it's values on the following planets"<<endl;
	cin>>weight;
	
	if(weight <0){
		cout<<"Doesn't work--enter a valid weight"<<endl;
		cin>>weight;
	}
	
	else;	
		float mass=(float)weight/9.807;
		int choice; 
		
		cout<<"Press 1 for Mercury weight "<<endl;
		cout<<"Press 2 for Venus Weight "<<endl;
		cout<<"Press 3 for Mars weight " <<endl;
		cout<<"Press 4 for Earth's Moon weight "<<endl;
		cout<<"Press 5 for All Conversions"<<endl;
		cin>>choice; 
	
		if (choice == 1){
			float ans= mass * 3.8;
			cout<<"Your weight on Mercury is: "<<ans<<endl;
		}
		
		else if (choice == 2){
			float ans=mass * 9.1;
			cout<<"Your weight on Venus is: "<<ans<<endl;
		}
		
		else if (choice ==3){
			float ans=mass* 3.8;
			cout<<"Your weight on Mars is: "<<ans<<endl;
		}
		else if (choice == 4 ){
			float ans= mass * 1.6;
			cout<<"Your weight on the moon is: "<<ans<<endl;
		}
		else if (choice ==5 ){
			cout<<"Your weight on Mercury is "<<mass*3.8<<endl;
			cout<<"Your weight on Venus is  "<<mass*9.1<<endl;
			cout<<"Your weight on Mars is   "<<mass*3.8 <<endl;
			cout<<"Your weight on the moon is "<<mass*1.6<<endl;
		}
	
	return 0;
}
