#include <curl.h>
#include <iostream>

using namespace std;

int main(void)
{
    cout << "L1" << endl;

    CURL *curl;
    curl = curl_easy_init();

    cout << "L2" << endl;

    system("PAUSE");

    return 0;
}

