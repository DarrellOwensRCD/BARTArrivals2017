#include <iostream>
using namespace std;
int main(){
	
	int amount_a, amount_b;
	float number;
	float *Arr_b = new float[0]; //Dynamic Array A declared at zero space
	
	float *Arr_a = new float[0]; //Dynamc Array B
	
	float *Arr_c=NULL; //Declaring this empty
	
	cout<<"How many numbers into your arrayA?"<<endl;
	
	cin>>amount_a;
	
	cout<<"How many numbers into your array B"<<endl;
	
	cin>>amount_b;
	
	//This gets the size the user wants for the array
	
	cout<<"Enter values for A and press enter: "<<endl; //Putting in values into the array A
	for (int i=0; i<amount_a; i++){
		cout<<i+1<<". ";
		
		cin>>number;
		
		cout<<endl;
		
		Arr_a[i]=number;
	}
	cout<<"Enter values for B and press enter: "<<endl; //Putting in values into the array B
	for(int i=0; i<amount_b; i++){
		
		cout<<i+1<<". ";
		
		cin>>number;
		
		cout<<endl;
		
		Arr_b[i]=number;
	}
	
	Arr_c = new float[amount_b]; 					//Making Array C with size B
	
	int c_size=amount_b+amount_a;						//Giving Array C a size
	
	std::copy(Arr_b, Arr_b+amount_b, Arr_c);         //This copies the dynamic array A/B into array c by its space
	
	std::copy(Arr_a, Arr_a+amount_a, Arr_c+amount_b);  //Same
	
	cout<<"This is dynamic array C"<<endl; 
	
	for (int i=0; i<c_size; i++){
		
		cout<<Arr_c[i]<<endl;   //Printing Array C
	}
	 
	 return 0;
}
