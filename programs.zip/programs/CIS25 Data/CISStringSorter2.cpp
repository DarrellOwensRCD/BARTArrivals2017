//Darrell Owens
//10/17/2017
#include <iostream>
using namespace std;
int main(){
	string array= "darrell";
	string array2="dereckl";
	int hold;
	int x=7;
	int hold2;
	char hold_bay [x]={};
	int counter=0;
	cout<<"String 1: "<<array<<endl;
	cout<<"String 2: "<<array2<<endl;
	for(int i=0; i<x; i++){
		for(int n=0; n<x-1; n++){
			if(array[n] > array[n+1]){
				hold=array[n];
				array[n]=array[n+1];
				array[n+1]=hold;
			}
		}
		for(int f=0; f<x-1; f++){
			if (array2[f]> array2[f+1]){
				hold=array2[f];
				array2[f]=array[f+1];
				array2[f+1]=hold;
			}
		}
	}

	for (int b=0; b<x; b++){
		hold2=array2[b];
		for (int c=0; c<x; c++){
			array[c];
			if (hold2==array[c] && hold2!=hold_bay[c-1] && hold2!=array2[b-1]){
				cout<<array[c]<<" duplicated\n";
				hold_bay[c]=array[c];
				counter++;
			}
		}
	}
}

