//Darrell Owens
//Crossword Linear Search
#include <iostream>
using namespace std;
class puzz{
	public: 
	char puzzle [4][4] ={ {'f', 'k', 's','a'}, {'l', 'u', 'o','w'},  {'y', 'o', 'n', 'a'},  {'x', 't', 'o', 'y'} };
	
	void show_puzzle(){
		for(int i=0; i<4; i++){
			for(int n=0; n<4; n++){
				cout<<puzzle[i][n]<<" ";
			}
			cout<<endl;
		}
	}
	void vertical_search(string word){ //Break word down into 3 chars
		char letter1=word[0];
		char letter2=word[1];
		char letter3=word[2];
		int Col1, Col2, Col3;
		for(int i=0; i<4; i++){
			for(int n=0; n<4; n++){
				puzzle[i][n];
				if(puzzle[i][n]==letter1){ //If you find the first letter of the string, capture the position
					Col1=n;
				}
				else if(n==Col1){   	//Go through conditional statements ONLY if the row is the same as the first letter's row...		
					if(puzzle[i][n]==letter2){ //if the index is on the corresponding letter, capture the row
						Col2=n;
					}
					else if(puzzle[i][n]==letter3){
						Col3=n;
					}
				}
			}
		}
		if(Col1==Col2 && Col1==Col3){ //If all rows identifiers are the same, that means its horizontal
			cout<<"This word: "<<word<<" is in the crossword vertically, in column "<<Col1+1<<endl;
			cout<<endl;
		}
	}
	void horizontal_search(string word){ //Condition: If i is the same 3 times, and they were letters that matched, then its a valid figure. 
	char letter1=word[0];
	char letter2=word[1];
	char letter3=word[2];
	int emptyRow1, emptyRow2, emptyRow3;
		for(int i=0; i<4; i++){
			for(int n=0; n<4; n++){
				puzzle[i][n];
				if(puzzle[i][n]==letter1){
					emptyRow1=i;
				}
				
				else if(i == emptyRow1){ //if this is on the same row, go for the corresponding...
					if(puzzle[i][n]==letter2){
						emptyRow2=i;
					}
					else if(puzzle[i][n]==letter3){
						emptyRow3=i;
					}
				}
			} 
		}
		if(emptyRow1==emptyRow2 && emptyRow1==emptyRow3){
			cout<<"This word: "<<word<<" is in the crossword horizontally, on row: "<<emptyRow1+1<<endl;
			cout<<endl;
		}
	}
	void diagonal_search(string word){
		char letter1=word[0];
		char letter2=word[1];
		char letter3=word[2];
		int dC1, dC2, dC3, dR1, dR2, dR3;
		for(int i=0; i<4; i++){
			for(int n=0; n<4; n++){
				puzzle[i][n];
				if(puzzle[i][n]==letter1){ //Capture position of first letter
					dR1=i;
					dC1=n;
				}
				else if(i == dR1+1 && n==dC1+1){ //if this is one row and one column over (i.e. diagonal), then proceed..
					if(puzzle[i][n]==letter2){
						dR2=i;
						dC2=n;
					}

				}
				else if(i==dR2+1 && n==dC2+1){
					if(puzzle[i][n]==letter3){
						dR3=i;
						dC3=n;						
					}
				}
			}
		}
		if(dR1==dC1 && dR2==dC2 && dR3==dC3){
			cout<<"This word: "<<word<<" was found diagonally, starting from Row: "<<dR1+1<<" and column: "<<dC1+1<<" and, ending at row: "<<dR3+1<<" and column: "<<dC3+1<<endl;
			cout<<endl;
		}				
	}	
}; 
int main(){
	puzz a;
	a.show_puzzle();
	string word_bank[]= {"toy", "son", "fun","fly"};
	cout<<endl;
	
	cout<<"Searching for words...Toy, Son, Fun, and Fly, via linear search...."<<endl;
	cout<<"-------------------------------------------------------------------"<<endl;
	//Running through all words via an array...
	for (int i=0; i<4; i++){
		a.horizontal_search(word_bank[i]);
		a.vertical_search(word_bank[i]);
		a.diagonal_search(word_bank[i]);
	}
	return 0;
}
