#include <iostream>
using namespace std;
int main(){
	int input;
	char ch;
	do{
		cout<<"1. Convert from upper-case to lower\n";
		cout<<"2. Convert from lower-case to upper\n";
		cout<<"3. Check for English Alphabet\n";
		cout<<"4. Terminate this program\n";
		cin>>input;
		
		cout<<"Insert the character\n";
		cin>>ch;
		
		if(input == 1){
			ch=ch+32;
			cout<<"Converted: "<<ch<<endl;
		}
		else if(input == 2){
			ch=ch-32;
			cout<<"Converted: "<<ch<<endl;
		}
		else if(input == 3){
			if(isalpha(ch)){
				cout<<"This is a valid letter"<<endl;
			}
			else{
				cout<<"Invalid, is not an alphabetic charcater"<<endl;
			}
		}
	}while(input!=4);
	cout<<"Terminating--thank you"<<endl;
	return 0;
}
