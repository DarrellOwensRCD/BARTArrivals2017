#include <iostream>
using namespace std;
class Weight{
public:
    float Value, x;
    int weight;
    Weight(){
        Value=100;
    }
	public:
	void Set(int i){
		Value=i;
	}
	
	void Get(){
		cout<<"Setting/Getting value from weight_conversion file"<<endl;
		x= Value/9.807;
	}
	
	float getmercury(){
		return x*3.8;
    }
    
    float getmars(){
        return x*3.8;

    }
    float getvenus(){
        return x*9.1;

    }
    float getmoon(){
        return x*1.6;
    }
    void getallConvos(){

        cout<<"Your weight on Mercury is "<<x*3.8<<endl;
        cout<<"Your weight on Venus is  "<<x*9.1<<endl;
        cout<<"Your weight on Mars is   "<<x*3.8 <<endl;
        cout<<"Your weight on the moon is "<<x*1.6<<endl;
    }
};
class kilograms: public Weight{
	public: 
	float kw;
		void converterGet(){
			kw= Value *  0.45359237;
		}
		void converterSet(){
			x=kw/9.807;
		}
		
};


