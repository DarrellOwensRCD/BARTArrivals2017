#include <iostream>
using namespace std;
int main () { //missing main parameters
   int number = 1; //missing semicolon
   bool go=true;
   while (go){
        number++;
      //Increment on wrong side
      if ((number % 3) == 0) 
        continue; //continue not in a loop
      if (number == 133) 
        break; //break not in a loop
      if ((number % 2) == 0) {
         number += 3;
      } else {
         number -= 3;
      }
        cout<<number << " ";
   }
 //missing output arrows
   cout << endl; 
   return 0 ; //mising value 0
} //Two, too many brackets '}'
