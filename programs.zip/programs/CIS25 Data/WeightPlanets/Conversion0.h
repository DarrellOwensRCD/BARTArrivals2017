#include <iostream>
#include "Conversion2.h"
using namespace std;
class Weight{
public:
    float Value;
    int weight;
    Weight(){
        Value=100;
    }
	public:
	void Set(int i){
		Value=i;
	}
	float Get(){
		return Value;
	}
	Weight(int lbs);
};

