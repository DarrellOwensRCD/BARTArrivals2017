//Darrell Owens
//CIS 25
//Weight Program
//11/4/2017
#include "Conversion2.h"
#include <iostream>
using namespace std;
class Weight{
    protected:
        float Value;
        int weight;
	public:
	void Set(int i){
		Value=i;
	}
	float Get(){
		return Value;
	}
	void setWeight(int lbs);
	int getWeight(void);
	Weight(int lbs);
};
Weight::Weight(int lbs){
	weight=lbs;
}
void Weight::setWeight(int lbs){
	weight=lbs;
}
int Weight::getWeight( void){
	return weight;
}
int main(){
	Weight Object(100);
	int weight0, weight1;
	float called;
	cout<<"Give me your weight and I'll print it's values on the following planets"<<endl;
	cout<<"Default weight is: "<<Object.getWeight()<<endl;
	cin>>weight1;

	if(weight1 <0){
		cout<<"Doesn't work--enter a valid weight"<<endl;
		cin>>weight1;
	}
	if(weight1!=0){
		called=create(weight1);
		Object.setWeight(called);
	}

		weight0=Object.getWeight();
		Object.Set(weight0);
		float mass;
		int choice;
		mass=Object.Get();

		cout<<"Press 1 for Mercury weight "<<endl;
		cout<<"Press 2 for Venus Weight "<<endl;
		cout<<"Press 3 for Mars weight " <<endl;
		cout<<"Press 4 for Earth's Moon weight "<<endl;
		cout<<"Press 5 for All Conversions"<<endl;
		cin>>choice;

		if (choice == 1){
			float ans= mass * 3.8;
			cout<<"Your weight on Mercury is: "<<ans<<endl;
		}

		else if (choice == 2){
			float ans=mass * 9.1;
			cout<<"Your weight on Venus is: "<<ans<<endl;
		}

		else if (choice ==3){
			float ans=mass* 3.8;
			cout<<"Your weight on Mars is: "<<ans<<endl;
		}
		else if (choice == 4 ){
			float ans= mass * 1.6;
			cout<<"Your weight on the moon is: "<<ans<<endl;
		}
		else if (choice ==5 ){
			cout<<"Your weight on Mercury is "<<mass*3.8<<endl;
			cout<<"Your weight on Venus is  "<<mass*9.1<<endl;
			cout<<"Your weight on Mars is   "<<mass*3.8 <<endl;
			cout<<"Your weight on the moon is "<<mass*1.6<<endl;
		}

	return 0;
}
