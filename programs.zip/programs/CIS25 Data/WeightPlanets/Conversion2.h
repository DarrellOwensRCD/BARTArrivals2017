#include <iostream>
using namespace std;
class Weight{
public:
    float Value;
    int weight;
    Weight();
	public:
	void Set(int i);
	float Get();
	Weight(int lbs);
};

