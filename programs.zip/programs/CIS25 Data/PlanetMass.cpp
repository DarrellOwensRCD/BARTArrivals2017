//Darrell Owens
//8/30/2017
//Weight on Planets
#include <iostream>
#include <string>
using namespace std;
int main(){   
	string planets [4] = {"Mercury", "Venus", "Mars", "Earth's moon"};
	double gravity[4]= {3.8, 9.1, 3.8, 1.6};
	double weight_list [4]={};
	double weight, mass;
	
	cout<<"Give me your weight and I'll print it's values on the following planets"<<endl;
	cin>>weight;
	
	mass=weight/9.807;
	
	for (int i=0; i<4; i++) {
	    weight_list[i]=gravity[i] * mass;
	    cout<<"Your weight on "<< planets[i]<<" is "<<weight_list[i]<<" lbs "<<endl;
	}
return 0;
}

