#include <iostream>
#include <vector>
using namespace std;
class vector1{
	public:
	vector<int> values;
	void arrayfiller(){
		cout<<"Filling array with 10 values"<<endl;
		
		for (int i=0; i<10; i++){
			values[i]=i+1;
		}
		cout<<endl;
	}
	void isEmpty(){
		if (values.empty()==0){
			cout<<"Vector is filled"<<endl;
		}
		else{
			cout<<"Vector is empty"<<endl;
		}
		cout<<endl;
	}
	void resize(int i){
		cout<<"Current vector size "<<values.size()<<endl;
		values.resize(i);
		cout<<"New vector size: "<<values.size()<<endl;
		cout<<endl;
	}
	void pushBack(){
		int pb;
		int size=values.size();
		cout<<"Last element is : "<<values.back()<<endl;
		cout<<"Push back how far from current size "<<size<<endl;
		cin>>pb;
		int start=values.back()+1;
		int end=(values.back()+1)+pb;
		
		for (int i=start; i<end; i++){
			values.push_back(i);
		}
		cout<<endl;
	}
	void popBack(){
		cout<<"Demoing a pop-back \nCurrent Vector size: "<<values.size()<<"\nCurrent last element: "<<values.back()<<endl;
		values.pop_back();
		cout<<"New size: "<<values.size()<<"\nLast element is: "<<values.back()<<endl;
		cout<<endl;
	}
	void iterate(){
		cout<<"Values of the vector"<<endl;
		for (int i=0; i<values.size(); i++){
			cout<<values[i]<<" ";
		}
		cout<<endl;
	}
};
int main(){
	vector1 v;
	cout<<"Vector Made"<<endl;
	v.isEmpty();
	v.resize(10);
	v.arrayfiller();
	v.isEmpty();
	v.iterate();
	v.resize(5);
	v.pushBack();
	v.iterate();
	v.popBack();
	v.iterate();
	return 0;
}
