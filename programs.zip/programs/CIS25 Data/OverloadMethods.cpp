//Darrell Owens 
//11/8/2017
//Method overloading 
//cis 25
#include <iostream>
using namespace std;
class apple{
	public: 
	void juice(int x, double y){
		cout<<"Called from method one\n";
	}
	void juice (int x, int z){
		cout<<"Called from method two\n";
	}
};
int main(){
	apple a;
	a.juice(1, 2.5);
	apple b;
	b.juice(1, 2);
}
