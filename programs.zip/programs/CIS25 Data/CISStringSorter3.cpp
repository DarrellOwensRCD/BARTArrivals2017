#include <iostream>
using namespace std;
int compareString(string a, string b){
	int error_count=0;
	for (int i=0; i<a.length(); i++){
	if (a[i]!=b[i]){
		error_count++;
		}		
	}
	
	return error_count;
}
int main(){
	string string1="darrell";
	string array[2]={"darrell", "jordan"};
	int n=0;
	int count=0;
	while(n<2){
		count=compareString(string1, array[n]);
		n++;
	
		if (count > 0){
			cout<<"Strings are not the same"<<endl;
		}
		else{
			cout<<"The strings are the same"<<endl;
		}
	}
}
