#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
class Calculation{
	public:
	int gSIZE;
	int sum;
	float list[1000]={};
	
	void randomization(){
		gSIZE=1000;
		srand (time(NULL));
		for(int i=0; i<gSIZE; i++){
			list[i]=(rand() % 1000)+1;
		}
		cout<<"Numbers generated and filled."<<endl;
	}
	
	void summation(){
		for(int i=0; i<gSIZE; i++){
			sum+=list[i];
		}
		cout<<"Sum of list is: "<<sum<<endl;

	}
	void average(){
		cout<<"Average is: "<<sum/gSIZE<<endl;
	}
	void sortArray(){
		int x=gSIZE;
		int hold=0;
		for(int i=0; i<x; i++){
			for(int n=0; n<x-1; n++){
				if(list[n] > list[n+1]){
					hold=list[n];
					list[n]=list[n+1];
					list[n+1]=hold;
				}
			}
		}
	}
	void intSearch(){
		sortArray();
		float loc;
		cout<<"Number to search?"<<endl;
		cin>>loc;
		int start=0;
		int x=gSIZE-1;
		int result=0;
		bool found = false;
		
		while (!found && (start< x)){
			int n=start+(x-start)/2;
			if(loc > list[n]){
				start=n+1;
			}
			else if (loc < list[n]){

				x=n-1;
			}
			else if (n==-1){
				cout<<"Value not found"<<endl;
			}
			else{
				result=n;
				found=true;
				cout<<"Value at index : "<<n<<endl;
			}		
		}
	}
	void print(){
		cout<<"Printing values!"<<endl;
		for(int i=0; i<gSIZE; i++){
			cout<<list[i]<<" ";
		}
		cout<<endl;
	} 
	
	
};
int main(){
	Calculation a;
	int choice=1;
	while(choice!=0){
		cout<<"Main menu: \n1) Generate 1000 random numbers and Binary Search\n2) Summation of all numbers \n3) Average of numbers \n4) Print numbers in the array"<<endl;
		cout<<"5) Use a binary search to locate a value "<<endl;
		cout<<"Press 0 to quit"<<endl;
		cin>>choice;
		cout<<choice<<endl;
		if(choice==1){
			a.randomization();
		}
		else if(choice==2){
			a.summation();
		}
		else if(choice ==3){
			a.average();
		}
		else if(choice==4){
			a.print();
		}
		else if(choice ==5){
			a.intSearch();
		}
		else if(choice ==0){
			break;
		}
	} 
}
