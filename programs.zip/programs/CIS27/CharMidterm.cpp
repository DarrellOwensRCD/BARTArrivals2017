#include <iostream>
using namespace std;
void compare(char test){
	int value=0;
	string name="Laneey";
	for(int i=0; i<name.size(); i++){
		if(name[i]==test){
			cout<<"Char spotted in string, at position "<<i<<endl;
			value=1;
		}
	}
	if(value==0){
		cout<<"Sorry, your char wasn't to be found in the string"<<endl;
	}
}
int main(){
	char user;
	cout<<"Insert a char and see if its in a mystery string."<<endl;
	cin>>user;
	compare(user);
	return 0;
}
