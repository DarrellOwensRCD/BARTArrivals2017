#include <iostream>
using namespace std;
class num{
	public:
	int array[9]={12, 2, 3, 10, 23, 4,10, 19,84}; //Unsorted Array
	
	void insertionSort(){
		int hold, index;
		for (int i=0; i<9; i++){
			hold=array[i]; //Take the first number iterated.
			index=i-1; //Subtract the number by one.
			
			while(index >= 0 && array[index]> hold){ //While the selected number minus 1 is greater than 0 and the position behind the selected
				array[index+1]=array[index]; //value is greater than the selected value, send it to the back. And continously do this UNTIL you encounter
				index=index-1; //a value smaller than the selected. 
			}
			array[index+1]=hold; 
		}
	}
	//For example: Capture the value 12. There's nothing behind it, so onto the next index. Index 1 is value 2, compare a position behind 2, being 12. Put 2 prior to 12. 
	//Onto index 2, compare 3 to the prior value which is the relocated 12, so put the 3 behind the 12. Repeat this process till the end of the array....
	void print(){
		for(int i=0; i<9; i++){
			cout<<array[i]<<" ";
		}
	}
};
int main(){
	num a;
	a.print();
	a.insertionSort();
	cout<<endl;
	a.print();
	
	return 0;
}
