//Float Averages
#include <iostream>
using namespace std;
class Averaging{
	public:
	float *Arr_a = NULL;
	int globalSize;
	
	void user_input(){
		int size;
		cout<<"How many numbers are you entering?"<<endl;
		cin>>size;
		Arr_a=new float [size];
		globalSize=size;
		cout<<"Proceed with entry..."<<endl;
		for(int i=0; i<size; i++){
			cout<<"Enter: ";
			cin>>Arr_a[i];
		}
	}
	
	float summation(){ 
		float sum;
		for (int i=0; i<globalSize; i++){
			sum+=Arr_a[i];
		}
		return sum;
	}
	void average(){
		float sum_val=summation();
		cout<<"The average is: "<<sum_val / globalSize<<endl;
	}
	void print(){ 
		cout<<"The Values of your array"<<endl;
		for (int i=0; i<globalSize; i++){
			cout<<Arr_a[i]<<" ";
		}
		cout<<endl;
		average();
	}
	void max(){
		float king=Arr_a[0];
		for(int i=0; i<globalSize; i++){
			if(Arr_a[i] > king){
				king= Arr_a[i];
			}
		}
		cout<<"Largest number is: "<<king<<endl;
	}
	void min(){
		float queen=Arr_a[0];
		for (int i=0; i<globalSize; i++){
			if(Arr_a[i]< queen){
				queen=Arr_a[i];
			}
		}
		cout<<"Smallest number is: "<<queen<<endl;
	}
	
};
int main(){
	Averaging a;
	int choice;
	for(;;){
		cout<<"0) Insert values \n1) Print values and Average values \n2) Get max value \n3) Get min value \n4) Press 4 to quit"<<endl;
		cin>>choice;
		if(choice ==0){
			a.user_input();	
			cout<<endl;
		}
		else if(choice==1){
			a.print();
		}
		else if (choice==2){
			a.max();
		}
		else if (choice ==3){
			a.min();
		}
		else if (choice == 4){
			break;
		}
		else{
			cout<<"Invalid input."<<endl;
		}
	}

	return 0;
}
