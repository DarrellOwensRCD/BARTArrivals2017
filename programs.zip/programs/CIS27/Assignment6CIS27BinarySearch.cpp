//Darrell Owens 
//Assignment 7/ CIS 27
//3/05/2018
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <time.h> 
#define CLOCKS_PER_MS (CLOCKS_PER_SEC / 1000)
using namespace std;
int check=0;
class Calculation{
	public:
	float *list=NULL;
	int gSIZE;
	void randomization(){  //This randomly produces the numbers, 100,000 ints
		srand (time(NULL));
		gSIZE=1000;
		list=new float [gSIZE];
		for(int i=0; i<gSIZE; i++){
			list[i]=(rand() % 1000)+1;
		}
		cout<<"Numbers generated and filled."<<endl;
	}
	void linear_search(){ 	//This searches the code linear wise, by checking each element
		int guess;
		bool condition=false;
		cout<<"Insert number to Search: "<<endl;
		cin>>guess;
		for(int i=0; i<gSIZE; i++){
			if(guess==list[i]){
				cout<<"Spotted, at index: "<<i<<endl;
				condition=true;
				break;
			}
		}
		if(condition==false){
			cout<<"This value isnt in the system"<<endl;
		}
	}
	void summation(){ //Simple summation
		int sum;
		for(int i=0; i<gSIZE; i++){
			sum+=list[i];
		}
		cout<<"Sum of list is: "<<sum<<endl;
		cout<<"Average of list is: "<<sum/gSIZE<<endl;

	}
	
	void user_sum(){ //Manually insert values vs. randomization upwards
		delete [] list;
		list=NULL;
		float hold;
			cout<<"How many numbers? "<<endl;
			cin>>gSIZE;
			list=new float[gSIZE];
			for(int i=0; i<gSIZE; i++){
				cout<<i+1<<". ";
				cin>>list[i];
			}
	}
	void intSearch(){ //Locate an integer using a Binary Search 
		float loc;
		cout<<"Number to search?"<<endl;
		cin>>loc;
		int start=0;
		int x=gSIZE-1;
		int result=0;
		bool found = false;
		
		while (!found && (start< x)){
			int n=start+(x-start)/2;
	
			if(loc > list[n])
				start=n+1;
		
			else if (loc < list[n])
				x=n-1;
			else if (n==-1)
				cout<<"Value not found"<<endl;
			else{
				result=n;
				found=true;
				cout<<"Value at index : "<<n<<endl;
			}		
		}
	}
	void sortArray(){ //Bubble Sort Algorithm MODIFIED to avoid repeition 
		int x=gSIZE;
		int hold=0;
		int rep=0;
		for(int i=0; i<x; i++){
			for(int n=0; n<x-1; n++){
				if(list[n] > list[n+1]){
					hold=list[n];
					list[n]=list[n+1];
					list[n+1]=hold;
					rep++;
				}
			}
			if (rep==0)
				break;
		}
	}
	void insertionSort(){ //Insertion sort, as described below. 
		int hold, index;
		for (int i=0; i<gSIZE; i++){
			hold=list[i]; //Take the first number iterated.
			index=i-1; //Subtract the position by one, behind the number.
			
			while(index >= 0 && list[index]> hold){ //While the selected number is greater than 0 and the position behind the selected
				list[index+1]=list[index]; //value is greater than the selected value, send it to the back. And continously do this UNTIL you encounter
				index=index-1; //a value smaller than the selected. Thus every number encountered, where the number in front is smaller than the number behind
			}					//will be compared to and put behind the larger number
			list[index+1]=hold; 
		}
	}
	void print(){
		cout<<"Printing values!"<<endl;
		for(int i=0; i<gSIZE; i++){
			cout<<list[i]<<" ";
		}
		cout<<endl;
	} 
	void isEmpty(){
		if(list==NULL){
			cout<<"Array is empty! Will not proceed until Array is filled."<<endl;
			check=1;
		}
		else{
			check=0;
		}
	}
	
};
int main(){
	clock_t t;
	t=clock();
	Calculation a;
	int choice=1;
	float last=0;
	while(choice!=0){
		cout<<"Main menu: \n1) Generate 1000 random numbers\n2) Summation of all numbers and Average \n3) Insert numbers manually \n4) Print numbers in the array"<<endl;
		cout<<"5) Use a binary search to locate a value \n6) Insertion Sort \n7) Bubble Sort Modified \n8) Linear Search. \n9) Empty Check"<<endl;
		cout<<"Press 0 to quit"<<endl;
		cin>>choice; 
			if(choice==1){
				cout<<"Randomization"<<endl;
				a.randomization();
			}
			else if(choice==2){
				a.isEmpty();
				if(check==0){
					a.summation();
				}
			}
			else if(choice ==3){
				a.user_sum();
			}
			else if(choice==4){
				a.isEmpty();
				if(check==0){
					a.print();
				}
			}
			else if(choice ==5){
			a.isEmpty();
				if(check==0){
					a.intSearch();
				}
			}
			else if(choice ==6){
				a.isEmpty();
				if(check==0){
					cout<<"Insertion sort"<<endl;
					a.insertionSort();
				}
			}
			else if(choice ==7){
				a.isEmpty();
				if(check==0){
					cout<<"Bubble sort"<<endl;
					a.sortArray();
				}
			}
			else if(choice==8){
				a.isEmpty();
				if(check==0){
					cout<<"Linear Search"<<endl;
					a.linear_search();
				}
			}
			else if(choice==9){
				cout<<"Is Empty Check"<<endl;
				a.isEmpty();
			}
			else if(choice ==0){
				break;
			}

		clock_t time=clock()-t;
		float now=((float)time)/CLOCKS_PER_SEC;
		unsigned mili = (float(now-last)) / CLOCKS_PER_MS;
	//	cout<<"Interval Time: "<<now-last<<" seconds."<<endl;
		//cout<<"Interval in Miliseconds: "<<mili<<" miliseconds"<<endl;
	//	cout<<"Overall time: "<<now<<" seconds."<<endl;
	//	last=now;

	} 
	t=clock()-t;
	cout<<"Final runtime of program is: "<<((float)t)/CLOCKS_PER_SEC<<endl;
}
