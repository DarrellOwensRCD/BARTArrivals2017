import sys
def main():
    char= 100000000.5
    print(sys.getsizeof(char))
