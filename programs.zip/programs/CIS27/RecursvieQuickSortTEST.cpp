//This quickSORT works
#include <iostream>
using namespace std;
class w{	
	public:
	int arr[10]={1,5,4,3,2,10,18,9,20,1};
	int arr2[];
	int le=0; //0 (first position)
	int ri=9; //9 or last position
	
void quickSort(int arr[], int left, int right) { //This will be necessary for the recursive nature, by passing values through the signature
      int i = left, n = right; //Establishing local variables which will grow/shrink and will need to be used later to contrast w/ initial starting indexes (left/right)
      int hold; //this will hold the value during the swap
      int pivot = arr[(left + right) / 2]; //this is the "pivot", center value (round up in case of odd) that'll be used to compare
   										   //taking the last element location and first element location, adding and dividing, is calculating the median space. 
   //the nature of the patrition is that the number chosen will compare end elements to the pivot, and swap them if need be, as so....
	      while (i <= n) { //while the number of the left side of the pivot is smaller or equal to the number on the right side of the pivot, continue...
	            while (arr[i] < pivot) //if the left-side index number is smaller than the pivot as it should be, increment up to the next number. Nothing to do.
	                  i++;
	            while (arr[n] > pivot) //if the right-side index number is larger than the pivot as it should be, increment down to the prior number. Nothing to do.
	                  n--;
	            if (i <= n) {				//if the indexes are properly smaller and larger than each other, but the number is NOT smaller than the pivot on the left side 
	            							//and NOT larger than the pivot from the right side, we will proceed to swap.
	                  hold = arr[i];			//hold the smaller index's value...
	                  arr[i] = arr[n];		//swap the value on the right side, into the left side..
	                  arr[n] = hold;			//put the value from the left side, back onto the right side
	                  i++;					//We're done with the swap. Both indexes go up 1 (left) or go down 1 (right)
	                  n--;
	            }
	      };
	      //Repeat the process. So long as either index hasn't overtaken their respective initial index values, there's sorting to do.
	      //When the right or left index inevitably over takes their opposite's initial index, that means "we've been there", and no more sorting
	      //on that side needs to be done. 
	      if (left < n)
	            quickSort(arr, left, n);
	      if (i < right)
	            quickSort(arr, i, right);
}
void print(){
	for(int i=0; i<10; i++){
		quickSort(arr, le, ri);
		cout<<arr[i]<<endl;
	}
}
void isEmpty(){
	if(arr2.empty()){
		cout<<"Array is empty"<<endl;
	}
	else{
		cout<<"Array is filled."<<endl;
	}
}
};

int main(){
	class w a;
	
	a.isEmpty();
return 0;	
}
